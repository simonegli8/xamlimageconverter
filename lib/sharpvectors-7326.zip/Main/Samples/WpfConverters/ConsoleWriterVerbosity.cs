﻿using System;

namespace SharpVectors.Converters
{
    public enum ConsoleWriterVerbosity
    {
        None    = 0,
        Quiet   = 1,
        Minimal = 2,
        Normal  = 3
    }
}
