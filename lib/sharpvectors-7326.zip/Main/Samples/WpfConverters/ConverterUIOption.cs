﻿using System;

namespace SharpVectors.Converters
{
    public enum ConverterUIOption
    {
        Unknown = 0,
        None    = 1,
        Console = 2,
        Windows = 3
    }
}
