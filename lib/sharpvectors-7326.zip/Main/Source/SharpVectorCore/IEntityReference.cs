using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for IEntityReference.
	/// </summary>
	public interface IEntityReference
	{
	}
}
