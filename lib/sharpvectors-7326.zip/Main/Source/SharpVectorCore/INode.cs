using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for INode.
	/// </summary>
	public interface INode : IXmlNode
	{
	}
}
