using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for IDomImplementation.
	/// </summary>
	public interface IDomImplementation
	{
	}
}
