using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for IElement.
	/// </summary>
	public interface IElement : IXmlElement      
	{
	}
}
