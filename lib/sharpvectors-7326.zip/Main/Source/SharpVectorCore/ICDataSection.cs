using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for ICDataSection.
	/// </summary>
	public interface ICDataSection : ICharacterData
	{
	}
}
