using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for IText.
	/// </summary>
	public interface IText : ICharacterData
	{
	}
}
