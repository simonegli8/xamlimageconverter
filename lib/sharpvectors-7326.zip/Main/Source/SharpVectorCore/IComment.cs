using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for IComment.
	/// </summary>
	public interface IComment : ICharacterData
	{
	}
}
