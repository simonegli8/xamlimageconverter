using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for IProcessingInstruction.
	/// </summary>
	public interface IProcessingInstruction
	{
	}
}
