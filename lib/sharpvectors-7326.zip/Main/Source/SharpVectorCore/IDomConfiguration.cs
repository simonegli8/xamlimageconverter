using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for IDomConfiguration.
	/// </summary>
	public interface IDomConfiguration
	{
	}
}
