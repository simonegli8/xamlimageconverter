using System;

namespace SharpVectors.Dom.Svg
{
	public interface ISvgAnimatedInteger
	{
		long BaseVal{get;set;}
		long AnimVal{get;}
	}
}

