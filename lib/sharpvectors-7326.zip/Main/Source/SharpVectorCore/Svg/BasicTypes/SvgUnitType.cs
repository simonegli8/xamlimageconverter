using System;

namespace SharpVectors.Dom.Svg
{
	public enum SvgUnitType
	{
		UserSpaceOnUse    = 1,
		ObjectBoundingBox = 2
	}
}