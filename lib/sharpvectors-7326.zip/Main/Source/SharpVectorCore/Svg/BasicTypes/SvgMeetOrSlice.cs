using System;

namespace SharpVectors.Dom.Svg
{
	// Meet-or-slice Types
	public enum SvgMeetOrSlice
	{
		Unknown,
		Meet,
		Slice
	}
}
