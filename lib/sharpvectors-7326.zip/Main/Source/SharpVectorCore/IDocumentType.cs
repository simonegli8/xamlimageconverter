using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for IDocumentType.
	/// </summary>
	public interface IDocumentType
	{
	}
}
