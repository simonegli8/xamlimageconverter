using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for ICharacterData.
	/// </summary>
	public interface ICharacterData : INode
	{
	}
}
