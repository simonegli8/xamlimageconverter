using System;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for IDocumentFragment.
	/// </summary>
	public interface IDocumentFragment
	{
	}
}
