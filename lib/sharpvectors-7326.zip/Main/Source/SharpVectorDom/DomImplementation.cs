using System;
using System.Xml;

namespace SharpVectors.Dom
{
	/// <summary>
	/// Summary description for DomImplementation.
	/// </summary>
	public class DomImplementation
		: XmlImplementation
	{
		#region Constructors
		
		public DomImplementation()
			: base()
		{
		}
		
		#endregion
	}
}
