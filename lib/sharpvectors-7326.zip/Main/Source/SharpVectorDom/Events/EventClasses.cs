using System;

namespace SharpVectors.Dom.Events
{
	/// <summary>
	/// Summary description for EventClasses.
	/// </summary>
	public class EventClasses
	{
		public static readonly string XmlEvents2001 = "http://www.w3.org/2001/xml-events";
	}
}
