﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Web;
using GalaSoft.Wpf.Utilities;

namespace GalaSoft.Web.ConvertXamlToPng
{
  // http://dotnetslackers.com/articles/aspnet/Generating-Image-Thumbnails-in-ASP-NET.aspx

  public class GenerateImage : IHttpHandler
  {
    public void ProcessRequest(HttpContext context)
    {
      string xamlFileName = "Sample";
      double width = 640;
      double height = 480;
      string cultureName = "en-US";
      List<DependencyPropertyReplacement> replacements = null;

      if (context.Request.QueryString["width"] != null)
      {
        width = Double.Parse(context.Request.QueryString["width"]);
      }
      if (context.Request.QueryString["height"] != null)
      {
        height = Double.Parse(context.Request.QueryString["height"]);
      }
      if (context.Request.QueryString["culture"] != null)
      {
        cultureName = context.Request.QueryString["culture"];
      }
      if (context.Request.QueryString["xaml"] != null)
      {
        xamlFileName = context.Request.QueryString["xaml"];
      }

      if (context.Request.QueryString["localize"] != null)
      {
        string localize = context.Request.QueryString["localize"];
        string[] localizeElements = localize.Split(new char[] { ';' });
        PrepareLocalizableReplacements(cultureName, xamlFileName, localizeElements, ref replacements);
      }
      if (context.Request.QueryString["customize"] != null)
      {
        string customize = context.Request.QueryString["customize"];
        string[] customizeElements = customize.Split(new char[] { ';' });
        PrepareCustomizableReplacements(customizeElements, ref replacements);
      }

      FileInfo xamlFile = new FileInfo(context.Server.MapPath(string.Format("~/XAML/{0}.xaml", xamlFileName)));

      try
      {
        using (Stream stream = File.OpenRead(xamlFile.FullName))
        {
          using (MemoryStream memoryStream = new MemoryStream())
          {
            XamlToPngConverter converter = new XamlToPngConverter();
            converter.Convert(stream, width, height, memoryStream, replacements);

            // set the content type
            context.Response.ContentType = "image/jpg";
            memoryStream.WriteTo(context.Response.OutputStream);
          }
        }
      }
      catch (Exception ex)
      {
        throw new HttpException(404, "Image not found:" + xamlFileName, ex);
      }
    }

    private void PrepareLocalizableReplacements(string cultureName,
      string xamlFileName, 
      string[] elementNames, 
      ref List<DependencyPropertyReplacement> replacements)
    {
      if (replacements == null)
      {
        replacements = new List<DependencyPropertyReplacement>();
      }

      if (xamlFileName == null
        || elementNames == null
        || xamlFileName.Length == 0
        || elementNames.Length == 0)
      {
        return;
      }

      CultureInfo culture = CultureInfo.GetCultureInfo(cultureName);

      foreach (string elementName in elementNames)
      {
        string stringName = xamlFileName + elementName;
        string value = Properties.Resources.ResourceManager.GetString(stringName, culture);

        // Since we are not sure if we must replace Text or Content, prepare replacement for each
        DependencyPropertyReplacement replacement1 = new DependencyPropertyReplacement();
        replacement1.ElementName = elementName;
        replacement1.PropertyName = "Text";
        replacement1.Value = value;
        replacements.Add(replacement1);
        
        DependencyPropertyReplacement replacement2 = new DependencyPropertyReplacement();
        replacement2.ElementName = elementName;
        replacement2.PropertyName = "Content";
        replacement2.Value = value;
        replacements.Add(replacement2);
      }
    }

    private void PrepareCustomizableReplacements(string[] elements,
      ref List<DependencyPropertyReplacement> replacements)
    {
      if (replacements == null)
      {
        replacements = new List<DependencyPropertyReplacement>();
      }

      foreach (string nameValue in elements)
      {
        string[] nameValuePair = nameValue.Split(new char[] { ':' });

        // This cannot be handled in a generic way because the DP must be set with a value
        // of the correct type.

        // UI elements (such as SolidColorBrush) must be frozen because of multithreading

        switch (nameValuePair[0])
        {
          case "BigBall":
            replacements.Add(MakeCustomizableReplacement(nameValuePair[0], 
              "Fill", WpfUtility.MakeSolidColorBrush(nameValuePair[1], true)));
            break;
          case "MainGridRightGradientStop":
            replacements.Add(MakeCustomizableReplacement(nameValuePair[0],
              "Color", WpfUtility.MakeColor(nameValuePair[1])));
            break;
          case "MainTextBlockLowerGradientStop":
            replacements.Add(MakeCustomizableReplacement(nameValuePair[0],
              "Color", WpfUtility.MakeColor(nameValuePair[1])));
            break;
          case "MainGridGradient":
            object[] points = SplitGradientVectorPoints(nameValuePair[1]);
            replacements.Add(MakeCustomizableReplacement(nameValuePair[0],
              "StartPoint", points[0]));
            replacements.Add(MakeCustomizableReplacement(nameValuePair[0],
              "EndPoint", points[1]));
            break;
        }
      }
    }

    private object[] SplitGradientVectorPoints(string queryValue)
    {
      if (queryValue == null)
      {
        throw new ArgumentNullException("queryValue");
      }
      if (queryValue.Length == 0)
      {
        throw new ArgumentException("Parameter may not be empty", "queryValue");
      }

      string[] pointsString = queryValue.Split(new char[] { 'X' });
      object[] points = new object[pointsString.Length];

      for (int index = 0; index < pointsString.Length; index++)
      {
        string[] pointCoord = pointsString[index].Split(new char[] { ',' });
        object point = WpfUtility.MakePoint(Double.Parse(pointCoord[0]), Double.Parse(pointCoord[1]));
        points[index] = point;
      }

      return points;
    }

    private DependencyPropertyReplacement MakeCustomizableReplacement(string elementName, string propertyName, object value)
    {
      DependencyPropertyReplacement replacement = new DependencyPropertyReplacement();
      replacement.ElementName = elementName;
      replacement.PropertyName = propertyName;
      replacement.Value = value;
      return replacement;
    }

    public bool IsReusable
    {
      get
      {
        return true;
      }
    }
  }
}
