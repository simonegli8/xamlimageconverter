﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace GalaSoft.Wpf.Utilities
{
  public class XamlToPngConverter
  {
    public void Convert(Stream xamlInput,
      double width, 
      double height, 
      Stream pngOutput, 
      List<DependencyPropertyReplacement> replacements)
    {
      // Round width and height to simplify
      width = Math.Round(width);
      height = Math.Round(height);

      Thread pngCreationThread = new Thread((ThreadStart) delegate()
      {
        FrameworkElement element = XamlReader.Load(xamlInput) as FrameworkElement;

        if (replacements != null)
        {
          foreach (DependencyPropertyReplacement replacement in replacements)
          {
            DependencyObject replacementElement = element.FindName(replacement.ElementName) as DependencyObject;

            if (replacementElement != null)
            {
              Type t = replacementElement.GetType();
              FieldInfo fieldInfo = t.GetField(replacement.PropertyName,
                 BindingFlags.Static | BindingFlags.FlattenHierarchy | BindingFlags.Public);

              if (fieldInfo != null)
              {
                DependencyProperty dp = (DependencyProperty) fieldInfo.GetValue(null);
                replacementElement.SetValue(dp, replacement.Value);
              }
            }
          }
        }

        Size renderingSize = new Size(width, height);
        element.Measure(renderingSize);
        Rect renderingRectangle = new Rect(renderingSize);
        element.Arrange(renderingRectangle);

        BitmapSource xamlBitmap = RenderToBitmap(element);

        try
        {
          PngBitmapEncoder enc = new PngBitmapEncoder();
          enc.Frames.Add(BitmapFrame.Create(xamlBitmap));
          enc.Save(pngOutput);
        }
        catch (ObjectDisposedException)
        {
          // IF the operation lasted too long, the object might be disposed already
        }
      });

      pngCreationThread.IsBackground = true;
      pngCreationThread.SetApartmentState(ApartmentState.STA);
      pngCreationThread.Start();
      pngCreationThread.Join();

      try
      {
        if (pngOutput.Length == 0)
        {
          throw new TimeoutException();
        }
      }
      catch (ObjectDisposedException)
      {
        // If the object was disposed, it means that the Stream is ready.
      }
    }

    private BitmapSource RenderToBitmap(FrameworkElement target)
    {
      Rect bounds = VisualTreeHelper.GetDescendantBounds(target);
      RenderTargetBitmap renderBitmap = new RenderTargetBitmap((int) target.ActualWidth,
        (int) target.ActualHeight,
        96, 96, PixelFormats.Pbgra32);

      DrawingVisual visual = new DrawingVisual();
      using (DrawingContext context = visual.RenderOpen())
      {
        VisualBrush brush = new VisualBrush(target);
        context.DrawRectangle(brush, null, new Rect(new Point(), bounds.Size));
      }
      renderBitmap.Render(visual);
      return renderBitmap;
    }
  }

  public class DependencyPropertyReplacement
  {
    public string ElementName
    {
      get;
      set;
    }
    private string _propertyName;
    public string PropertyName
    {
      get { return _propertyName; }
      set
      {
        if (value == null)
        {
          value = "";
        }
        if (!value.EndsWith("Property"))
        {
          value += "Property";
        }
        _propertyName = value;
      }
    }
    public object Value
    {
      get;
      set;
    }
  }
}
