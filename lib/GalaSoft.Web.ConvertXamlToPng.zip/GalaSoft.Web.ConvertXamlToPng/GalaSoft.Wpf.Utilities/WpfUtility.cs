﻿using System;
using System.Windows.Media;

namespace GalaSoft.Wpf.Utilities
{
  public static class WpfUtility
  {
    public static object MakeColor(string colorNameOrCode)
    {
      if (colorNameOrCode == null)
      {
        throw new ArgumentNullException("colorNameOrCode");
      }

      if (colorNameOrCode.StartsWith("#"))
      {
        byte[] bytes = HexToData(colorNameOrCode.Substring(1));

        if (bytes == null
          || bytes.Length < 3
          || bytes.Length > 4)
        {
          throw new ArgumentException("Parameter must be formatted as #AARRGGBB or #RRGGBB", "colorNameOrCode");
        }

        if (bytes.Length == 3)
        {
          return MakeColor(255, bytes[0], bytes[1], bytes[2]);
        }
        else
        {
          return MakeColor(bytes[0], bytes[1], bytes[2], bytes[3]);
        }
      }
      else
      {
        System.Drawing.Color drawingColor = System.Drawing.Color.FromName(colorNameOrCode);
        return MakeColor(drawingColor.A, drawingColor.R, drawingColor.G, drawingColor.B);
      }
    }

    public static object MakeColor(byte a, byte r, byte g, byte b)
    {
      return System.Windows.Media.Color.FromArgb(a, r, g, b);
    }

    public static object MakeSolidColorBrush(string colorNameOrCode)
    {
      return MakeSolidColorBrush(colorNameOrCode, false);
    }

    public static object MakeSolidColorBrush(string colorNameOrCode, bool freeze)
    {
      if (colorNameOrCode == null)
      {
        throw new ArgumentNullException("colorNameOrCode");
      }

      object color = MakeColor(colorNameOrCode);
      SolidColorBrush brush = new SolidColorBrush((System.Windows.Media.Color) color);
      
      if (freeze)
      {
        brush.Freeze();
      }
      
      return brush;
    }

    public static object MakeSolidColorBrush(byte a, byte r, byte g, byte b)
    {
      return MakeSolidColorBrush(a, r, g, b, false);
    }

    public static object MakeSolidColorBrush(byte a, byte r, byte g, byte b, bool freeze)
    {
      SolidColorBrush brush = new SolidColorBrush(System.Windows.Media.Color.FromArgb(a, r, g, b));

      if (freeze)
      {
        brush.Freeze();
      }

      return brush;
    }

    public static object MakePoint(System.Drawing.Point originalPoint)
    {
      return new System.Windows.Point((double) originalPoint.X, (double) originalPoint.Y);
    }

    public static object MakePoint(double[] coords)
    {
      return new System.Windows.Point(coords[0], coords[1]);
    }

    public static object MakePoint(double x, double y)
    {
      return new System.Windows.Point(x, y);
    }

    // http://www.codeproject.com/KB/recipes/hexencoding.aspx
    private static byte[] HexToData(string hexString)
    {
      if (hexString == null)
        return null;

      if (hexString.Length % 2 == 1)
        hexString = '0' + hexString;

      byte[] data = new byte[hexString.Length / 2];

      for (int i = 0; i < data.Length; i++)
        data[i] = Convert.ToByte(hexString.Substring(i * 2, 2), 16);

      return data;
    }
  }
}
