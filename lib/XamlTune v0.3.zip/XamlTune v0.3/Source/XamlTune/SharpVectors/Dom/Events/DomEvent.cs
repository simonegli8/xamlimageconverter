using System;

namespace SharpVectors.Dom.Events
{
	public delegate void DomEvent(IEvent e);
}
