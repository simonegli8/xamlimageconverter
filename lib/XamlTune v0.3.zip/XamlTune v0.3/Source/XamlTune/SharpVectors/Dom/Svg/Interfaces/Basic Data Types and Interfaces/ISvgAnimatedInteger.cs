using System;

namespace SharpVectors.Dom.Svg
{
	public interface ISvgAnimatedInteger
	{
		double BaseVal{get;}
		double AnimVal{get;}
	}
}

