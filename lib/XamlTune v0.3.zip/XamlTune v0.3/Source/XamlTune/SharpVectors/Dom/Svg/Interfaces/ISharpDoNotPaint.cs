using System;

namespace SharpVectors.Dom.Svg
{
	public interface ISharpDoNotPaint
	{
	}
}
