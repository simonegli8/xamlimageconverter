﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using System.Collections;
using System.Windows.Markup;
using System.Text.RegularExpressions;
using System.Globalization;
using SharpVectors.Renderer.Xaml;
using SharpVectors.Dom.Svg;
using System.Windows.Ink;
using ICSharpCode.TextEditor.Document;

namespace XamlTune
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Input : Window
    {
        public Input()
        {
            InitializeComponent();


        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            textControl.Document.HighlightingStrategy = HighlightingStrategyFactory.CreateHighlightingStrategy("XML");
            if (App.Arguments != null)
            {
                if (App.Arguments.Length >= 1)
                {
                    try
                    {
                        textControl.Text = System.IO.File.ReadAllText(App.Arguments[0]);
                        Convert();
                    }
                    catch
                    {
                    }
                }

            }

        }

        private void btnConvert_Click(object sender, RoutedEventArgs e)
        {
            Convert();
        }

        public void Convert()
        {
            if (textControl.Text.Length > 0)
            {
                XmlNamespaceManager mgr = new XmlNamespaceManager(new NameTable());
                mgr.AddNamespace("svg", "http://www.w3.org/2000/svg");

                XmlDocument doc = new XmlDocument(mgr.NameTable);
                try
                {
                    doc.LoadXml(textControl.Text);
                    if (doc.SelectSingleNode("/svg:svg", mgr) != null)
                    {
                        XamlContent = ConvertUtility.ConvertSvg(textControl.Text);
                    }
                    else
                    {
                        string txt = textControl.Text;
                        txt.Replace(XamlTuner.slNamespace, XamlTuner.wpfNamespace);
                        XamlContent = txt;
                    }
                }
                catch
                {
                }
            }
        }

        private string xamlContent;

        public string XamlContent
        {
            get { return xamlContent; }
            set
            {
                xamlContent = value;
                if (XamlContentChanged != null)
                    XamlContentChanged(this, EventArgs.Empty);
            }
        }

        public event EventHandler XamlContentChanged;

        private void btnInput_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == true)
            {
                try
                {
                    textControl.Text = System.IO.File.ReadAllText(ofd.FileName);
                }
                catch
                {
                }
            }
        }
    }
}
