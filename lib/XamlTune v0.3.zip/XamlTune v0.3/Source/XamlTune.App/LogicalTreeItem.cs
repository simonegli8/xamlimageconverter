using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Media;
using System.Diagnostics;
using System.Windows.Input;
using System.Collections.ObjectModel;

namespace Microsoft.Samples.KMoore.WPFSamples.VisualTreeViewer
{
    public class LogicalTreeItem
    {
        public LogicalTreeItem(DependencyObject element)
        {
            _element = element;
        }

        public IEnumerable<LogicalTreeItem> Children
        {
            get
            {
                if (_children == null)
                {
                    _children = new List<LogicalTreeItem>();
                    foreach(DependencyObject obj in LogicalTreeHelper.GetChildren(_element))
                    {
                        _children.Add(new LogicalTreeItem(obj));
                    }
                }
                return _children;
            }
        }

        public string Name
        {
            get
            {
                FrameworkElement fe = _element as FrameworkElement;
                if (fe != null && !String.IsNullOrEmpty(fe.Name))
                {
                    return Type + ":" + fe.Name;
                }
                else
                {
                    return Type;
                }
            }
        }

        public string Type
        {
            get
            {
                return _element.GetType().Name;
            }
        }

        private DependencyObject _element;
        public DependencyObject Element
        {
            get { return _element; }
        }

        private List<LogicalTreeItem> _children;
    }

}
