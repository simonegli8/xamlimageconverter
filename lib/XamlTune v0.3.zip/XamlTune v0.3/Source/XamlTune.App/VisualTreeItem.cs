using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Media;
using System.Diagnostics;
using System.Windows.Input;
using System.Collections.ObjectModel;

namespace Microsoft.Samples.KMoore.WPFSamples.VisualTreeViewer
{
    public class VisualTreeItem
    {
        public VisualTreeItem(DependencyObject element)
        {
            _element = element;
        }

        public IEnumerable<VisualTreeItem> Children
        {
            get
            {
                if (_children == null)
                {
                    _children = new List<VisualTreeItem>(VisualTreeHelper.GetChildrenCount(_element));
                    for (int i = 0; i < VisualTreeHelper.GetChildrenCount(_element); i++)
                    {
                        _children.Add(new VisualTreeItem(VisualTreeHelper.GetChild(_element, i)));
                    }
                }
                return _children;
            }
        }

        public string Name
        {
            get
            {
                FrameworkElement fe = _element as FrameworkElement;
                if (fe != null && !String.IsNullOrEmpty(fe.Name))
                {
                    return Type + ":" + fe.Name;
                }
                else
                {
                    return Type;
                }
            }
        }

        public string Type
        {
            get
            {
                return _element.GetType().Name;
            }
        }

        private DependencyObject _element;
        public DependencyObject Element
        {
            get { return _element; }
        }

        private List<VisualTreeItem> _children;
    }

}
