﻿

// ---------------------------------------------------------------
// Date          090509
// Author        BBIM
// Version       Visual Studio 2008 Pro (C#).
// Framework     3.5.
// Module name   Form1
// Purpose       SVG to XAML with svg2xaml.xsl.
// Comments      1) Original stylesheet source: svg2xaml.xsl. 
//               Toine de Greef, http://members.chello.nl/~a.degreef/XAML.html
//               2) Used stylesheet source.
//               svg2xaml.xsl + colors.xml from Inkskape 0.46. 
//               See C:\Program Files\Inkscape\share\extensions\. Put in application root.
//               3) XSLT_Transform() can also be used for XAML to SVG.
//               Use xaml2svg.xsl + files in \xaml2svg from Inkscape.
//               |-> Add xmlns="http://www.w3.org/2000/svg" declaration in root element afterwards!
//               Not implemented (stylesheet filename, File | Open, File | Save).
//               4) See also website:
//               D:\PC3000_Info_Base\My_Website\Website_NET2971_016_2\Articles\Article_SVGToXAML_01.htm.
// ---------------------------------------------------------------

// History.
// ---------------------------------------------------------------
// 03-04-09 - SVG2XAML_01.
//            D:\PC3000_Info_Base\My_Website\Website_NET2971_016_2\Standards\Standard_XSLT.htm.
// 03-04-09 - SVG2XAML_02.
// 09-05-09 - Mod_SVG2XAML_03 - Menu's added. Textboxes for SVG and XAML.
// ---------------------------------------------------------------


// ---------------------------------------------
// private void Form1_Shown()
// private void Form1_FormClosing(
// private void Form1_Resize()
// private void Resize_Me()
// private void Form1_Paint()                   ' Draw borders for textboxes.
// private void panSVG_Paint()                  ' Draw background for slider.
// private void panXAM_Paint()                  ' Draw background for slider.
// private void mnuFileNew_Click()              ' Menu File | New.
// private void mnuFileOpen_Click()             ' Menu File | Open.
// private void mnuFileSave_Click()             ' Menu File | Save (.xaml).
// private void mnuFileSaveAs_Click()           ' Menu File | Save As (.xaml).
// private void SaveXAML()                      ' Transform SVG to XAML and save.
// private void mnuFileExit_Click()             ' Menu File | Exit.
// private void mnuHelpIndex_Click()            ' Menu Help | Index.
// private void mnuHelpAbout_Click()            ' Menu Help | About.
// ---------------------------------------------
// private string XSLT_Transform()              ' Transform an XML document with XSLT.
// private string XSLT_Transform_2()            ' Transform an XML document with XSLT.
// private string File_ReadAllText()            ' Get text from a file.
// private string File_AppPath_2()              ' Get application path.
// ---------------------------------------------


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Xml;
using System.Xml.Xsl;
using System.IO;
 


namespace BBIM
{
    public partial class Form1 : Form
    {
        private const string APP_NAME = "SVG2XAML";
        private const string APP_BUILD = "0.0.3.0";

        // Main menu's.
        private MenuStrip mnuMainStrip;
        private ToolStripMenuItem mnuFile;
        private ToolStripMenuItem mnuHelp;

        // Dropdown items on mnuFile.
        private ToolStripMenuItem mnuFileNew;
        private ToolStripMenuItem mnuFileOpen;
        private ToolStripMenuItem mnuFileSave;
        private ToolStripMenuItem mnuFileSaveAs;
        private ToolStripSeparator mnuFileSep01;
        private ToolStripMenuItem mnuFilePageSetup;
        private ToolStripMenuItem mnuFilePreview;
        private ToolStripMenuItem mnuFilePrint;
        private ToolStripSeparator mnuFileSep02;
        private ToolStripMenuItem mnuFileExtra0;
        private ToolStripMenuItem mnuFileExtra1;
        private ToolStripMenuItem mnuFileExtra2;
        private ToolStripMenuItem mnuFileExtra3;
        private ToolStripMenuItem mnuFileExtra4;
        private ToolStripSeparator mnuFileSep03;
        private ToolStripMenuItem mnuFileExit;

        // Dropdown items on mnuHelp.
        private ToolStripMenuItem mnuHelpIndex;
        private ToolStripMenuItem mnuHelpAbout;

        private OpenFileDialog OpenFileDialog1;
        private SaveFileDialog SaveFileDialog1;

        private string sFilNameOpenXSL;             // Stylesheet for SVG to XAML conversion (.xsl).
        private string sFilNameOpenSVG;             // File | Open (.svg).
        private string sDirNameOpenSVG;             // Path from sFilNameOpenXSL.
        private string sFilNameSaveXAM;             // File | Save (.xaml).
        private string sDirNameSaveXAM;             // Path from sFilNameOpenXSL.

        private Label lblSVG;                       // Label "SVG" above textBox.
        private Label lblXAM;                       // Label "XAML" above textBox.
        private Panel panSVG;                       // Container for txtBoxSVG (create margins).
        private Panel panXAM;                       // Container for txtBoxXAM (create margins).
        private TextBox txtBoxSVG;                  // Textbox for the SVG code.
        private TextBox txtBoxXAM;                  // Textbox for the XAML code.


        // Constructor.
        public Form1()
        {
            InitializeComponent();

            // Main menus.
            mnuMainStrip = new MenuStrip();
            mnuFile = new ToolStripMenuItem();
            mnuHelp = new ToolStripMenuItem();
            // Menu File.
            mnuFileNew = new ToolStripMenuItem();
            mnuFileOpen = new ToolStripMenuItem();
            mnuFileSave = new ToolStripMenuItem();
            mnuFileSaveAs = new ToolStripMenuItem();
            mnuFileSep01 = new ToolStripSeparator();
            mnuFilePageSetup = new ToolStripMenuItem();
            mnuFilePreview = new ToolStripMenuItem();
            mnuFilePrint = new ToolStripMenuItem();
            mnuFileSep02 = new ToolStripSeparator();
            mnuFileExtra0 = new ToolStripMenuItem();
            mnuFileExtra1 = new ToolStripMenuItem();
            mnuFileExtra2 = new ToolStripMenuItem();
            mnuFileExtra3 = new ToolStripMenuItem();
            mnuFileExtra4 = new ToolStripMenuItem();
            mnuFileSep03 = new ToolStripSeparator();
            mnuFileExit = new ToolStripMenuItem();
            // Menu Help.
            mnuHelpIndex = new ToolStripMenuItem();
            mnuHelpAbout = new ToolStripMenuItem();

            OpenFileDialog1 = new OpenFileDialog();
            SaveFileDialog1 = new SaveFileDialog();

            lblSVG = new Label();
            lblXAM = new Label();
            panSVG = new Panel();
            panXAM = new Panel();
            txtBoxSVG = new TextBox();
            txtBoxXAM = new TextBox();

            this.SuspendLayout();


            // --- Menu File -----------------------------------------

            mnuMainStrip.Items.AddRange(new ToolStripItem[] {
            mnuFile,
            mnuHelp});

            // 
            // mnuFile
            // 
            mnuFile.DropDownItems.AddRange(new ToolStripItem[] {
            mnuFileNew,
            mnuFileOpen,
            mnuFileSave,
            mnuFileSaveAs,
            mnuFileSep01,
            mnuFilePageSetup,
            mnuFilePreview,
            mnuFilePrint,
            mnuFileSep02,
            mnuFileExtra0,
            mnuFileExtra1,
            mnuFileExtra2,
            mnuFileExtra3,
            mnuFileExtra4,
            mnuFileSep03,
            mnuFileExit});
            mnuFile.Name = "mnuFile";
            mnuFile.Size = new System.Drawing.Size(35, 12);
            mnuFile.Font = new Font("Tahoma", 8.0F);
            mnuFile.Text = "&File";
            // 
            // mnuHelp
            // 
            mnuHelp.DropDownItems.AddRange(new ToolStripItem[] {
            mnuHelpIndex,
            mnuHelpAbout});
            mnuHelp.Name = "mnuHelp";
            mnuHelp.Size = new System.Drawing.Size(35, 12);
            mnuHelp.Font = new Font("Tahoma", 8.0F);
            mnuHelp.Text = "&Help";

            // 
            // mnuFileNew
            // 
            mnuFileNew.Name = "mnuFileNew";
            mnuFileNew.Size = new System.Drawing.Size(152, 12);
            mnuFileNew.Text = "&New";
            mnuFileNew.Click += new EventHandler(mnuFileNew_Click);
            // 
            // mnuFileOpen
            // 
            mnuFileOpen.Name = "mnuFileOpen";
            mnuFileOpen.Size = new System.Drawing.Size(152, 12);
            mnuFileOpen.Text = "&Open ...";
            mnuFileOpen.Click += new EventHandler(mnuFileOpen_Click);
            // 
            // mnuFileSave
            // 
            mnuFileSave.Name = "mnuFileSave";
            mnuFileSave.Size = new System.Drawing.Size(152, 12);
            mnuFileSave.Text = "&Save (.xaml)";
            mnuFileSave.Click += new EventHandler(mnuFileSave_Click);
            // 
            // mnuFileSaveAs
            // 
            mnuFileSaveAs.Name = "mnuFileSaveAs";
            mnuFileSaveAs.Size = new System.Drawing.Size(152, 12);
            mnuFileSaveAs.Text = "Save &As (.xaml) ...";
            mnuFileSaveAs.Click += new EventHandler(mnuFileSaveAs_Click);
            // 
            // mnuFilePageSetup
            // 
            mnuFilePageSetup.Name = "mnuFilePageSetup";
            mnuFilePageSetup.Size = new System.Drawing.Size(152, 12);
            mnuFilePageSetup.Text = "Page Setup ...";
            // 
            // mnuFilePreview
            //
            mnuFilePreview.Name = "mnuFilePreview";
            mnuFilePreview.Size = new System.Drawing.Size(152, 12);
            mnuFilePreview.Text = "Preview ...";
            // 
            // mnuFilePrint
            //
            mnuFilePrint.Name = "mnuFilePrint";
            mnuFilePrint.Size = new System.Drawing.Size(152, 12);
            mnuFilePrint.Text = "Print ...";
            // 
            // mnuFileExtra0
            // 
            mnuFileExtra0.Name = "mnuFileExtra0";
            mnuFileExtra0.Size = new System.Drawing.Size(152, 12);
            mnuFileExtra0.Text = "Extra 0";
            // 
            // mnuFileExtra1
            // 
            mnuFileExtra1.Name = "mnuFileExtra1";
            mnuFileExtra1.Size = new System.Drawing.Size(152, 12);
            mnuFileExtra1.Text = "Extra 1";
            // 
            // mnuFileExtra2
            // 
            mnuFileExtra2.Name = "mnuFileExtra2";
            mnuFileExtra2.Size = new System.Drawing.Size(152, 12);
            mnuFileExtra2.Text = "Extra 2";
            // 
            // mnuFileExtra3
            // 
            mnuFileExtra3.Name = "mnuFileExtra3";
            mnuFileExtra3.Size = new System.Drawing.Size(152, 12);
            mnuFileExtra3.Text = "Extra 3";
            // 
            // mnuFileExtra4
            // 
            mnuFileExtra4.Name = "mnuFileExtra4";
            mnuFileExtra4.Size = new System.Drawing.Size(152, 12);
            mnuFileExtra4.Text = "Extra 4";
            // 
            // mnuFileExit
            // 
            mnuFileExit.Name = "mnuFileExit";
            mnuFileExit.Size = new System.Drawing.Size(152, 12);
            mnuFileExit.Text = "&Exit";
            mnuFileExit.Click += new EventHandler(mnuFileExit_Click);

            // --- end menu File ------------------------------------
            // --- menu Help ----------------------------------------
            // 
            // mnuHelpindex
            // 
            mnuHelpIndex.Name = "mnuHelpIndex";
            mnuHelpIndex.Size = new System.Drawing.Size(152, 12);
            mnuHelpIndex.Text = "&Index";
            mnuHelpIndex.Click += new EventHandler(mnuHelpIndex_Click);
            // 
            // mnuHelpAbout
            // 
            mnuHelpAbout.Name = "mnuHelpAbout";
            mnuHelpAbout.Size = new System.Drawing.Size(152, 12);
            mnuHelpAbout.Text = "&About";
            mnuHelpAbout.Click += new EventHandler(mnuHelpAbout_Click);

            // --- end menu Help ------------------------------------

            //
            // lblSVG
            //
            lblSVG.Height = 18;
            lblSVG.BackColor = this.BackColor;
            lblSVG.BorderStyle = BorderStyle.None;
            lblSVG.Font = new Font("Verdana", 9.0F);
            lblSVG.TextAlign = ContentAlignment.MiddleCenter;
            lblSVG.Text = "SVG     ";
            // 
            // txtBoxSVG
            // 
            txtBoxSVG.BorderStyle = BorderStyle.None;
            txtBoxSVG.Font = new Font("Courier New", 10.0F,
                System.Drawing.FontStyle.Regular,
                System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            txtBoxSVG.Location = new Point(8, 24);
            txtBoxSVG.Dock = DockStyle.Fill;
            txtBoxSVG.Multiline = true;
            txtBoxSVG.Name = "txtBoxSVG";
            txtBoxSVG.ScrollBars = ScrollBars.Vertical;
            txtBoxSVG.Size = new Size(300, 216);
            txtBoxSVG.TabIndex = 0;
            //
            // panSVG
            //
            panSVG.BorderStyle = BorderStyle.None;
            panSVG.BackColor = Color.White;
            panSVG.Padding = new Padding(10, 8, 0, 8);      // Margins for textbox.
            panSVG.Paint += new PaintEventHandler(panSVG_Paint);
            panSVG.Controls.Add(txtBoxSVG);

            //
            // lblXAM
            //
            lblXAM.Height = 18;
            lblXAM.BackColor = this.BackColor;
            lblXAM.BorderStyle = BorderStyle.None;
            lblXAM.Font = new Font("Verdana", 9.0F);
            lblXAM.TextAlign = ContentAlignment.MiddleCenter;
            lblXAM.Text = "XAML     ";
            // 
            // txtBoxXAM
            // 
            txtBoxXAM.BorderStyle = BorderStyle.None;
            txtBoxXAM.Font = new Font("Courier New", 10.0F,
                System.Drawing.FontStyle.Regular,
                System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            txtBoxXAM.Location = new Point(8, 24);
            txtBoxXAM.Dock = DockStyle.Fill;
            txtBoxXAM.Multiline = true;
            txtBoxXAM.Name = "txtBoxXAM";
            txtBoxXAM.ScrollBars = ScrollBars.Vertical;
            txtBoxXAM.Size = new Size(300, 216);
            txtBoxXAM.TabIndex = 0;
            //
            // panXAM
            //
            panXAM.BorderStyle = BorderStyle.None;
            panXAM.BackColor = Color.White;
            panXAM.Padding = new Padding(10, 8, 0, 8);      // Margins for textbox.
            panXAM.Paint += new PaintEventHandler(panXAM_Paint);
            panXAM.Controls.Add(txtBoxXAM);


            // This Form.
            this.Controls.Add(mnuMainStrip);
            this.Controls.Add(lblSVG);
            this.Controls.Add(panSVG);
            this.Controls.Add(lblXAM);
            this.Controls.Add(panXAM);
            this.Width = 600;
            this.Height = 600;
            this.Text = "    " + APP_NAME;
            this.ShowIcon = false;
            this.Resize += new EventHandler(Form1_Resize);
            this.FormClosing += new FormClosingEventHandler(Form1_FormClosing);
            this.Shown += new EventHandler(Form1_Shown);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Paint += new PaintEventHandler(Form1_Paint);

            this.ResumeLayout(false);
            this.PerformLayout();

            // Inits.
            mnuMainStrip.BackColor = this.BackColor;
            mnuFilePageSetup.Visible = false;
            mnuFilePreview.Visible = false;
            mnuFilePrint.Visible = false;
            mnuFileSep02.Visible = false;
            mnuFileExtra0.Visible = false;
            mnuFileExtra1.Visible = false;
            mnuFileExtra2.Visible = false;
            mnuFileExtra3.Visible = false;
            mnuFileExtra4.Visible = false;
            mnuFileSep03.Visible = false;

            mnuFileNew.Enabled = false;
            mnuFileOpen.Enabled = true;
            mnuFileSave.Enabled = false;
            mnuFileSaveAs.Enabled = false;
            mnuFileExit.Enabled = true;

            // Stylesheet.
            sFilNameOpenXSL = File_AppPath_2() + @"\svg2xaml.xsl";
        }

        

        private void Form1_Shown(object sender, EventArgs e)
        {
             Resize_Me();           
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //..
        }


        // When form is resized.
        private void Form1_Resize(object sender, EventArgs e)
        {
            Resize_Me();
        }


        private void Resize_Me()
        {
            if (this.WindowState != FormWindowState.Minimized)
            {
                int iB = 6;
                int iW = (int)((this.ClientSize.Width - (3 * iB)) / 2);
                int iH = this.ClientSize.Height - (mnuMainStrip.Height + lblSVG.Height + (2 * iB));

                lblSVG.Top = mnuMainStrip.Height + 1;
                lblSVG.Width = iW;
                lblSVG.Left = iB;

                panSVG.Top = mnuMainStrip.Height + lblSVG.Height + 2;
                panSVG.Left = iB;
                panSVG.Width = iW;
                panSVG.Height = iH;

                lblXAM.Top = mnuMainStrip.Height + 1;
                lblXAM.Width = iW;
                lblXAM.Left = iB + panSVG.Width + iB;

                panXAM.Top = mnuMainStrip.Height + lblXAM.Height + 2;
                panXAM.Left = iB + panSVG.Width + iB;
                panXAM.Width = iW;
                panXAM.Height = iH;
            }
        }


        // Draw borders for textboxes.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            int iXB;
            int iYB;
            int iWB;
            int iHB;

            Graphics g = this.CreateGraphics();
            Color backColor = Color.FromArgb(212, 208, 200);
            g.Clear(backColor);
            Pen oPen = new Pen(Brushes.DarkGray);

            iXB = panSVG.Left - 1;
            iYB = panSVG.Top - 1;
            iWB = panSVG.Width + 1;
            iHB = panSVG.Height + 1;
            g.DrawRectangle(oPen, new Rectangle(iXB, iYB, iWB, iHB));

            iXB = panXAM.Left - 1;
            iYB = panXAM.Top - 1;
            iWB = panXAM.Width + 1;
            iHB = panXAM.Height + 1;
            g.DrawRectangle(oPen, new Rectangle(iXB, iYB, iWB, iHB));

            g.Dispose();

        }

        // Draw background for slider.
        private void panSVG_Paint(object sender, PaintEventArgs e)
        {
            int iBL = 8;
            Pen oPen = new Pen(Brushes.Gainsboro, 16.0F);
            Graphics g2 = panSVG.CreateGraphics();
            g2.Clear(Color.White);
            g2.DrawLine(oPen, panSVG.Width - iBL, 0, panSVG.Width - iBL, panSVG.Height);
            g2.Dispose();
        }


        // Draw background for slider.
        private void panXAM_Paint(object sender, PaintEventArgs e)
        {
            int iBL = 8;
            Pen oPen = new Pen(Brushes.Gainsboro, 16.0F);
            Graphics g2 = panXAM.CreateGraphics();
            g2.Clear(Color.White);
            g2.DrawLine(oPen, panXAM.Width - iBL, 0, panXAM.Width - iBL, panSVG.Height);
            g2.Dispose();
        }


        // Menu File | New.        
        private void mnuFileNew_Click(object sender, EventArgs e)
        {
            txtBoxSVG.Text = "";
            txtBoxXAM.Text = "";
            this.Text = "    " + APP_NAME;

            mnuFileNew.Enabled = false;
            mnuFileOpen.Enabled = true;
            mnuFileSave.Enabled = false;
            mnuFileSaveAs.Enabled = false;
            mnuFileExit.Enabled = true;
        }


        // Menu File | Open.
        private void mnuFileOpen_Click(object sender, EventArgs e)
        {
            DialogResult OpenResult;   // DialogResult Enumeration.

            if (sDirNameOpenSVG != "")
            {
                OpenFileDialog1.InitialDirectory = sDirNameOpenSVG;
            }
            else
            {
                OpenFileDialog1.InitialDirectory = "";
            }
            OpenFileDialog1.Title = " Open SVG";
            OpenFileDialog1.Multiselect = false;
            OpenFileDialog1.Filter = "SVG (*.svg)|*.svg";
            OpenFileDialog1.FilterIndex = 1;
            OpenFileDialog1.FileName = sFilNameOpenSVG;

            OpenResult = OpenFileDialog1.ShowDialog();    // Returns DialogResult Enumeration value.
            switch (OpenResult)
            {
                case System.Windows.Forms.DialogResult.Cancel:
                    // MsgBox("Cancel button used")        ' Also when [x] button is used.
                    break;
                case System.Windows.Forms.DialogResult.OK:
                    // Remember filename and directory.
                    sFilNameOpenSVG = OpenFileDialog1.FileName;
                    FileInfo fi = new FileInfo(sFilNameOpenSVG);
                    sDirNameOpenSVG = fi.DirectoryName;
                    // Make XAML filename.
                    sFilNameSaveXAM = sFilNameOpenSVG;
                    sFilNameSaveXAM = Path.ChangeExtension(sFilNameSaveXAM, ".xaml");
                    sDirNameSaveXAM = sDirNameOpenSVG;

                    // Show SVG input.
                    txtBoxSVG.Text = File.ReadAllText(sFilNameOpenSVG);
                    txtBoxSVG.SelectionLength = 0;
                    txtBoxSVG.SelectionStart = 0;

                    // Caption.
                    this.Text = "    " + APP_NAME + "  -  " + fi.Name;

                    mnuFileNew.Enabled = true;
                    mnuFileOpen.Enabled = true;
                    mnuFileSave.Enabled = true;
                    mnuFileSaveAs.Enabled = true;
                    mnuFileExit.Enabled = true;

                    break;
            }	// end switch.
        }


        // Menu File | Save (.xaml).
        private void mnuFileSave_Click(object sender, EventArgs e)
        {
            if (File.Exists(sFilNameOpenSVG))
            {
                // Transform and save.
                SaveXAML(sFilNameSaveXAM);

                mnuFileNew.Enabled = true;
                mnuFileOpen.Enabled = true;
                mnuFileSave.Enabled = true;
                mnuFileSaveAs.Enabled = true;
                mnuFileExit.Enabled = true;
            }
        }


        // Menu File | Save As (.xaml).
        private void mnuFileSaveAs_Click(object sender, EventArgs e)
        {
            DialogResult SaveResult;

            if (Directory.Exists(sDirNameSaveXAM))
            {
                SaveFileDialog1.InitialDirectory = sDirNameSaveXAM;
            }
            else
            {
                SaveFileDialog1.InitialDirectory = "";
            }
            SaveFileDialog1.Title = " Save XAML";
            SaveFileDialog1.Filter = "XAML (*.xaml)|*.xaml";
            SaveFileDialog1.FilterIndex = 1;
            SaveFileDialog1.FileName = sFilNameSaveXAM;

            SaveResult = SaveFileDialog1.ShowDialog();
            switch (SaveResult)
            {
                case System.Windows.Forms.DialogResult.Cancel:
                    // MsgBox("Cancel button used")    ' Also when [x] button is used.
                    break;
                case System.Windows.Forms.DialogResult.OK:
                    // Remember filenames and directories.
                    sFilNameSaveXAM = SaveFileDialog1.FileName;
                    FileInfo fi = new FileInfo(sFilNameSaveXAM);
                    sDirNameSaveXAM = fi.DirectoryName;

                    // Transform and save.
                    SaveXAML(sFilNameSaveXAM);

                    mnuFileNew.Enabled = true;
                    mnuFileOpen.Enabled = true;
                    mnuFileSave.Enabled = true;
                    mnuFileSaveAs.Enabled = true;
                    mnuFileExit.Enabled = true;

                    break;
            }
        }


        // Transform SVG to XAML and save.
        private void SaveXAML(string sFileName_xaml)
        {
            // Transform and save.
            string sRet = XSLT_Transform(sFilNameOpenSVG, sFilNameOpenXSL, sFilNameSaveXAM);

            // Show XAML output.
            if (sRet.Length == 0)
            {
                if (File.Exists(sFilNameSaveXAM) == true)
                {
                    txtBoxXAM.Text = File.ReadAllText(sFilNameSaveXAM);

                    txtBoxSVG.SelectionLength = 0;
                    txtBoxSVG.SelectionStart = txtBoxXAM.Text.Length;
                }
                else
                {
                    txtBoxXAM.Text = "Output file not found.";
                }
            }
            else
            {
                // Show error description.
                txtBoxXAM.Text = sRet;
            }
        }


        // Menu File | Exit.
        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        // Menu Help | Index.
        private void mnuHelpIndex_Click(object sender, EventArgs e)
        {
            // ...
            string r = "\t\n";
            string s = r;

            s += r;
            s += "1] Open an SVG file with File | Open (.svg)." + r;
            s += "2] Convert SVG file to XAML with File | Save, with the same name (.xaml)."  + r;
            s += "The file is saved in the same directory as the SVG file." + r;
            s += "3] Convert SVG file to XAML with File | Save As, with another name (.xaml)." + r;
            s += r;
            s += " Converts SVG from the selected (opened) file, not from the text in the UI.";
            MessageBox.Show(s, "    Help - SVG to XAML");
        }


        // Menu Help | About.
        private void mnuHelpAbout_Click(object sender, EventArgs e)
        {
            string r = "\t\n";
            string s = r;

            s += APP_NAME + " v" + APP_BUILD + "." + r;
            s += "SVG to XAML conversion with XSLT." + r;
            s += "Uses stylesheet svg2xaml.xsl from Toine de Greef." + r;
            s += "See also Inkscape, http://www.inkscape.org/." + r;
            s += "(c) BBIM 2009" + r;
            MessageBox.Show(s, "    About");
        }


        // === Converter ==============================================================


        // ---------------------------------------------------------------
        // Date      030409
        // Purpose   Transform an XML document with XSLT.
        // Entry     sFileName_xml - The XML datafile.
        //           sFileName_xsl - The XSL style sheet.
        //           sFileName_out - The result of the transformation.
        // Return    An empty string if successful, else an error description.
        // Comments  The output file is directly saved to disk.
        //           Source:
        //           D:\PC3000_Info_Base\My_Website\Website_NET2971_016_2
        //             \Standards\Standard_XSLT.htm. Modified.
        // ---------------------------------------------------------------
        private string XSLT_Transform(string sFileName_xml,
                                      string sFileName_xsl,
                                      string sFileName_out)
        {
            try
            {
                // Enable support for XSLT 'document()' function.
                XsltSettings settings = new XsltSettings(true, true);
                // Alternative:
                // settings.EnableDocumentFunction = true;     

                // Load the style sheet.
                XslCompiledTransform xslt = new XslCompiledTransform();
                xslt.Load(sFileName_xsl, settings, new XmlUrlResolver());
                // Execute the transform and output the results to a file.
                xslt.Transform(sFileName_xml, sFileName_out);

                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }


        // Not tested, not used.
        // Allow DTD in source file.
        private string XSLT_Transform_2(string sFileName_xml,
                                        string sFileName_xsl,
                                        string sFileName_out)
        {
            try
            {
                // Enable support for XSLT 'document()' function.
                XsltSettings set1 = new XsltSettings(true, true);

                // Allow DTD.
                XmlReaderSettings set2 = new XmlReaderSettings();
                set2.ProhibitDtd = false;

                // Load the style sheet.
                XslCompiledTransform xslt = new XslCompiledTransform();
                xslt.Load(XmlReader.Create(sFileName_xml, set2), set1, new XmlUrlResolver());

                // Execute the transform and output the results to a file.
                xslt.Transform(sFileName_xml, sFileName_out);

                return "";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }


        // ---------------------------------------------------------------
        // Date      090509
        // Purpose   Get text from a file.
        // Entry     sFileName - The textfile to open.
        // Return    The text from the file.
        // Comments  
        // ---------------------------------------------------------------
        private string File_ReadAllText(string sFileName)
        {
            string sText = "";
            if (File.Exists(sFileName) == true)
            {
                sText = File.ReadAllText(sFileName);
            }
            return sText;
        }


        // ---------------------------------------------------------------
        // Date      070806
        // Purpose   Get application path.
        // Entry     None
        // Return    The application path, where the .exe is (no trailing "\").
        //           If not successful, an empty string ("").
        // Comments  Returns full path ...\root\bin\debug. 
        // ---------------------------------------------------------------
        private string File_AppPath_2()
        {
            DirectoryInfo di;
            string sAppFilName;    // Filename of the application .exe.
            string sAppPath;

            try
            {
                sAppFilName = System.Reflection.Assembly.GetExecutingAssembly().Location;
                di = Directory.GetParent(sAppFilName);
                sAppPath = di.FullName;
                return sAppPath;
            }
            catch
            {
                return "";
            }
        }


        // === end Converter ==========================================================


    }   // end class
}       // end namespace
