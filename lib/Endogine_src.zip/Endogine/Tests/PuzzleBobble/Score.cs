using System;

namespace PuzzleBobble
{
	/// <summary>
	/// Summary description for Score.
	/// </summary>
	public class Score
	{
		public Score()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
