using System;
using System.Collections.Generic;
using System.Text;

namespace Endogine.Editors
{
    public interface IPicRefTool : IEditorForm
    {
    }
}
