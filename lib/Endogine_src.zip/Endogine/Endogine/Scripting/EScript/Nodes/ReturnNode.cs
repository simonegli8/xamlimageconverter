using System;

namespace Endogine.Scripting.EScript.Nodes
{
	/// <summary>
	/// Summary description for ReturnNode.
	/// </summary>
	public class ReturnNode : BaseNode
	{
		public ReturnNode()
		{
		}

//		protected override object _Execute()
//		{
//			if (this.ChildNodes.Count == 0)
//				return null;
//			ExpressionNode node = (ExpressionNode)this.ChildNodes.GetByIndex(0);
//			return node.Execute();
//		}
	}
}
