using System;

namespace Endogine.Scripting.EScript.Nodes
{
	/// <summary>
	/// //TODO: move stuff from Functions.cs to here!
	/// </summary>
	public class GlobalNode : BaseNode
	{
		public GlobalNode()
		{
		}
	}
}
