using System;

namespace Endogine.Scripting.EScript.Types
{
	/// <summary>
	/// Summary description for Int.
	/// </summary>
	public class Int : Number
	{
		public Int(int i)
		{
			this.m_value = i;
		}
	}
}
