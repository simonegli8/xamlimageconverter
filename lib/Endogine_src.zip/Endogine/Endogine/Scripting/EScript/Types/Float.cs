using System;

namespace Endogine.Scripting.EScript.Types
{
	/// <summary>
	/// Summary description for FSDouble.
	/// </summary>
	public class Float : Number
	{

		public Float(float f)
		{
			this.m_value = f;
		}
	}
}
