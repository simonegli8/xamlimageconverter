using System;

namespace Endogine.ParticleSystem
{
	/// <summary>
	/// Summary description for ParticleFactory.
	/// </summary>
	public class ParticleFactory
	{
		public ParticleFactory()
		{
		}

//		public Sprite CreateParticle()
//		{
//			//TODO: a particle can be any object derived from Sprite; a button, a custom one
//			//the particle-system-specific stuff (velocity, movement etc) could be in a Behavior,
//			//or maybe a particle is a class which creates it's own sprite?
//
//			//anyway, we might not always want a standard sprite/particle,
//			//we need a factory that creates the kind of object we want
//		}
	}
}
