using System;

namespace Endogine.Serialization
{
	/// <summary>
	/// Summary description for Director.
	/// </summary>
	public class Director
	{
		public Director()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
