//using System;
//
//namespace Endogine.Serialization.Flash.Style.FillStyle
//{
//	/// <summary>
//	/// Summary description for Base.
//	/// </summary>
//	public class Base
//	{
//		public Base()
//		{
//		}
//	}
//}
