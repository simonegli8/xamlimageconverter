using System;

namespace Endogine.Serialization.Flash.Action
{
	/// <summary>
	/// Summary description for Action.
	/// </summary>
	public class Action
	{
		public Action()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
