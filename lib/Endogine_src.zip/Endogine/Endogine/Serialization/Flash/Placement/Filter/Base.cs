using System;

namespace Endogine.Serialization.Flash.Placement.Filter
{
	/// <summary>
	/// Summary description for Base.
	/// </summary>
	public class Base
	{
		public Base()
		{
		}
	}
}
