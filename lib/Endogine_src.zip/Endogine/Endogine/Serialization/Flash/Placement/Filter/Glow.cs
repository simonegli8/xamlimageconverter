using System;

namespace Endogine.Serialization.Flash.Placement.Filter
{
	/// <summary>
	/// Summary description for Glow.
	/// </summary>
	public class Glow : Base
	{
		public Glow()
		{
			// 15 bytes
		}
	}
}
