using System;

namespace Endogine.Serialization.Flash.Placement.Filter
{
	/// <summary>
	/// Summary description for AdjustColor.
	/// </summary>
	public class AdjustColor : Base
	{
		public AdjustColor()
		{
			// 80 bytes
		}
	}
}
