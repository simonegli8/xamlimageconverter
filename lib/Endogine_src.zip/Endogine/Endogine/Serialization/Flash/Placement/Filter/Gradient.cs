using System;

namespace Endogine.Serialization.Flash.Placement.Filter
{
	/// <summary>
	/// Summary description for Gradient.
	/// </summary>
	public class Gradient : Base
	{
		public Gradient()
		{
			byte numColors = 0;
			for (int i=0; i<numColors; i++)
			{
				//ReadRGBA(); gradientPosition = ReadByte();
			}
			//19 bytes more
		}
	}
}
