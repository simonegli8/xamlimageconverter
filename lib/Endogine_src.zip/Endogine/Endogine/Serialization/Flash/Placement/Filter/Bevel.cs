using System;

namespace Endogine.Serialization.Flash.Placement.Filter
{
	/// <summary>
	/// Summary description for Bevel.
	/// </summary>
	public class Bevel : Base
	{
		public Bevel()
		{
			// 27 bytes
		}
	}
}
