using System;

namespace Endogine.Serialization.Flash.Placement.Filter
{
	/// <summary>
	/// Summary description for Blue.
	/// </summary>
	public class Blue : Base
	{
		public Blue()
		{
			// 9 bytes
		}
	}
}
