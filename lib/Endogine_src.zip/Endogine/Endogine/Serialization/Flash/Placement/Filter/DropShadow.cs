using System;

namespace Endogine.Serialization.Flash.Placement.Filter
{
	/// <summary>
	/// Summary description for DropShadow.
	/// </summary>
	public class DropShadow : Base
	{
		public DropShadow()
		{
			//23 bytes of data 
		}
	}
}
