using System;

namespace Endogine.Serialization.Flash.Placement.Filter
{
	/// <summary>
	/// Summary description for GradientGlow.
	/// </summary>
	public class GradientGlow : Gradient
	{
		public GradientGlow()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
