using System;

namespace Endogine.Serialization.Flash.Placement.Filter
{
	/// <summary>
	/// Summary description for GradientBevel.
	/// </summary>
	public class GradientBevel : Gradient
	{
		public GradientBevel()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
