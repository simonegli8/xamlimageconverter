using System;

namespace Endogine.Serialization.Flash.Text
{
	/// <summary>
	/// Summary description for Text.
	/// </summary>
	public class Text : Record
	{
		public Text()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
