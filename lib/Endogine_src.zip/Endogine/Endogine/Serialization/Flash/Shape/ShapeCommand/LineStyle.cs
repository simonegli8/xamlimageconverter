using System;

namespace Endogine.Serialization.Flash.Shape.ShapeCommand
{
	/// <summary>
	/// Summary description for LineStyle.
	/// </summary>
	public class LineStyle : Style
	{
		public LineStyle(int nStyle) : base(nStyle)
		{
		}
	}
}
