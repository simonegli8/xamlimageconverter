using System;
using System.Collections.Generic;
using System.Text;

namespace Endogine.Interpolation
{
    public class InterpolatorNDimensions
    {
        public InterpolatorNDimensions()
        {
        }

        public void Add(Animation.AnimationKey key)
        {
        }
    }
}
