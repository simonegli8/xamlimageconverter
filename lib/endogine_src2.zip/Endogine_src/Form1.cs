using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Endogine;
using ThisMovie;

namespace EndoTest01
{
	/// <summary>
	/// http://www.amanith.org/blog/index.php
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.ComponentModel.IContainer components;

		private EndogineHub m_endogine;
		private Movie thisMovie;
		private System.Windows.Forms.ToolBar toolBar1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.ToolBarButton tbBtnSpriteEdit;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.MenuItem miOnlineSpriteEdit;
		private MainBase m_formStage = null;

		public Form1()
		{
			InitializeComponent();

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (thisMovie!=null)
					thisMovie.Dispose();
				if (m_endogine!=null)
					m_endogine.Dispose();

				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
			this.toolBar1 = new System.Windows.Forms.ToolBar();
			this.tbBtnSpriteEdit = new System.Windows.Forms.ToolBarButton();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.miOnlineSpriteEdit = new System.Windows.Forms.MenuItem();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.SuspendLayout();
			// 
			// toolBar1
			// 
			this.toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						this.tbBtnSpriteEdit});
			this.toolBar1.DropDownArrows = true;
			this.toolBar1.Location = new System.Drawing.Point(0, 0);
			this.toolBar1.Name = "toolBar1";
			this.toolBar1.ShowToolTips = true;
			this.toolBar1.Size = new System.Drawing.Size(176, 28);
			this.toolBar1.TabIndex = 0;
			// 
			// tbBtnSpriteEdit
			// 
			this.tbBtnSpriteEdit.Pushed = ((bool)(configurationAppSettings.GetValue("tbBtnSpriteEdit.Pushed", typeof(bool))));
			this.tbBtnSpriteEdit.ToolTipText = "Sprite edit mode";
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.miOnlineSpriteEdit});
			this.menuItem1.Text = "Edit";
			// 
			// miOnlineSpriteEdit
			// 
			this.miOnlineSpriteEdit.Index = 0;
			this.miOnlineSpriteEdit.Text = "Onscreen sprite edit";
			this.miOnlineSpriteEdit.Click += new System.EventHandler(this.miOnlineSpriteEdit_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(176, 149);
			this.Controls.Add(this.toolBar1);
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Endogine";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}


		protected override void OnKeyDown(System.Windows.Forms.KeyEventArgs e) 
		{
			if (e.KeyCode == Keys.Escape) 
			{
				this.Close();
				return;
			}
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			m_endogine = new EndogineHub(Application.ExecutablePath);

			string[] aAvailableStrategies = new string[]{Enum.GetName(typeof(EndogineHub.RenderStrategy), 0), Enum.GetName(typeof(EndogineHub.RenderStrategy), 2)};
			SetupWindow wndSetup = new SetupWindow(aAvailableStrategies, this);
			wndSetup.ShowDialog();

			m_formStage = new ThisMovie.Main();
			
			Form formMdiParent = (Form)null;
			if (IsMdiContainer)
			{
				this.Width = 640;
				this.Height = 480;
				this.WindowState = FormWindowState.Maximized;
				formMdiParent = this;
				m_formStage.MdiParent = this;
			}
			else
			{
				this.Visible = false; // this doesn't work
				this.Text = "Should be invisible!";
			}
			//TODO: anyhow, it's strange to use a Form to start from, the project should probably be a console application.

			m_formStage.Show();

			m_endogine.Init(m_formStage, formMdiParent);

			thisMovie = new Movie(m_endogine);
			m_endogine.Movie = thisMovie;
		}

		private void miOnlineSpriteEdit_Click(object sender, System.EventArgs e)
		{
			((MenuItem)sender).Checked = !((MenuItem)sender).Checked;
			m_endogine.OnScreenEdit = ((MenuItem)sender).Checked;
		}
	}
}
