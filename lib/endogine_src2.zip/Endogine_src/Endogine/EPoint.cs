using System;
using System.Drawing;

namespace Endogine
{
	/// <summary>
	/// Summary description for EPointF.
	/// </summary>
	public class EPoint
	{
		public int X = 0;
		public int Y = 0;

		public EPoint()
		{
		}
		public EPoint(float x, float y)
		{
			X = (int)x;
			Y = (int)y;
		}
		public EPoint(int x, int y)
		{
			X = x;
			Y = y;
		}
		public EPoint(PointF pnt)
		{
			X = (int)pnt.X;
			Y = (int)pnt.Y;
		}
		public EPoint(Point pnt)
		{
			X = pnt.X;
			Y = pnt.Y;
		}
		public EPoint Copy()
		{
			return new EPoint(X,Y);
		}


		public EPointF ToEPointF()
		{
			return new EPointF(X,Y);
		}
		public PointF ToPointF()
		{
			return new PointF(X,Y);
		}
		public Point ToPoint()
		{
			return new Point(X,Y);
		}
		public SizeF ToSizeF()
		{
			return new SizeF(X,Y);
		}
		public Size ToSize()
		{
			return new Size(X,Y);
		}


		public static EPoint operator -(EPoint p1, EPoint p2)
		{
			return new EPoint(p1.X-p2.X, p1.Y-p2.Y);
		}
		public static EPoint operator +(EPoint p1, EPoint p2)
		{
			return new EPoint(p1.X+p2.X, p1.Y+p2.Y);
		}
		public static EPoint operator *(EPoint p1, EPoint p2)
		{
			return new EPoint(p1.X*p2.X, p1.Y*p2.Y);
		}
		public static EPoint operator *(EPoint p1, int i)
		{
			return new EPoint(p1.X*i, p1.Y*i);
		}
		public static EPoint operator /(EPoint p1, EPoint p2)
		{
			return new EPoint(p1.X/p2.X, p1.Y/p2.Y);
		}
		public static EPoint operator /(EPoint p1, int i)
		{
			return new EPoint(p1.X/i, p1.Y/i);
		}

		public override bool Equals(object obj)
		{
			EPoint pnt = (EPoint)obj;
			return (pnt.X == X && pnt.Y == Y);
		}
		public override string ToString()
		{
			return "x="+X.ToString()+";y="+Y.ToString();
		}
	}
}
