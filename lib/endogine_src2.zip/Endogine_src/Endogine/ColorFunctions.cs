using System;
using System.Drawing;
using System.Collections;

namespace Endogine
{
	/// <summary>
	/// Summary description for ColorFunctions.
	/// </summary>
	public class ColorFunctions
	{
		public ColorFunctions()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public static float[] RGB2HSB(Color a_clr)
		{
			float[] hsb = new float[3];
			hsb[0] = a_clr.GetHue();
			hsb[1] = a_clr.GetSaturation();
			hsb[2] = a_clr.GetBrightness();
			return hsb;
		}

/*		void convRGB2HSB (const unsigned char rgbR, const unsigned char rgbG, const unsigned char rgbB,
				  unsigned int &hsbH, unsigned char &hsbS, unsigned char &hsbB)
{
	unsigned char bMax, bMin, bDelta;
	bMax = rgbR>rgbG?(rgbR>rgbB?rgbR:rgbB):(rgbG>rgbB?rgbG:rgbB);
	bMin = rgbR<rgbG?(rgbR<rgbB?rgbR:rgbB):(rgbG<rgbB?rgbG:rgbB);
	bDelta = bMax - bMin;
	
	hsbB = (unsigned char)((unsigned int)bMax * 100 / 255);
	
	if (bMax > 0) {
		hsbS = (unsigned char)((unsigned int)bDelta * 100 / bMax);
		if (bDelta > 0) {
			if (bMax == rgbR) hsbH = 60*(100*(rgbG - rgbB) / bDelta) / 100;
			else if (bMax == rgbG) hsbH = 60*(200 + 100*(rgbB - rgbR) / bDelta) / 100;
			else hsbH = 60*(400 + 100*(rgbR - rgbG) / bDelta) / 100;

			if (hsbH < 0) hsbH = hsbH + 360;
		}
	}
}*/

public static Color HSB2RGB(float[] hsb)
{
	if (hsb[1] > 0) {
		float fH, fS, fB;
		fH = hsb[0] / 60.0f;
		fS = hsb[1] / 100.0f;
		fB = hsb[2] / 100.0f;

		uint nH = (uint)fH;
		float fF, fP, fQ, fT;
		fF = fH - (float)nH;

		fP = fB * (1.0f - fS);
		fQ = fB * (1.0f - fS * fF);
		fT = fB * (1.0f - fS * (1.0f - fF));

		int r,g,b;
		r = g = b = 0;
		switch (nH)
		{
			case 0: r = (int)(255.0f*fB); g = (int)(255.0f*fT); b = (int)(255.0f*fP); break;
			case 1: r = (int)(255.0f*fQ); g = (int)(255.0f*fB); b = (int)(255.0f*fP); break;
			case 2: r = (int)(255.0f*fP); g = (int)(255.0f*fB); b = (int)(255.0f*fT); break;
			case 3: r = (int)(255.0f*fP); g = (int)(255.0f*fQ); b = (int)(255.0f*fB); break;
			case 4: r = (int)(255.0f*fT); g = (int)(255.0f*fP); b = (int)(255.0f*fB); break;
			case 5: r = (int)(255.0f*fB); g = (int)(255.0f*fP); b = (int)(255.0f*fQ); break;
		}
		return Color.FromArgb(r,g,b);
	}
	else {
		int nGray = (int)(hsb[2] * 255 / 100);
		return Color.FromArgb(nGray,nGray,nGray);
	}
}
/*		public static Color HSB2RGB(float[] hsb)
		{
			//int[] aPos = new int[] {-1,-1,-1};
			ArrayList aPos = new ArrayList();
			aPos.Add(-1);
			aPos.Add(-1);
			aPos.Add(-1);

			float fMax = hsb[2]*255;
			float fMaxDiff = hsb[1]*fMax;
			float fMin = fMax-fMaxDiff;

			float fTmp = hsb[0]/120;
			int nTmp = (int)fTmp;
			float fTmpPart = fTmp-nTmp;

			if (nTmp == 3)
				nTmp = 0;

			aPos[nTmp] = 1;

			if (nTmp == 0)
				aPos[2] = 0;
			else
				aPos[nTmp-1] = 0;

			
			uint nClr = 0xff000000;
			int n;
			n = aPos.IndexOf(1);
			nClr+=(uint)(Math.Pow(2, n*8)*fMax);

			n = aPos.IndexOf(-1);
			nClr+=(uint)(Math.Pow(2, n*8)*fMin);

			n = aPos.IndexOf(0);
			nClr+=(uint)(Math.Pow(2, n*8)*(fMin + fTmpPart*2*fMaxDiff));

			return Color.FromArgb((int)nClr);
		}*/

		/*
on hsb2rgb hsb
  tmpPart = abs(tmpPart)*2
  rgb[posList.getPos(1)] = max
  rgb[posList.getPos(-1)] = min
  rgb[posList.getPos(0)] = min + tmpPart*maxDiff
end


on rgb2cmyk argRGB
  --cmyk vals 0-100
  C = 100 - 100 * argRGB[1] / 255
  M = 100 - 100 * argRGB[2] / 255
  Y = 100 - 100 * argRGB[3] / 255
  K = C
  if (M < K) then K = M
  if (Y < K) then K = Y
  C = C - K
  M = M - K
  Y = Y - K
  return [c,m,y,k]
end

on cmyk2rgb argCMYK
  R = 255 - integer(2.55 * (argCMYK[1] + argCMYK[4]))
  if R < 0 then R = 0
  G = 255 - integer(2.55 * (argCMYK[2] + argCMYK[4]))
  if G < 0 then G = 0
  B = 255 - integer(2.55 * (argCMYK[3] + argCMYK[4]))
  if B < 0 then B = 0
  return [r,g,b]
end

on hsb2rgb2 HSB
  H=hsb[1]
  S=hsb[2]
  L=hsb[3]
  If S > 0 then
    nH = H/60
    nL = L
    nS = S
    lH = nH.integer
    nF = nH - lH
    nP = nL * (1 - nS)
    nQ = nL * (1 - nS * nF)
    nT = nL * (1 - nS * (1 - nF))
    case lH of
      0:
        R = nL * 255
        G = nT * 255
        B = nP * 255
      1:
        R = nQ * 255
        G = nL * 255
        B = nP * 255
      2:
        R = nP * 255
        G = nL * 255
        B = nT * 255
      3:
        R = nP * 255
        G = nQ * 255
        B = nL * 255
      4:
        R = nT * 255
        G = nP * 255
        B = nL * 255
      5:
        R = nL * 255
        G = nP * 255
        B = nQ * 255
    end case
  Else
    R = (L * 255) / 100
    G = R
    B = R
  end if
  return [R, G, B]
end



on RGBToHSV(R, G, B)
  R=float(R)
  G=float(G)
  B=float(B)
  minVal=float(min(R, G, B))
  V=float(max(R, G, B))
  
  Delta=V-minVal
  
  -- Calculate saturation: saturation is 0 if r, g and b are all 0
  if V=0.0 then
    S=0.0
  else
    S=Delta / V
  end if
  
  if S=0.0 then
    H=0.0    -- Achromatic: When s = 0, h is undefined but who cares
  else       -- Chromatic
    if R<=V then -- between yellow and magenta [degrees]
      H=60.0*(G-B)/Delta
    else
      if G<=V then -- between cyan and yellow
        H=120.0+60.0*(B-R)/Delta
      else
        if B<=V then -- between magenta and cyan
          H=240.0+60.0*(R-G)/Delta
          if H<0.0 then H=H+360.0
        end if
      end if
    end if
  end if
  -- return a list of values as an rgb object would not be sensible
  return [h, s, v]
end RGBtoHSV

on HSVtoRGB(h, s, v)
  h=float(h)
  s=float(s)
  v=float(v)
  if S=0.0 then   -- color is on black-and-white center line
    R=V           -- achromatic: shades of gray
    G=V           -- supposedly invalid for h=0 when s=0 but who cares
    B=V
  else -- chromatic color
    if H=360.0 then  -- 360 degrees same as 0 degrees
      hTemp=0.0
    else
      hTemp=H
    end if
    
    hTemp=hTemp/60.0   -- h is now in [0,6)
    i=bitOr(hTemp, 0)  -- largest integer <= h
    f=hTemp-i          -- fractional part of h
    
    p=V*(1.0-S)
    q=V*(1.0-(S*f))
    t=V*(1.0-(S*(1.0-f)))
    
    case i of
      0:
        R = V
        G = t
        B = p
      1:
        R = q
        G = V
        B = p
      2:
        R = p
        G = V
        B = t
      3:
        R = p
        G = q
        B = V
      4:
        R = t
        G = p
        B = V
      5:
        R = V
        G = p
        B = q
    end case
  end if
  return rgb(R*255, G*255, B*255)
end


on labToRGB aLab
  --http://www.easyrgb.com/math.php
  paWhitePointPresets = [\
2:[\
#A:[109.850, 100.0, 35.585],\
#C:[98.074, 100.0, 118.232],\
#D50:[96.422, 100.0, 82.521],\
#D55:[95.682, 100.0, 92.149],\
#D65:[95.047, 100.0, 108.883],\
#D75:[94.972, 100.0, 122.638],\
  #F2:[99.187, 100.0, 67.395],\
#F7:[95.044, 100.0, 108.755],\
#F11:[100.966, 100.0, 64.370]],\
10:[\
#A:[111.144, 100.0, 35.200],\
#C:[97.285, 100.0, 116.145],\
#D50:[96.720, 100.0, 81.427],\
#D55:[95.799, 100.0, 90.926],\
#D65:[94.811, 100.0, 107.304],\
#D75:[94.416, 100.0, 120.641],\
#F2:[103.280, 100.0, 69.026],\
#F7:[95.792, 100.0, 107.687],\
#F11:[103.866, 100.0, 65.627]\
]]
  
  
  nAngle = 2
  sbObserver = #D65
  aWhitePoint = paWhitePointPresets.getaProp(nAngle)[sbObserver]
  
  aWhitePoint = aWhitePoint/100
  --Lab -> XYZ
  
  --L*[0..100]=w/100 a*[-128..127]=x/100  b*[-128..127]=y/100
  --don't now what the a&b input range should be... -100 - 100? 120 (as in Photoshop)? 128 as some docs say?
  repeat with n = 2 to 3
    aLab[n] = aLab[n]/120*100
  end repeat
  
  if (FALSE) then
    Y = (aLab[1] + 16) / 116
    X = aLab[2] / 500 + Y
    Z = Y - aLab[3] / 200
    
    y3 = Y*Y*Y
    x3 = X*X*X
    z3 = Z*Z*Z
    if (y3 > 0.008856) then Y = y3
    else Y = (Y - 16 / 116 ) / 7.787
    if (x3 > 0.008856) then X = x3
    else X = (X - 16 / 116 ) / 7.787
    if (z3 > 0.008856 ) then Z = z3
    else Z = (Z - 16 / 116 ) / 7.787
    
  else
    L = aLab[1]
    a = aLab[2]
    b = aLab[3]
    
    LF = (L+16)/116
    if (L >= 29.0*b/50 + 8) then Z = power(LF - b/200, 3)
    else Z = (108.0/841)*(LF - 4.0/29 - b/200)
    
    if (L >= 8 - 29.0*a/125) then X = power(a/500 + LF, 3)
    else X = (108.0/841)*(a/500 + LF - 4.0/29)
    
    if (L >= 8) then Y = power(LF, 3)
    else Y = 27.0*L/24389
  end if
  
  x = x*aWhitePoint[1]
  y = y*aWhitePoint[2]
  z = z*aWhitePoint[3]
  
  --p-ut "XYZ", X, Y, Z
  
  R =  3.063219*X -1.393326*Y -0.475801*Z
  G = -0.969245*X +1.875968*Y +0.041555*Z
  B =  0.067872*X -0.228833*Y +1.069251*Z
  
  --          aRGB = [r,g,b]
  --          repeat with n = 1 to 3
  --            aRGB[n] = aRGB[n]*
  --          end repeat
  nFact = 255--*1.3
  clr = rgb(max(R, 0)*nFact, max(G, 0)*nFact, max(B, 0)*nFact)
  
  return clr
  
  --          X = 0.430574*R + 0.341550*G + 0.178325*B
  --          Y = 0.222015*R + 0.706655*G + 0.071330*B
  --          Z = 0.020183*R + 0.129553*G + 0.939180*B
  
end
		 */
	}
}
