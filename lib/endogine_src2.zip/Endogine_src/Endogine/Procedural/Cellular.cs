using System;
using System.Drawing;

namespace Endogine.Procedural
{
	/// <summary>
	/// Summary description for NoiseMarble.
	/// </summary>
	public class Cellular : Noise
	{
		public Cellular()
		{
		}

		public override void WriteToBitmap(Bitmap a_bmp)
		{
			Random rnd = new Random();
			PrepareWriteBitmap(a_bmp);
			int[,] array1 = new int[a_bmp.Width, a_bmp.Height];
			int[,] array2 = new int[a_bmp.Width, a_bmp.Height];
			for(int x=0; x<a_bmp.Width; x++) 
			{
				for(int y=0; y<a_bmp.Height; y++) 
				{
					array1[x,y] = rnd.Next(255);
				}
			}

			double m_dRate = 0.1;

			for (int nStep = 0; nStep < 50; nStep++)
			{
				//' Run the cellular automata step:
				for(int x=0; x<a_bmp.Width; x++) 
				{
					for(int y=0; y<a_bmp.Height; y++) 
					{
						double dTot = 0;
						for(int iX=-1; iX<=1; iX++) 
						{
							int i = x + iX;
							int j = 0;
							if (i < 0)  i = a_bmp.Width-1;
							else if (i >= a_bmp.Width) i = 0;
							for(int iY=0; iY<=1; iY++) 
							{
								j = y + iY;
								if (j < 0) j = a_bmp.Height - 1;
								else if (j >= a_bmp.Height) j = 0;
								dTot+= array1[i,j];
							}
							dTot/= 9;
							dTot+= m_dRate;
							dTot = dTot - (int)dTot;
							array2[i, j] = (int)(dTot * 255.0);
						}
					}
				}
				int[,] arrayTmp;
				arrayTmp = array2;
				array2= array1;
				array1 = arrayTmp;
			}

			for(int x=0; x<a_bmp.Width; x++) 
			{
				for(int y=0; y<a_bmp.Height; y++) 
				{
					Color clr = (Color)m_aColorTable[array2[x,y]];
					a_bmp.SetPixel(x, y, clr);
				}
			}
		}
	}
}
