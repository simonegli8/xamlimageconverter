using System;
using System.Drawing;
using System.Collections;

namespace Endogine
{
	/// <summary>
	/// Summary description for Frame.
	/// </summary>
	public class Frame : Sprite
	{
		protected ArrayList m_aSprites;
		protected int m_nRemoveForInterpolation;

		public Frame()
		{
			this.m_bMeInvisibleButNotChildren = true;
			this.m_bNoScalingOnSetRect = true;
			Name = "Frame";

			m_aSprites = new ArrayList();

			for (int i = 0; i < 9; i++)
				m_aSprites.Add(new Sprite());
		}

		public override MemberSpriteBitmap Member
		{
			get
			{
				return base.Member;
			}
			set
			{
				base.Member = value;

				MemberSpriteBitmap mb = value;
				Rectangle rectOffset = new Rectangle(mb.Size.X/2-1,value.Size.Y/2-1,  -mb.Size.X/2+1,-mb.Size.Y/2+1);
				Rectangle rectMid = new Rectangle(rectOffset.Left, rectOffset.Top, mb.Size.X+rectOffset.Width, mb.Size.Y+rectOffset.Height);
				
				foreach (Sprite sp1 in m_aSprites)
				{
					sp1.Member = mb;
					sp1.Parent = this;
				}

				Sprite sp;

				EPoint pntTopBottom;

				EPoint pntMidRight = new EPoint(rectOffset.Left, mb.Size.X+rectOffset.Width);

				//unfortunately, GDI+ always interpolates when stretching, so remove last pixels on right/down:
				m_nRemoveForInterpolation = 1;
				int nRemove = m_nRemoveForInterpolation;

				//Top row:
				pntTopBottom = new EPoint(0,rectOffset.Top);
				sp = ((Sprite)m_aSprites[0]);
				sp.Name = "TopLeft";
				sp.SourceRect = ERectangle.FromLTRB(0,pntTopBottom.X, rectOffset.Left, pntTopBottom.Y);
				sp.RegPoint = sp.SourceRect.Location;
				
				sp = ((Sprite)m_aSprites[1]);
				sp.Name = "TopMid";
				sp.SourceRect = ERectangle.FromLTRB(pntMidRight.X,pntTopBottom.X , pntMidRight.Y-nRemove, pntTopBottom.Y);
				sp.RegPoint = sp.SourceRect.Location;

				sp = ((Sprite)m_aSprites[2]);
				sp.Name = "TopRight";
				sp.SourceRect = ERectangle.FromLTRB(pntMidRight.Y,pntTopBottom.X, mb.Size.X,pntTopBottom.Y);
				sp.RegPoint = sp.SourceRect.Location;

				//Middle row:
				pntTopBottom = new EPoint(rectOffset.Top,mb.Size.Y+rectOffset.Height);
				sp = ((Sprite)m_aSprites[3]);
				sp.Name = "MidLeft";
				sp.SourceRect = ERectangle.FromLTRB(0,pntTopBottom.X, rectOffset.Left,pntTopBottom.Y-nRemove);
				sp.RegPoint = sp.SourceRect.Location;

				sp = ((Sprite)m_aSprites[4]);
				sp.Name = "MidMid";
				sp.SourceRect = ERectangle.FromLTRB(pntMidRight.X,pntTopBottom.X, pntMidRight.Y-nRemove,pntTopBottom.Y-nRemove);
				sp.RegPoint = sp.SourceRect.Location;

				sp = ((Sprite)m_aSprites[5]);
				sp.Name = "MidRight";
				sp.SourceRect = ERectangle.FromLTRB(pntMidRight.Y,pntTopBottom.X, mb.Size.X,pntTopBottom.Y-nRemove);
				sp.RegPoint = sp.SourceRect.Location;

				//Bottom row:
				pntTopBottom = new EPoint(mb.Size.Y+rectOffset.Height, mb.Size.Y);
				sp = ((Sprite)m_aSprites[6]);
				sp.Name = "BottomLeft";
				sp.SourceRect = ERectangle.FromLTRB(0,pntTopBottom.X, pntMidRight.X,pntTopBottom.Y);
				sp.RegPoint = sp.SourceRect.Location;

				sp = ((Sprite)m_aSprites[7]);
				sp.Name = "BottomMid";
				sp.SourceRect = ERectangle.FromLTRB(pntMidRight.X,pntTopBottom.X, pntMidRight.Y-nRemove,pntTopBottom.Y);
				sp.RegPoint = sp.SourceRect.Location;
				
				sp = ((Sprite)m_aSprites[8]);
				sp.Name = "BottomRight";
				sp.SourceRect = ERectangle.FromLTRB(pntMidRight.Y,pntTopBottom.X, mb.Size.X,pntTopBottom.Y);
				sp.RegPoint = sp.SourceRect.Location;
			}
		}

		public override RasterOps.ROPs Ink
		{
			get {return base.Ink;}
			set 
			{
				base.Ink = value;
				for (int i = 0; i < m_aSprites.Count; i++)
				{
					((Sprite)m_aSprites[i]).Ink = value;
				}
			}
		}

		public override ERectangleF Rect
		{
			get
			{
				return base.Rect;
			}
			set
			{
				base.Rect = value;

				//we don't want this to be scaled (that would make the 9 sprite scale as well) so set SourceRect to same size
				//set it directly, we don't want to recalc the output rect (as SourceRect would do)
				//this.m_rctSrcClip = new Rectangle(0,0,(int)Rect.Width, (int)Rect.Height);

				//the corners just need locs, the sides need rect (stretching on one axis), the middle tile needs rect (on both axes)
				Sprite sp;

				//sprite 0 (top left) is always 0,0 - no need to set.
				sp = (Sprite)m_aSprites[0];
				//sp.Rect = new RectangleF(0,0,0,0);

				m_nRemoveForInterpolation = 1;
				int nAdd= m_nRemoveForInterpolation;

				
				sp = (Sprite)m_aSprites[1];
				sp.Rect = ERectangleF.FromLTRB(sp.SourceRect.Left,0, Rect.Right-(sp.Member.Size.X-sp.SourceRect.Right)+nAdd, sp.SourceRect.Bottom);
				sp = (Sprite)m_aSprites[2];
				sp.Loc = new EPointF(Rect.Width-sp.SourceRect.Width,0);

				sp = (Sprite)m_aSprites[3];
				sp.Rect = ERectangleF.FromLTRB(0,sp.SourceRect.Top, sp.SourceRect.Right, Rect.Bottom-(sp.Member.Size.X-sp.SourceRect.Bottom)+nAdd);
				sp = (Sprite)m_aSprites[4];
				sp.Rect = ERectangleF.FromLTRB(sp.SourceRect.Left,sp.SourceRect.Top, Rect.Right-(sp.Member.Size.X-sp.SourceRect.Right)+nAdd, Rect.Bottom-(sp.Member.Size.X-sp.SourceRect.Bottom)+nAdd);
				sp = (Sprite)m_aSprites[5];
				sp.Rect = ERectangleF.FromLTRB(Rect.Width-sp.SourceRect.Width,sp.SourceRect.Top, Rect.Width, Rect.Bottom-(sp.Member.Size.X-sp.SourceRect.Bottom)+nAdd);

				sp = (Sprite)m_aSprites[6];
				sp.Loc = new EPointF(0,Rect.Height-sp.SourceRect.Height);
				sp = (Sprite)m_aSprites[7];
				sp.Rect = ERectangleF.FromLTRB(sp.SourceRect.Left,Rect.Height-sp.SourceRect.Height, Rect.Right-(sp.Member.Size.X-sp.SourceRect.Right)+nAdd, Rect.Height);
				sp = (Sprite)m_aSprites[8];
				sp.Loc = new EPointF(Rect.Width-sp.SourceRect.Width,Rect.Height-sp.SourceRect.Height);
			}
		}
	}
}
