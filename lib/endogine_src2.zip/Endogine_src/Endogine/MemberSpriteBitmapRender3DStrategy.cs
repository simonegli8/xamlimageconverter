using System;
using System.Drawing;
using Microsoft.DirectX.Direct3D;

namespace Endogine
{
	/// <summary>
	/// Summary description for MemberSpriteBitmapRender3DStrategy.
	/// </summary>
	public class MemberSpriteBitmapRender3DStrategy : MemberSpriteBitmapRenderStrategy
	{
		private Texture m_tx;
		//private ImageInformation m_info;


		public MemberSpriteBitmapRender3DStrategy()
		{
		}

		public override void Load(string a_sFilename)
		{
			Bitmap bmp = m_mb._FriendLoadIntoBitmap(a_sFilename);
			if (m_mb.GotAnimation)
			{
				m_tx = new Texture(m_endogine.Stage.D3DDevice, bmp, Usage.None, Pool.Managed);
				//TODO: can't I set Min/Mag filters here!?

				//m_tx = new Texture(a_endogine.Stage.D3DDevice, img.Size.Width, img.Size.Height, 1, Usage.None, Format.A8R8G8B8, Pool.Managed)
				//m_info = new ImageInformation();
				//m_info.Width = bmp.Width;
				//m_info.Height = bmp.Height;
			}
			else
			{
				ImageInformation m_info = TextureLoader.ImageInformationFromFile(m_mb.FileFullName);
			
				int nMipLevels = 1;
				Format format = m_info.Format;
				//format = Format.A8R8G8B8;

				int nColorKey = (unchecked((int)0xff000000));
				//nColorKey = (unchecked((int)0xffffffff));

				m_tx = TextureLoader.FromFile(m_endogine.Stage.D3DDevice, m_mb.FileFullName, m_info.Width, m_info.Height, 
					nMipLevels, Usage.None, format, Pool.Managed, Filter.Linear, Filter.Point, nColorKey, ref m_info);
			}
			bmp.Dispose();
		}

		public override void CreateFromBitmap(Bitmap a_bmp)
		{
			m_tx = new Texture(m_endogine.Stage.D3DDevice, a_bmp, Usage.None, Pool.Managed);
		}

		public Texture Texture
		{
			get {return m_tx;}
		}
	}
}
