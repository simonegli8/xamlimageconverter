using System;
using System.Data;
using System.Data.OleDb;
using System.Collections;
using System.IO;

namespace Endogine
{
	/// <summary>
	/// Summary description for CastLib.
	/// </summary>
	public class CastLib
	{
		private DataTable m_dtMembers;
		private Hashtable m_plMembers;
		private ArrayList m_aMembers;
		public bool UseDummiesForFilesNotFound = false;

		private EndogineHub m_endogine;
		private DirectoryInfo m_dirInfo;

		public CastLib(EndogineHub a_endogine)
		{
			m_endogine = a_endogine;

			m_dirInfo = new DirectoryInfo(m_endogine.ApplicationPath).Parent;
			if (m_dirInfo.Name == "Debug" || m_dirInfo.Name == "Release")
				m_dirInfo = m_dirInfo.Parent.Parent;
			m_dirInfo = new DirectoryInfo(m_dirInfo.FullName + "\\Media");

			m_aMembers = new ArrayList();
			m_plMembers = new Hashtable();

			m_dtMembers = new DataTable();
			m_dtMembers.Columns.Add("Name", typeof(System.String));
			m_dtMembers.Columns.Add("Hash", typeof(System.Int32));
		}

		public void Dispose()
		{
			m_dtMembers.Dispose();
		}

		/// <summary>
		/// Gets the default directory for media
		/// </summary>
		public string DirectoryPath
		{
			get {return m_dirInfo.FullName + "\\";}
		}

		/// <summary>
		/// Finds a media file. if you supply fully qualified path, it doesn't do anything.
		/// Looks first in default castlib folder, then in application folder.
		/// If no extension is provided, the first found file which matches will be returned.
		/// TODO: could add several alternative paths to look in
		/// </summary>
		/// <param name="a_sFile">File name or path</param>
		public string FindFile(string a_sFile)
		{
			FileInfo finfo = new FileInfo(a_sFile);
			if (finfo.Extension.Length == 0)
			{
				FileInfo[] files = m_dirInfo.GetFiles(a_sFile+".*");
				if (files.GetLength(0)>0)
				{
					a_sFile = files[0].FullName;
					finfo = new FileInfo(a_sFile);
				}
			}
			
			if (a_sFile.IndexOf(finfo.Directory.Root.FullName) == 0) //is it a fully qualified path?
			{
				if (finfo.Exists)
					return a_sFile;
			}
			else
			{
				finfo = new FileInfo(DirectoryPath+a_sFile);
				if (finfo.Exists)
					return finfo.FullName;

				finfo = new FileInfo(a_sFile);
				if (finfo.Exists)
					return finfo.FullName;
			}

			return "";
		}

		public MemberBase GetOrCreate(string a_sName)
		{
			MemberBase mb = GetByName(a_sName);
			if (mb != null)
				return mb;

			return ((MemberBase)new MemberSpriteBitmap(a_sName));
		}

		public void Add(MemberBase a_mb)
		{
			DataRow row = m_dtMembers.NewRow();
			m_dtMembers.Rows.Add(row);

			row["Name"] = a_mb.Name;
			row["Hash"] = a_mb.GetHashCode();

			m_plMembers[a_mb.GetHashCode()] = a_mb;

			m_aMembers.Add(a_mb);
		}

		public void Remove(MemberBase a_mb)
		{
			DataRow[] rows = m_dtMembers.Select("Hash = "+a_mb.GetHashCode());
			foreach (DataRow row in rows)
				m_dtMembers.Rows.Remove(row);
			m_plMembers.Remove(a_mb.GetHashCode());
			m_aMembers.Remove(a_mb);
		}

		public MemberBase GetByName(string a_sName)
		{
			DataRow[] rows = m_dtMembers.Select("Name = '"+a_sName+"'");
			if (rows.GetLength(0) > 0)
			{
				return (MemberBase)m_plMembers[(int)rows[0]["Hash"]];
			}
			return (MemberBase)null;
		}

		public MemberBase GetByIndex(int a_nIndex)
		{
			return (MemberBase)m_aMembers[a_nIndex];
		}
	}
}
