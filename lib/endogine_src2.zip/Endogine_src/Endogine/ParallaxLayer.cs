using System;

namespace Endogine
{
	/// <summary>
	/// A ParallaxLayer manages it's child sprites so that they are moved according to the ScrollFactor when the camera is moved
	/// </summary>
	public class ParallaxLayer : Sprite
	{
		protected EPointF m_pntScrollFactor;

		public ParallaxLayer()
		{
			m_pntScrollFactor = new EPointF(1,1);
			this.SourceRect = new ERectangle(0,0,1,1);
			this.Rect = new ERectangleF(0,0,1,1);
		}

		public EPointF ScrollFactor
		{
			get {return m_pntScrollFactor;}
			set {m_pntScrollFactor = value;}
		}

		public override EPointF Loc
		{
			get
			{
				return base.Loc/m_pntScrollFactor;
			}
			set
			{
				base.Loc = value*m_pntScrollFactor;
			}
		}
	}
}
