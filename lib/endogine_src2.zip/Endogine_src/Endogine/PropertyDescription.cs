using System;

namespace Endogine
{
	/// <summary>
	/// Summary description for PropertyDescription.
	/// </summary>

	//TODO: just found the PropertyInfo class - this class should derive from it!
	public class PropertyDescription
	{
		public string Name;
		public string Comment;
		public System.Type Type;
		public float Min = 0;
		public float Max = 100;
		public float Default = 0;
		public bool UseNumericUpDown = true;
		public bool UseSlider = false;
		public bool UseDropDownList = false;
		public bool UseCheckBox = false;

		public bool EnforceLimits = false; //false if min/max is only a suggestion, true if min/max can't be exceeded

		public PropertyDescription(string sName, string sComment, System.Type tType)
		{
			Name = sName;
			if (sComment == null || sComment == "")
				Comment = Name;
			else
				Comment = sComment;
			Type = tType;
		}
	}
}
