using System;
using System.Drawing;
using System.Collections;

namespace Endogine
{
	/// <summary>
	/// Summary description for BhSpriteChangeLoc.
	/// </summary>
	public class BhSpriteChangeLoc : Behavior
	{
		protected ArrayList m_aSprites;

		public BhSpriteChangeLoc()
		{
			m_aSprites = new ArrayList();

			//create an arrow bitmap

			//create one sprite with arrow for each axis

			Sprite sp;
			sp = new Sprite();
			sp.MemberName = "Cross";
			sp.LocZ = 1000;
			m_aSprites.Add(sp);

			//create one sprite for both axis movement
		}

		public override void Dispose()
		{
			foreach (Sprite sp in m_aSprites)
				sp.Dispose();
			base.Dispose();
		}
		protected override void EnterFrame()
		{
			base.EnterFrame();

			if (m_sp.Rect == null)
				return;

			ERectangleF rct = new ERectangleF(
				m_sp.ConvParentLocToRootLoc(m_sp.Rect.Location),
				m_sp.ConvParentLocToRootLoc(m_sp.Rect.Size));
		}
	}
}
