using System;
using System.Drawing;

namespace Endogine
{
	/// <summary>
	/// Summary description for ERectangle.
	/// </summary>
	public class ERectangleF
	{
		public float X = 0;
		public float Y = 0;
		public float Width = 0;
		public float Height = 0;

		public ERectangleF()
		{
		}
		public ERectangleF(float x, float y, float width, float height)
		{
			X = x; Y = y; Width = width; Height = height;
		}
		public ERectangleF(EPointF loc, EPointF size)
		{
			X = loc.X; Y = loc.Y; Width = size.X; Height = size.Y;
		}
		public ERectangleF(RectangleF rct)
		{
			X = rct.X; Y = rct.Y; Width = rct.Width; Height = rct.Height;
		}



		public static ERectangleF FromLTRB(float l, float t, float r, float b)
		{
			return new ERectangleF(l,t, r-l, b-t);
		}

		public void Offset(EPointF pnt)
		{
			X+=pnt.X;
			Y+=pnt.Y;
		}
		public void Offset(float x, float y)
		{
			X+=x;
			Y+=y;
		}
		public EPointF Location
		{
			get {return new EPointF(X,Y);}
			set {X = value.X; Y = value.Y;}
		}
		public EPointF BottomRight
		{
			get {return new EPointF(X+Width,Y+Height);}
			set {Width = value.X-X; Y = value.Y-Y;}
		}
		public EPointF Middle
		{
			get {return new EPointF(X+Width/2,Y+Height/2);}
		}
		public EPointF Size
		{
			get {return new EPointF(Width, Height);}
			set {Width = value.X; Height = value.Y;}
		}
		public float Left
		{
			get {return X;}
			set {X = value;}
		}
		public float Top
		{
			get {return Y;}
			set {Y = value;}
		}
		public float Right
		{
			get {return X+Width;}
			set {Width = value-X;}
		}
		public float Bottom
		{
			get {return Y+Height;}
			set {Height = value-Y;}
		}

		public void Inflate(EPointF pnt)
		{
			Height = Math.Max(Height, pnt.X);
			Width = Math.Max(Width, pnt.Y);
		}
		public void Expand(ERectangleF rct)
		{
			float r = Right;
			float b = Bottom;

			X = Math.Min(X, rct.X);
			Y = Math.Min(Y, rct.Y);

			Right = Math.Max(r, rct.Right);
			Bottom = Math.Max(b, rct.Bottom);
		}

		public void Normalize()
		{
			if (Width < 0)
			{
				Width=-Width;
				X = X-Width;
			}
			if (Height < 0)
			{
				Height=-Height;
				Y = Y-Height;
			}
		}
		public float GetArea()
		{
			return Width*Height;
		}
		public double GetHypo()
		{
			return Math.Sqrt(Width*Width + Height*Height);
		}


		public ERectangle ToERectangle()
		{
			return new ERectangle((int)X,(int)Y,(int)Width,(int)Height);
		}
		public Rectangle ToRectangle()
		{
			return new Rectangle((int)X,(int)Y,(int)Width,(int)Height);
		}
		public RectangleF ToRectangleF()
		{
			return new RectangleF(X,Y,Width,Height);
		}

		public bool IsEmpty()
		{
			return (Width==0 && Height == 0);
		}
		public bool IsNegative()
		{
			return (Width<0 || Height < 0);
		}

		public ERectangleF Copy()
		{
			return new ERectangleF(X,Y,Width,Height);
		}
		public void Intersect(ERectangleF rct)
		{
			float b = Bottom;
			float r = Right;
			X = Math.Max(rct.X, X);
			Y = Math.Max(rct.Y, Y);
			Bottom = Math.Min(rct.Bottom, b);
			Right = Math.Min(rct.Right, r);
		}
		public bool IntersectsWith(ERectangleF rct)
		{
			ERectangleF rctNew = this.Copy();
			rctNew.Intersect(rct);
			return !(rctNew.IsNegative() || rctNew.IsEmpty());
		}
		public bool Contains(EPointF pnt)
		{
			return (pnt.X >= Left && pnt.X <= Right && pnt.Y >= Top && pnt.Y <= Bottom);
		}

		public void MakePointInside(EPointF pnt)
		{
			pnt.X = Math.Max(pnt.X, X);
			pnt.X = Math.Min(pnt.X, Right);
			pnt.Y = Math.Max(pnt.Y, Y);
			pnt.Y = Math.Min(pnt.Y, Bottom);
		}
		public void WrapPointInside(EPointF pnt)
		{
			if (pnt.X < X)
				pnt.X = Right - (X - pnt.X);
			else if (pnt.X > Right)
				pnt.X = X + (pnt.X - Right);
			if (pnt.Y < Y)
				pnt.Y = Bottom - (Y - pnt.Y);
			else if (pnt.Y > Bottom)
				pnt.Y = Y + (pnt.Y - Bottom);
		}


		public static ERectangleF operator +(ERectangleF r1, ERectangleF r2)
		{
			return new ERectangleF(r1.X+r2.X, r1.Y+r2.Y, r1.Width+r2.Width, r1.Height+r2.Height);
		}

		public void Multiply(EPointF pnt)
		{
			X*=pnt.X;
			Y*=pnt.Y;
			Width*=pnt.X;
			Height*=pnt.Y;
		}
		public void Multiply(float val)
		{
			X*=val;
			Y*=val;
			Width*=val;
			Height*=val;
		}
	}
}
