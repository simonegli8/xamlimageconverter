using System;
using System.Drawing;

namespace Endogine
{
	/// <summary>
	/// Summary description for MemberSpriteBitmapRenderDDStrategy.
	/// </summary>
	public class MemberSpriteBitmapRenderGDIStrategy : MemberSpriteBitmapRenderStrategy
	{
		protected Bitmap m_bmp;

		public MemberSpriteBitmapRenderGDIStrategy()
		{
		}

		public override void Load(string a_sFilename)
		{
			m_bmp =  m_mb._FriendLoadIntoBitmap(a_sFilename);
		}
		
		public override void CreateFromBitmap(Bitmap a_bmp)
		{
			if (m_bmp!=null)
				m_bmp.Dispose();
			m_bmp = a_bmp;
		}

		public Bitmap GetBitmap()
		{
			return m_bmp;
		}

	}
}
