using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Endogine
{
	/// <summary>
	/// Summary description for MessageWindow.
	/// </summary>
	public class MessageWindow : System.Windows.Forms.Form
	{
		private System.Windows.Forms.RichTextBox richTextBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MessageWindow()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		public void Put(string s)
		{
			int nOverflow = richTextBox1.Text.Length -6*1024;
			if (nOverflow > 0)
				richTextBox1.Text = richTextBox1.Text.Remove(0, nOverflow);

			richTextBox1.Text+=s+"\n";
			this.Invalidate();
			//TODO: how to invalidate although the form isn't in focus?? this.Focus();
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.SuspendLayout();
			// 
			// richTextBox1
			// 
			this.richTextBox1.Location = new System.Drawing.Point(0, 0);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
			this.richTextBox1.Size = new System.Drawing.Size(296, 272);
			this.richTextBox1.TabIndex = 1;
			this.richTextBox1.Text = "Welcome to Endogine";
			this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
			// 
			// MessageWindow
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.Add(this.richTextBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Location = new System.Drawing.Point(0, 300);
			this.Name = "MessageWindow";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "MessageWindow";
			this.Resize += new System.EventHandler(this.MessageWindow_Resize);
			this.ResumeLayout(false);

		}
		#endregion

		private void richTextBox1_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void MessageWindow_Resize(object sender, System.EventArgs e)
		{
			richTextBox1.Width = ClientRectangle.Width;
			richTextBox1.Height = ClientRectangle.Height;
		}
	}
}
