using System;
using System.Drawing;
using System.Data;
using System.Collections;
using System.Windows.Forms;

namespace Endogine
{

	/// <summary>
	/// Summary description for Sprite.
	/// </summary>
	public class Sprite
	{
		public delegate void MouseEventDelegate(MouseEventArgs e, MouseEventType t);
		public delegate void EnterFrameEventDelegate();

		public enum Props
		{
			Loc, LocX, LocY, LocZ,
			Rotation,
			ScaleX, ScaleY,
			Ink, Blend, Visible,
			Member, MemberName, MemberNum, MemberAnimationFrame
		}
		public enum MouseEventType
		{
			Down, StillDown, Up, UpOutside, Click, Enter, Leave
		}
	
		protected ERectangle m_rctSrcClip;
		//protected Size m_sizeSrc;
		//protected Point m_pntSrcRegPoint;

		protected ERectangleF m_rctDstParent;
		protected ERectangleF m_rctDstDraw;
		protected Sprite m_spParent = null;
		protected Sprite m_spDrawTarget = null;

		protected Hashtable m_plChildrenByHash;
		protected DataTable m_dtChildren;
		protected DataView m_dvChildrenLocZSorted;
		protected DataView m_dvChildrenLocZInverseSorted;

		protected string m_sID;
		protected int m_nInk = 0;
		protected int m_nBlend = 255;
		protected bool m_bVisible = true;
		protected Color m_clr;
		protected bool m_bMeInvisibleButNotChildren = false;

		protected EndogineHub m_endogine;

		protected Animator m_autoAnimator = null;

		protected bool m_bMouseActive = false;
		protected bool m_bMouseDown = false;
		protected bool m_bMouseIsInside = false;
		protected SpriteMouseEvents m_spMouse = null;
		public event MouseEventDelegate MouseEvent;
		protected EPoint m_pntMouseDown;
		protected EPoint m_pntMouseLast;

		//these are "derived" values - for user interaction and faster calculations.
		//m_rctDstParent is the result of loc, scale, srcCrop and regPoint
		protected float m_fLocZ;
		protected EPointF m_pntLoc;
		protected EPointF m_pntScale;
		protected bool m_bNoScalingOnSetRect = false; //only applicable to dummy sprites: if the children should not inherit scaling (what actually happens is that the sourcerect is set to correspond to the output rect
		protected EPoint m_pntRegPoint; //this value originally comes from the member, but can be set individually for each sprite.
		protected float m_fRotation;

		protected MemberSpriteBitmap m_mb;
		protected int m_nMemberAnimFrame;

		protected ArrayList m_aChildrenToRemove; //when removing a child during looping, they remain in lists until looping is done
		protected bool m_bDisposing = false;
		protected bool m_bLooping = false; //true when inside a loop that doesn't allow child sprites to be added/deleted. If so, they're added to a list which will be processed later
		protected SpriteRenderStrategy m_renderStrategy;

		protected ArrayList m_aBehaviors;
		public event EnterFrameEventDelegate EnterFrameEvent;

		public Sprite()
		{
			m_endogine = EndogineHub.Get();
			Init();
		}

		public Sprite(EndogineHub a_endogine)
		{
			m_endogine = a_endogine;
			Init();
		}

		private void Init()
		{
			m_aChildrenToRemove = new ArrayList();
			m_plChildrenByHash = new Hashtable();
			m_sID = "";
			m_nInk = 0;
			m_nBlend = 255;
			m_fLocZ = 0.0f;
			m_pntLoc = new EPointF(0.0f, 0.0f);
			m_pntScale = new EPointF(1.0f, 1.0f);
			m_rctSrcClip = new ERectangle(0,0,1,1);
			m_pntRegPoint = new EPoint(0,0);
			m_clr = Color.White;

			m_aBehaviors = new ArrayList();

			m_nMemberAnimFrame = 0;

			m_dtChildren = new DataTable();
			m_dtChildren.Columns.Add("Name", typeof(System.String));
			m_dtChildren.Columns.Add("LocZ", typeof(System.Double));
			m_dtChildren.Columns.Add("Hash", typeof(System.Int32));

			m_dvChildrenLocZSorted = new DataView(m_dtChildren, "", "LocZ", DataViewRowState.CurrentRows);
			m_dvChildrenLocZInverseSorted  = new DataView(m_dtChildren, "", "LocZ DESC", DataViewRowState.CurrentRows);

			m_pntMouseDown = new EPoint();
			m_pntMouseLast = new EPoint();

			if (m_endogine.Stage != null)
			{
				if (m_endogine.Stage.Camera != null)
				{
					ParallaxLayer layer = (ParallaxLayer)m_endogine.Stage.Camera.GetChildByName("DefaultLayer");
					if (layer != null)
						Parent = (Sprite)layer;
					else
						Parent = (Sprite)m_endogine.Stage.Camera;
				}
				else if (m_endogine.Stage.RootSprite != null)
					Parent = m_endogine.Stage.RootSprite;
			}

			if (m_endogine.CurrentRenderStrategy == EndogineHub.RenderStrategy.D3D)
				m_renderStrategy = new SpriteRender3DStrategy();
			else if (m_endogine.CurrentRenderStrategy == EndogineHub.RenderStrategy.DD)
				m_renderStrategy = new SpriteRenderDDStrategy();
			else
				m_renderStrategy = new SpriteRenderGDIStrategy();
			
			m_renderStrategy.SetEndogine(m_endogine);
			m_renderStrategy.SetSprite(this);
			m_renderStrategy.Init();
		}


		public virtual void Dispose()
		{
			m_bDisposing = true;
			if (m_autoAnimator != null)
				m_autoAnimator.Dispose();
			if (m_mb != null)
				m_mb.RemoveSprite(this);
			//if (this.m_spDrawTarget!=null)
			if (m_spParent != null)
				m_spParent.RemoveChild(this);

			for (int i = m_aBehaviors.Count-1; i >= 0; i--)
			{
				Behavior bh = (Behavior)m_aBehaviors[i];
				bh.Dispose();
			}

			m_renderStrategy.Dispose();
		}
		public bool Disposing
		{
			get {return m_bDisposing;}
		}


		
		public EndogineHub EndogineHub
		{
			get {return m_endogine;}
		}

		#region Mouse control
		public void ConfigMouse()
		{
			m_bMouseActive = true;
			//if (m_spMouse == null)
			//	m_spMouse = new SpriteMouseEvents(this);
		}

		public bool CheckMouse(MouseEventArgs e, EPointF a_pntLocalLoc, bool a_bButtonAction, bool a_bDown)
		{
			bool bReactedToButton = false;
			bool bReactedRoll = false;

			if (Rect.Contains(a_pntLocalLoc))
			{
				if (!m_bMouseIsInside)
				{
					//enter
					bReactedRoll = true;
					m_bMouseIsInside = true;
					OnMouse(e, MouseEventType.Enter);
				}
					
				if (a_bButtonAction)
				{
					if (a_bDown)
					{
						m_pntMouseDown.X = e.X;
						m_pntMouseDown.Y = e.Y;
						m_pntMouseLast = m_pntMouseDown;
						OnMouse(e, MouseEventType.Down);
					}
					else
					{
						if (m_bMouseDown)
							OnMouse(e, MouseEventType.Click);
						else
							OnMouse(e, MouseEventType.Up);
					}
					bReactedToButton = true;
				}
				else if (m_bMouseDown)
				{
					OnMouse(e, MouseEventType.StillDown);
				}
			}
			else
			{
				if (m_bMouseIsInside)
				{
					//leave
					bReactedRoll = true;
					m_bMouseIsInside = false;
					OnMouse(e, MouseEventType.Leave);
				}
				if (a_bButtonAction && !a_bDown && m_bMouseDown)
				{
					m_bMouseDown = false;
					OnMouse(e, MouseEventType.UpOutside);
				}
			}

			m_pntMouseLast.X = e.X;
			m_pntMouseLast.Y = e.Y;

			if (bReactedToButton)
				m_bMouseDown = a_bDown;

			//Can't stop checking completely: sprites under might need to send Leave, or UpOutside...
			if (bReactedToButton && true) //TODO: pass?
				return false; 
			if (bReactedRoll && true) //TODO: pass?
				return false;
			return true;
		}

		public bool CheckChildrenMouse(MouseEventArgs e, EPointF a_pntLocalLoc, bool a_bButtonAction, bool a_bDown)
		{
			bool bContinueChecking = true;

			m_bLooping = true;
			a_pntLocalLoc = this.ConvParentLocToSrcLoc(a_pntLocalLoc);
			foreach (DataRowView row in m_dvChildrenLocZInverseSorted)
			{
				Sprite sp = ((Sprite)m_plChildrenByHash[(int)row["Hash"]]);
				if (sp.ChildCount > 0)
					bContinueChecking = sp.CheckChildrenMouse(e, a_pntLocalLoc, a_bButtonAction, a_bDown);

				if (!bContinueChecking)
					return false;
				if (sp.MouseActive)
				{
					sp.CheckMouse(e,a_pntLocalLoc, a_bButtonAction, a_bDown);
				}					
			}
			m_bLooping = false;

			return true;
		}

		protected virtual void OnMouse(MouseEventArgs e, MouseEventType t)
		{
			if (MouseEvent!=null)
				MouseEvent(e,t);
		}
		public EPoint MouseLast
		{
			get {return m_pntMouseLast;}
		}

		public void GetMouseActiveOffspringZSorted(ref SortedList a_plSprites, ref int a_nOrderCount)
		{
			foreach (DataRowView row in m_dvChildrenLocZSorted)
			{
				Sprite sp = ((Sprite)m_plChildrenByHash[(int)row["Hash"]]);
	
				if (sp.MouseActive)
					a_plSprites.Add(a_nOrderCount, sp);

				a_nOrderCount++;
				if (sp.ChildCount > 0)
				{
					sp.GetMouseActiveOffspringZSorted(ref a_plSprites, ref a_nOrderCount);
				}
			}
		}
		public void GetVisibleOffspringZSorted(ref SortedList a_plSprites, ref int a_nOrderCount)
		{
			foreach (DataRowView row in m_dvChildrenLocZSorted)
			{
				Sprite sp = ((Sprite)m_plChildrenByHash[(int)row["Hash"]]);

				if (sp.Visible && !sp.m_bMeInvisibleButNotChildren)
					a_plSprites.Add(a_nOrderCount, sp);

				a_nOrderCount++;
				if (sp.ChildCount > 0)
				{
					sp.GetVisibleOffspringZSorted(ref a_plSprites, ref a_nOrderCount);
				}
			}
		}

		public bool MouseActive
		{
			get
			{
				return m_bMouseActive;
				//if (m_spMouse == null) return false;
				//return m_spMouse.Active;
			}
			set 
			{
				m_bMouseActive = value;
				/*if (m_spMouse == null)
				{
					if (value == true) ConfigMouse();
					else return;
				}
				else
					m_spMouse.Active = value;*/
			}
		}
		#endregion

		#region SetOneProp/GetOneProp
		public Hashtable GetPropertyDescriptionList()
		{
			//TODO: should be static, and generated at first sprite creation.
			//TODO: create a PropertyDescription class for each type (int, float, string, Point, Rect etc)
			Hashtable ht = new Hashtable();
			PropertyDescription pd;

			pd = new PropertyDescription("LocX", null, typeof(float));
			ht.Add(pd.Name, pd);
			pd = new PropertyDescription("LocY", null, typeof(float));
			ht.Add(pd.Name, pd);

			pd = new PropertyDescription("LocZ", null, typeof(float));
			ht.Add(pd.Name, pd);

			pd = new PropertyDescription("ScaleX", null, typeof(float));
			ht.Add(pd.Name, pd);
			pd = new PropertyDescription("ScaleY", null, typeof(float));
			ht.Add(pd.Name, pd);

			pd = new PropertyDescription("Visible", null, typeof(bool));
			pd.UseCheckBox = true;
			pd.UseNumericUpDown = false;
			ht.Add(pd.Name, pd);

			pd = new PropertyDescription("Ink", null, typeof(RasterOps.ROPs));
			pd.UseNumericUpDown = false;
			pd.UseDropDownList = true;
			ht.Add(pd.Name, pd);

			pd = new PropertyDescription("Rotation", null, typeof(float));
			ht.Add(pd.Name, pd);

			pd = new PropertyDescription("Blend", null, typeof(int));
			pd.EnforceLimits = true;
			pd.Max = 255;
			ht.Add(pd.Name, pd);

			return ht;
		}

		public object GetOneProp(string a_sProp)
		{
			switch (a_sProp)
			{
				case "LocX":
					return LocX;
				case "LocY":
					return LocY;
				case "LocZ":
					return LocZ;
				case "Rotation":
					return Rotation;
				case "ScaleX":
					return Scaling.X;
				case "ScaleY":
					return Scaling.Y;
					//				case "MemberNum":
					//					if (Member!=null)
					//						return Member.Name?
					//					break;
				case "Member":
					return Member;
				case "MemberName":
					if (Member!=null)
						return Member.Name;
					return null;
				case "MemberAnimationFrame":
					return MemberAnimationFrame;
				case "Ink":
					return Ink;
				case "Blend":
					return Blend;
				case "Visible":
					return Visible;
			}
			return null;
		}

		public void SetOneProp(string a_sProp, object a_oVal)
		{
			switch (a_sProp)
			{
				case "LocX":
					SetOneProp(Props.LocX, a_oVal);
					break;
				case "LocY":
					SetOneProp(Props.LocY, a_oVal);
					break;
				case "LocZ":
					SetOneProp(Props.LocZ, a_oVal);
					break;
				case "ScaleX":
					SetOneProp(Props.ScaleX, a_oVal);
					break;
				case "ScaleY":
					SetOneProp(Props.ScaleY, a_oVal);
					break;
				case "Rotation":
					SetOneProp(Props.Rotation, a_oVal);
					break;
				case "MemberNum":
					SetOneProp(Props.MemberNum, a_oVal);
					break;
				case "Member":
					SetOneProp(Props.Member, a_oVal);
					break;
				case "MemberName":
					SetOneProp(Props.MemberName, a_oVal);
					break;
				case "MemberAnimationFrame":
					SetOneProp(Props.MemberAnimationFrame, a_oVal);
					break;
				case "Ink":
					SetOneProp(Props.Ink, a_oVal);
					break;
				case "Blend":
					SetOneProp(Props.Blend, a_oVal);
					break;
				case "Visible":
					SetOneProp(Props.Visible, a_oVal);
					break;
			}
		}
		public void SetOneProp(Props a_prop, object a_oVal)
		{
			switch (a_prop)
			{
				case Props.Loc:
					this.Loc = (EPointF)a_oVal;
					break;
				case Props.LocX:
					Move((float)Convert.ToDouble(a_oVal)-Loc.X, 0);
					break;
				case Props.LocY:
					Move(0, (float)Convert.ToDouble(a_oVal)-Loc.Y);
					break;
				case Props.LocZ:
					LocZ = (float)Convert.ToDouble(a_oVal);
					break;
				case Props.ScaleX:
					Scaling = new EPointF((float)Convert.ToDouble(a_oVal), Scaling.Y);
					break;
				case Props.ScaleY:
					Scaling = new EPointF(Scaling.X, (float)Convert.ToDouble(a_oVal));
					break;
				case Props.Rotation:
					Rotation = (float)Convert.ToDouble(a_oVal);
					break;
				case Props.MemberNum:
					this.Member = (MemberSpriteBitmap)m_endogine.CastLib.GetByIndex((int)a_oVal);
					break;
				case Props.Member:
					this.Member = (MemberSpriteBitmap)a_oVal;
					break;
				case Props.MemberName:
					this.Member = (MemberSpriteBitmap)m_endogine.CastLib.GetByName((string)a_oVal);
					break;
				case Props.MemberAnimationFrame:
					this.MemberAnimationFrame = (int)Convert.ToDouble(a_oVal);
					break;
				case Props.Ink:
					try
					{
						this.Ink = (RasterOps.ROPs)(int)Convert.ToDouble(a_oVal);
					}
					catch
					{
						string s = null;
						try
						{
							s = Convert.ToString(a_oVal);
						}
						catch
						{
							return;
						}
						this.Ink = (RasterOps.ROPs)Enum.Parse(typeof(RasterOps.ROPs), s, true);
					}
					break;
				case Props.Blend:
					this.Blend = (int)Convert.ToDouble(a_oVal);
					break;
				case Props.Visible:
					this.Visible = Convert.ToDouble(a_oVal) > 0;
					break;
			}
		}
		#endregion

		public string GetSceneGraphName()
		{
			string sText = Name +  "/";
			if (Member != null)
				sText+=Member.Name;
			sText+= ":"+this.ToString().Replace("Endogine", ""); //remove "Endogine" from class name, it's understood...
			return sText;
		}

		public String Name
		{
			get {return m_sID;}
			set 
			{
				m_sID = value;
				if (m_spParent != null)
					m_spParent.UpdateChildTableForChild(this);
			}
		}

		public ArrayList GetSpritesUnderLoc(EPointF a_pnt, int a_nMaxNumSprites)
		{
			ArrayList aSprites = new ArrayList();
			SortedList plSprites = new SortedList();
			int n = 0;
			GetVisibleOffspringZSorted(ref plSprites, ref n);
			for (int i = plSprites.Count-1; i >= 0; i--)
			{
				Sprite sp = (Sprite)plSprites.GetByIndex(i);
				EPointF pntSprite = sp.ConvRootLocToParentLoc(a_pnt);
				if (sp.Rect == null)
					continue;

				if (sp.Rect.Contains(pntSprite))
				{
					aSprites.Add(sp);
					if (aSprites.Count == a_nMaxNumSprites)
						break;
				}
			}
			return aSprites;
		}

		public ERectangleF GetPortionOfMemberToDisplay()
		{
			//TODO: doesn't care about SrcCrop!
			ERectangleF rctfCropped;

			EPoint size = Member.TotalSize;
			EPoint sizeFrame = Member.Size;
			EPoint sizeReal = size;//GetUpperPowerTextureSize(size);

			if (Member.GotAnimation)
			{
				ERectangle rctAnim = SourceRect;
				//Rectangle rctAnim = Member.GetRectForFrame(m_nMemberAnimFrame);

				rctfCropped = new ERectangleF((float)rctAnim.X/sizeReal.X, (float)rctAnim.Y/sizeReal.Y, 
					(float)rctAnim.Width/sizeReal.X, (float)rctAnim.Height/sizeReal.Y);
			}
			else
			{
				ERectangle rctAnim = SourceRect;
				rctfCropped = new ERectangleF((float)rctAnim.X/sizeReal.X, (float)rctAnim.Y/sizeReal.Y, 
					(float)rctAnim.Width/sizeReal.X, (float)rctAnim.Height/sizeReal.Y);
				//rctfCropped = new RectangleF(0,0, 1, 1);
				//rctfCropped = new RectangleF(0.1f,0.1f, 0.9f, 0.9f);
			}

			return rctfCropped;
		}

		public virtual ERectangleF Rect
		{
			get {return m_rctDstParent;}
			set
			{
				if (m_bNoScalingOnSetRect)
				{
					m_rctSrcClip = new ERectangle(0,0,(int)value.Width,(int)value.Height);
				}
				else
				{
					m_pntScale.X = value.Width/m_rctSrcClip.Width;
					m_pntScale.Y = value.Height/m_rctSrcClip.Height;
				}

				m_pntLoc.X = value.Left + m_pntScale.X*m_pntRegPoint.X;
				m_pntLoc.Y = value.Top + m_pntScale.Y*m_pntRegPoint.Y;

				m_rctDstParent = value;
			}
		}
		public ERectangle RectInt
		{
			get {return new ERectangle((int)m_rctDstParent.Left, (int)m_rctDstParent.Top, (int)m_rctDstParent.Width, (int)m_rctDstParent.Height);}
		}
		public ERectangle SourceRect
		{
			get
			{
				if (Member!=null && Member.GotAnimation)
				{
					ERectangle rctAnim = Member.GetRectForFrame(m_nMemberAnimFrame);
					ERectangle rct = m_rctSrcClip.Copy();
					rct.Offset(rctAnim.Location);
					return rct;
				}
				return m_rctSrcClip;
			}
			set
			{
				m_rctSrcClip = value;
				CalcInParent();
				//m_renderStrategy.SetSourceRect(m_rctSrcClip);
			}
		}

		/*//normally avoided. Use for when sprite is only a dummy node, with no graphic representation
		public void ForceSetSourceRect(Rectangle a_rct)
		{
			m_rctSrcClip = a_rct;
			CalcInParent();
		}*/

		public virtual RasterOps.ROPs Ink
		{
			get {return (RasterOps.ROPs)m_nInk;}
			set {m_nInk = (int)value;}
		}
		public int Blend
		{
			get {return m_nBlend;}
			set {m_nBlend = Math.Min(255,Math.Max(0,value));}
		}
		public bool Visible
		{
			get {return m_bVisible;}
			set {m_bVisible = value;}
		}
//		public bool VisibleChildrenInvisibleMe
//		{
//			get {return m_bMeInvisibleButNotChildren;}
//			set {m_bMeInvisibleButNotChildren = value;}
//		}
		public virtual Color Color
		{
			get {return m_clr;}
			set {m_clr = value; m_renderStrategy.SetColor(m_clr);}
		}

		public int MemberAnimationFrame
		{
			get {return m_nMemberAnimFrame;}
			set {
				if (value < 0)
					m_nMemberAnimFrame = -value;
				else
					m_nMemberAnimFrame = value;
				m_renderStrategy.SetMemberAnimationFrame(m_nMemberAnimFrame);
			}
		}

		public Animator AutoAnimator
		{	get {return m_autoAnimator;} }

		public Animator CreateAnimator(string a_sProp)
		{
			return new Animator(m_endogine, a_sProp, new AnimateEvent(SetOneProp));
		}

		public string MemberName
		{
			set 
			{
				Member = (MemberSpriteBitmap)m_endogine.CastLib.GetOrCreate(value);
			}
			get {return Member.Name;}
		}
		public virtual MemberSpriteBitmap Member
		{
			get {return m_mb;}
			set
			{
				if (m_mb != null)
					m_mb.RemoveSprite(this);
				if (value == null)
					throw(new Exception("No member!"));

				m_mb = value;
				m_pntRegPoint = m_mb.RegPoint;
				m_rctSrcClip = new ERectangle(new EPoint(0,0), m_mb.Size);
				CalcInParent();

				if (value.AutoAnimate)
				{
					m_autoAnimator = new Animator(m_endogine, "MemberAnimationFrame", new AnimateEvent(SetOneProp));
				}

				m_renderStrategy.SetMember(m_mb);
				m_mb.AddSprite(this);
			}
		}

		#region Move/Scale/Rotate methods
		public virtual EPointF Loc
		{
			get {return m_pntLoc;}
			set {m_pntLoc = value; CalcInParent();}
		}
		public virtual float LocX
		{
			get {return m_pntLoc.X;}
			set {Move(new EPointF(value-m_pntLoc.X, 0));}//m_pntLoc.X = value; CalcInParent();}
		}
		public virtual float LocY
		{
			get {return m_pntLoc.Y;}
			set {Move(new EPointF(0, value-m_pntLoc.Y));}//m_pntLoc.Y = value; CalcInParent();}
		}
		public virtual void Move(EPointF a_pnt)
		{
			this.Loc = new EPointF(a_pnt.X+this.Loc.X, a_pnt.Y+this.Loc.Y);
		}
		public virtual void Move(float a_fX, float a_fY)
		{
			this.Loc = new EPointF(a_fX+this.Loc.X, a_fY+this.Loc.Y);
		}
		public float LocZ
		{
			get {return m_fLocZ;}
			set
			{
				m_fLocZ = value;
				if (m_spParent != null)
					m_spParent.UpdateChildTableForChild(this);
			}
		}
		public EPoint RegPoint
		{
			get {return m_pntRegPoint;}
			set {m_pntRegPoint = value; CalcInParent();}
		}

		public EPointF Scaling
		{
			get {return m_pntScale;}
			set {m_pntScale = value; CalcInParent();}
		}
		public void Scale(float a_fX, float a_fY)
		{
			m_pntScale.X = a_fX; m_pntScale.Y = a_fY;
			CalcInParent();
		}
		public float Rotation
		{
			get {return m_fRotation;}
			set {m_fRotation = value;}
		}
		#endregion


		#region Output rect/quad calculation methods
		public void CalcInParent()
		{
			m_rctDstParent = m_rctSrcClip.ToERectangleF();

			m_rctDstParent.X *= m_pntScale.X;
			m_rctDstParent.Y *= m_pntScale.Y;
			m_rctDstParent.Width *= m_pntScale.X;
			m_rctDstParent.Height *= m_pntScale.Y;

			//TODO: use sprite pntLoc instead of members!
			if (Member != null)
				m_rctDstParent.Offset(m_pntLoc.X - m_pntRegPoint.X*m_pntScale.X, m_pntLoc.Y - m_pntRegPoint.Y*m_pntScale.Y);
			else
				m_rctDstParent.Offset(m_pntLoc);

			m_renderStrategy.RecalcedParentOutput();
		}

		public ERectangleF CalcRectInDrawTarget()
		{
			EPointF pnt1 = ConvParentLocToDrawLoc(m_rctDstParent.Location, m_spDrawTarget);
			EPointF pnt2 = ConvParentLocToDrawLoc(new EPointF(m_rctDstParent.Right, m_rctDstParent.Bottom), m_spDrawTarget);
			//TODO: why can't PointF and SizeF be added..?
			//PointF pnt2 = ConvParentLocToDrawLoc(new PointF(m_rctDstParent.Location.X + m_rctDstParent.Size.Width, m_rctDstParent.Location.Y + m_rctDstParent.Size.Height), m_spDrawTarget);
			return new ERectangleF(pnt1.X, pnt1.Y, pnt2.X-pnt1.X, pnt2.Y-pnt1.Y);
		}
		#endregion


		#region Loc conversion methods (between source/parent/drawTarget/root)
		//ParentLoc = point relative to the output rect (Rect) - source loc after move/scale/rotate
		public EPointF ConvSrcLocToParentLoc(EPointF a_pntLoc)
		{
			//if (Member==null)
			//	return a_pntLoc;
//			PointF pntFract = new PointF(a_pntLoc.X/m_mb.Size.Width, a_pntLoc.Y/m_mb.Size.Height);
			EPointF pntFract = new EPointF(a_pntLoc.X/SourceRect.Width, a_pntLoc.Y/SourceRect.Height);
			pntFract.X = pntFract.X*m_rctDstParent.Width + m_rctDstParent.Left;
			pntFract.Y = pntFract.Y*m_rctDstParent.Height + m_rctDstParent.Top;
			return pntFract;
		}

		public EPointF ConvParentLocToDrawLoc(EPointF a_pntLoc, Sprite a_spDraw)
		{
			if (m_spParent == null || (m_spParent!=null && m_spParent == a_spDraw))
				return a_pntLoc;

			a_pntLoc = m_spParent.ConvSrcLocToParentLoc(a_pntLoc);
			return m_spParent.ConvParentLocToDrawLoc(a_pntLoc, a_spDraw);
		}

		public EPointF ConvParentLocToRootLoc(EPointF a_pntLoc)
		{
			if (m_spParent == null)
				return a_pntLoc;

			return m_spParent.ConvParentLocToRootLoc(m_spParent.ConvSrcLocToParentLoc(a_pntLoc));
		}

		public EPointF MapPointFromRectAToRectB(EPointF a_pnt, ERectangleF a_rctA, ERectangleF a_rctB)
		{
			EPointF pntNew = new EPointF(a_pnt.X-a_rctA.Left, a_pnt.Y-a_rctA.Top);
			pntNew.X/=a_rctA.Width;
			pntNew.Y/=a_rctA.Height;

			pntNew.X = pntNew.X*a_rctB.Width + a_rctB.Left;
			pntNew.Y = pntNew.Y*a_rctB.Height + a_rctB.Top;
			return pntNew;
		}

		public EPointF ConvParentLocToSrcLoc(EPointF a_pntLoc)
		{
			return MapPointFromRectAToRectB(a_pntLoc, Rect, this.SourceRect.ToERectangleF());
		}

		public EPointF ConvRootLocToSrcLoc(EPointF a_pnt)
		{
			//convert a loc in root (normally stage) space to source space.
			//One calculation per link can make it slow in deep trees.
			if (Parent != null)
				a_pnt = Parent.ConvRootLocToSrcLoc(a_pnt);
			return ConvParentLocToSrcLoc(a_pnt);
		}
		public EPointF ConvRootLocToParentLoc(EPointF a_pnt)
		{
			if (Parent != null)
				a_pnt = Parent.ConvRootLocToSrcLoc(a_pnt);
			return a_pnt;
		}
		#endregion


		//TODO: I want to move these methods out to a BehaviorCollection, but I have to read about creating such classes first.
		//This is true for many collections throughout the project. Important: the owner of such a collection must be notified about adds/removes
		public void AddBehavior(Behavior bh)
		{
			m_aBehaviors.Add(bh);
			if (bh.Sprite != this)
				bh.Sprite = this;
		}
		public void RemoveBehavior(Behavior bh)
		{
			m_aBehaviors.Remove(bh);
			//TODO if (.Disposed == false), dispose it!
		}
		public bool HasBehavior(Behavior bh)
		{
			return m_aBehaviors.Contains(bh);
		}
		public int GetNumBehaviors()
		{
			return m_aBehaviors.Count;
		}
		public Behavior GetBehaviorByIndex(int i)
		{
			return (Behavior)m_aBehaviors[i];
		}

		public virtual void EnterFrame()
		{
			if (EnterFrameEvent!=null)
				EnterFrameEvent();

			m_renderStrategy.EnterFrame();

			m_bLooping = true;
			foreach (DataRowView row in m_dvChildrenLocZSorted)
			{
				Sprite sp = ((Sprite)m_plChildrenByHash[(int)row["Hash"]]);
				if (sp.Disposing)
					continue;
				sp.EnterFrame();
			}
			m_bLooping = false;

			foreach (Sprite sp in m_aChildrenToRemove)
				RemoveChild(sp);
			m_aChildrenToRemove.Clear();
		}
		public virtual void Draw()
		{
			if (!Visible)
				return;

			if ((Name != "root" && Member!=null) && m_bMeInvisibleButNotChildren == false) // && Visible
				m_renderStrategy.SubDraw();

			foreach (DataRowView row in m_dvChildrenLocZSorted) //m_dvChildrenLocZSorted m_dvChildrenLocZInverseSorted
				((Sprite)m_plChildrenByHash[(int)row["Hash"]]).Draw();
		}

		#region Parent/child relation methods
		public Sprite DrawToSprite
		{
			set {m_spDrawTarget = value; if (m_spParent == null) m_spParent = value;}
			get {return m_spDrawTarget;}
		}

		public Sprite Parent
		{
			get {return m_spParent;}
			set
			{
				if (m_spParent != null)
					m_spParent.RemoveChild(this);

				if (value != null)
				{
					m_spParent = value;
					m_spParent.AddChild(this);
				}
			}
		}
		public void AddChild(Sprite a_sp)
		{
			//Need a sorted list class that allows duplicate keys!
			DataRow row = m_dtChildren.NewRow();
			row["Name"] = a_sp.Name;
			row["LocZ"] = a_sp.LocZ;
			row["Hash"] = a_sp.GetHashCode();
			m_dtChildren.Rows.Add(row);

			m_plChildrenByHash[a_sp.GetHashCode()] = a_sp;
		}
		public void RemoveChild(Sprite a_sp)
		{
			if (m_bLooping)
			{
				m_aChildrenToRemove.Add(a_sp);
				return;
			}
			//DataRow[] rows = m_dtChildren.Select("Name = '"+a_sp.Name+"'");
			DataRow[] rows = m_dtChildren.Select("Hash = '"+a_sp.GetHashCode()+"'");
			if (rows.GetLength(0) > 0)
				m_dtChildren.Rows.Remove(rows[0]);

			m_plChildrenByHash.Remove(a_sp.GetHashCode());
		}
		protected void UpdateChildTableForChild(Sprite a_sp)
		{
			//Use when changing any one of the properties in the sprite that are used in m_dtChildren
			DataRow[] rows = m_dtChildren.Select("Hash = '"+a_sp.GetHashCode()+"'");
			if (rows.GetLength(0) > 0)
			{
				rows[0]["Name"] = a_sp.Name;
				rows[0]["LocZ"] = a_sp.LocZ;
			}
		}

		public int ChildCount
		{
			get {return m_plChildrenByHash.Count;}
		}
		public Sprite GetChildByName(string a_sName)
		{
			DataRow[] rows = m_dtChildren.Select("Name = '"+a_sName+"'");
			if (rows.GetLength(0) > 0)
			{
				int hash = (int)rows[0]["Hash"];
				return (Sprite)m_plChildrenByHash[hash];
			}
			return (Sprite)null;
		}
		public Sprite GetChildByIndex(int a_nIndex)
		{
			DataRowView row = m_dvChildrenLocZSorted[a_nIndex];
			return (Sprite)m_plChildrenByHash[(int)row["Hash"]];
		}
		public void GetChildHierarchyDebug(ref string sOutput, int nDepth)
		{
			string sIndent = "";
			nDepth++;
			for (int j = 0; j<nDepth; j++)
				sIndent+=" ";

			for (int i = 0; i < ChildCount; i++)
			{
				Sprite sp = GetChildByIndex(i);
				sOutput+=sIndent+sp.Name+"\r\n";
				sp.GetChildHierarchyDebug(ref sOutput, nDepth);
			}
		}
		public Sprite GetChildByHashCode(int a_hashCode)
		{
			Sprite sp = (Sprite)m_plChildrenByHash[a_hashCode];
			return sp;
		}
		#endregion
	}
}
