using System;

namespace Endogine
{
	/// <summary>
	/// Summary description for Behaviour.
	/// </summary>
	public class Behavior
	{
		protected Sprite m_sp = null;

		public Behavior(Sprite a_sp)
		{
			Sprite = a_sp;
		}

		public Behavior()
		{
		}

		public Sprite Sprite
		{
			set
			{
				RemoveFromSprite();
				m_sp = value;
				if (!m_sp.HasBehavior(this))
					m_sp.AddBehavior(this);
				m_sp.MouseEvent+=new Endogine.Sprite.MouseEventDelegate(Mouse);
				m_sp.EnterFrameEvent+=new Endogine.Sprite.EnterFrameEventDelegate(EnterFrame);
			}
			get
			{
				return m_sp;
			}
		}

		private void RemoveFromSprite()
		{
			if (m_sp == null)
				return;
			m_sp.MouseEvent-=new Endogine.Sprite.MouseEventDelegate(Mouse);
			m_sp.EnterFrameEvent-=new Endogine.Sprite.EnterFrameEventDelegate(EnterFrame);
			m_sp.RemoveBehavior(this);
		}

		public virtual void Dispose()
		{
			RemoveFromSprite();
		}

		protected virtual void Mouse(System.Windows.Forms.MouseEventArgs e, Endogine.Sprite.MouseEventType t)
		{

		}

		protected virtual void EnterFrame()
		{

		}
	}
}
