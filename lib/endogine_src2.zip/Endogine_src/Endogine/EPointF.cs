using System;
using System.Drawing;

namespace Endogine
{
	/// <summary>
	/// Summary description for EPointF.
	/// </summary>
	public class EPointF
	{
		public float X = 0;
		public float Y = 0;

		public EPointF()
		{
		}
		public EPointF(float x, float y)
		{
			X = x;
			Y = y;
		}
		public EPointF(int x, int y)
		{
			X = x;
			Y = y;
		}
		public EPointF(PointF pnt)
		{
			X = pnt.X;
			Y = pnt.Y;
		}
		public EPointF(Point pnt)
		{
			X = pnt.X;
			Y = pnt.Y;
		}
		public EPointF Copy()
		{
			return new EPointF(X,Y);
		}



		public EPoint ToEPoint()
		{
			return new EPoint((int)X,(int)Y);
		}
		public PointF ToPointF()
		{
			return new PointF(X,Y);
		}
		public Point ToPoint()
		{
			return new Point((int)X,(int)Y);
		}
		public SizeF ToSizeF()
		{
			return new SizeF(X,Y);
		}
		public Size ToSize()
		{
			return new Size((int)X,(int)Y);
		}



		public static EPointF operator -(EPointF p1, EPointF p2)
		{
			return new EPointF(p1.X-p2.X, p1.Y-p2.Y);
		}
		public static EPointF operator +(EPointF p1, EPointF p2)
		{
			return new EPointF(p1.X+p2.X, p1.Y+p2.Y);
		}
		public static EPointF operator *(EPointF p1, EPointF p2)
		{
			return new EPointF(p1.X*p2.X, p1.Y*p2.Y);
		}
		public static EPointF operator *(EPointF p1, float f)
		{
			return new EPointF(p1.X*f, p1.Y*f);
		}
		public static EPointF operator /(EPointF p1, EPointF p2)
		{
			return new EPointF(p1.X/p2.X, p1.Y/p2.Y);
		}
		public static EPointF operator /(EPointF p1, float f)
		{
			return new EPointF(p1.X/f, p1.Y/f);
		}

		public override bool Equals(object obj)
		{
			EPointF pnt = (EPointF)obj;
			return (pnt.X == X && pnt.Y == Y);
		}
		public override string ToString()
		{
			return "x="+X.ToString()+";y="+Y.ToString();
		}
	}
}
