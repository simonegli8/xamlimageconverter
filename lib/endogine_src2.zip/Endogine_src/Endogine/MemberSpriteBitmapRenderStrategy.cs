using System;
using System.Drawing;

namespace Endogine
{
	/// <summary>
	/// Summary description for MemberSpriteBitmapRenderStrategy.
	/// </summary>
	public abstract class MemberSpriteBitmapRenderStrategy
	{
		protected MemberSpriteBitmap m_mb;
		protected EndogineHub m_endogine;

		public void SetMemberBitmap(MemberSpriteBitmap a_mb)
		{
			m_mb = a_mb;
		}
		public void SetEndogine(EndogineHub a_endogine)
		{
			m_endogine = a_endogine;
		}

		abstract public void Load(string a_sFilename);
		abstract public void CreateFromBitmap(Bitmap a_bmp);
	}
}
