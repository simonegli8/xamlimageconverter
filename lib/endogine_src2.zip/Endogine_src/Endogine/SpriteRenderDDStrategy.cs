using System;
using System.Drawing;

namespace Endogine
{
	/// <summary>
	/// Summary description for SpriteRenderDDStrategy.
	/// </summary>
	public class SpriteRenderDDStrategy: SpriteRenderStrategy
	{
		public SpriteRenderDDStrategy()
		{}

		public override void Dispose()
		{
		}

		public override void Init()
		{
			if (m_endogine.Stage != null && m_endogine.Stage.RootSprite != null)
			{
				m_sp.DrawToSprite = m_endogine.Stage.RootSprite;
			}
		}

		public override void SetColor(Color a_clr)
		{
		}

		public override void SetMember(MemberBase a_mb)
		{
		}
		public override void SetMemberAnimationFrame(int a_n)
		{
		}
//		public override void SetSourceRect(ERectangle rct)
//		{
//		}
		public override void RecalcedParentOutput()
		{
		}



		public override void EnterFrame()
		{
		}

		public override void SubDraw() 
		{
			//if (m_surface != null)
			//m_lockedsurfacedata = m_surface.Lock(LockFlags.SurfaceMemoryPointer);

				ERectangleF rctDraw = m_sp.CalcRectInDrawTarget();
				RasterOps rasterops = new RasterOps();

			//TODO: MemberSpriteBitmap
				//rasterops.CopyPixels(((MemberDDSurface)m_sp.DrawToSprite.Member), (MemberDDSurface)m_sp.Member,
				//	rctDraw, m_sp.SourceRect, m_sp.DrawToSprite.SourceRect,
				//	m_sp.Ink, m_sp.Blend);
			//m_spDrawTarget.m_lockedsurfacedata

			//TODO not SourceRect, rctSrcClip!!!

			//if (m_surface != null && m_lockedsurfacedata.Width != 0)
			//	m_surface.Unlock();
		}
	}
}
