using System;
using System.Collections;
using System.Drawing;

namespace Endogine
{
	/// <summary>
	/// Summary description for InterpolatorColor.
	/// </summary>
	public class InterpolatorColor
	{
		private SortedList m_sorted;
		private ArrayList m_aInterpolators;

		public InterpolatorColor(SortedList a_colorKeyFrames)
		{
			m_sorted = a_colorKeyFrames;
			m_aInterpolators = new ArrayList();
			
			for (int i = 0; i < 3; i++)
			{
				Interpolator ip = new Interpolator();
				m_aInterpolators.Add(ip);
				SortedList a = new SortedList();
				for (int nClrNum = 0; nClrNum < m_sorted.Count; nClrNum++)
				{
					Color clr = (Color)m_sorted.GetByIndex(nClrNum);
					double dVal = 0;
					if (i == 0)
						dVal = clr.R;
					else if (i == 1)
						dVal = clr.G;
					else if (i == 2)
						dVal = clr.B;
					a.Add(m_sorted.GetKey(nClrNum), dVal);
				}
				ip.KeyFramesList = a;
			}
		}

		public void Dispose()
		{
			foreach (Interpolator ip in m_aInterpolators)
				ip.Dispose();
			m_aInterpolators.Clear();
			m_aInterpolators = null;

			m_sorted.Clear();
			m_sorted = null;
		}

		public Color GetValueAtTime(double a_dTime)
		{
			Color clr = Color.White;
			for (int i = 0; i < 3; i++)
			{
				double dVal = ((Interpolator)m_aInterpolators[i]).GetValueAtTime(a_dTime);
				if (i == 0)
					clr = Color.FromArgb((byte)dVal, clr.G, clr.B);
				else if (i == 1)
					clr = Color.FromArgb(clr.R, (byte)dVal, clr.B);
				else if (i == 2)
					clr = Color.FromArgb(clr.R, clr.G, (byte)dVal);
			}
			return clr;
		}

		public ArrayList GenerateList (double a_dFromTime, double a_dToTime, int a_nNumEntries)
		{
			ArrayList aList = new ArrayList();
			double dStep = (a_dToTime-a_dFromTime)/a_nNumEntries;
			for (int i = 0; i < a_nNumEntries; i++)
				aList.Add(GetValueAtTime(dStep*i+a_dFromTime));
			return aList;
		}
	}
}
