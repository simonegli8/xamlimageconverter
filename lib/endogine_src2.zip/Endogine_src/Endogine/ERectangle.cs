using System;
using System.Drawing;

namespace Endogine
{
	/// <summary>
	/// Summary description for ERectangle.
	/// </summary>
	public class ERectangle
	{
		public int X = 0;
		public int Y = 0;
		public int Width = 0;
		public int Height = 0;

		public ERectangle()
		{
		}
		public ERectangle(int x, int y, int width, int height)
		{
			X = x; Y = y; Width = width; Height = height;
		}
		public ERectangle(EPoint loc, EPoint size)
		{
			X = loc.X; Y = loc.Y; Width = size.X; Height = size.Y;
		}
		public ERectangle(Rectangle rct)
		{
			X = rct.X; Y = rct.Y; Width = rct.Width; Height = rct.Height;
		}


		public static ERectangle FromLTRB(int l, int t, int r, int b)
		{
			return new ERectangle(l,t, r-l, b-t);
		}

		public void Offset(EPoint pnt)
		{
			X+=pnt.X;
			Y+=pnt.Y;
		}
		public void Offset(int x, int y)
		{
			X+=x;
			Y+=y;
		}

		public EPoint Location
		{
			get {return new EPoint(X,Y);}
			set {X = value.X; Y = value.Y;}
		}
		public EPoint BottomRight
		{
			get {return new EPoint(X+Width,Y+Height);}
			set {Width = value.X-X; Y = value.Y-Y;}
		}
		public EPoint Middle
		{
			get {return new EPoint(X+Width/2,Y+Height/2);}
		}
		public EPoint Size
		{
			get {return new EPoint(Width, Height);}
			set {Width = value.X; Height = value.Y;}
		}
		public int Left
		{
			get {return X;}
			set {X = value;}
		}
		public int Top
		{
			get {return Y;}
			set {Y = value;}
		}
		public int Right
		{
			get {return X+Width;}
			set {Width = value-X;}
		}
		public int Bottom
		{
			get {return Y+Height;}
			set {Height = value-Y;}
		}

		public void Inflate(EPoint pnt)
		{
			Height = Math.Max(Height, pnt.X);
			Width = Math.Max(Width, pnt.Y);
		}
		public void Expand(ERectangle rct)
		{
			int r = Right;
			int b = Bottom;

			X = Math.Min(X, rct.X);
			Y = Math.Min(Y, rct.Y);

			Right = Math.Max(r, rct.Right);
			Bottom = Math.Max(b, rct.Bottom);
		}

		public void Normalize()
		{
			if (Width < 0)
			{
				Width=-Width;
				X = X-Width;
			}
			if (Height < 0)
			{
				Height=-Height;
				Y = Y-Height;
			}
		}
		public int GetArea()
		{
			return Width*Height;
		}
		public double GetHypo()
		{
			return Math.Sqrt(Width*Width + Height*Height);
		}


		public ERectangleF ToERectangleF()
		{
			return new ERectangleF(X,Y,Width,Height);
		}
		public Rectangle ToRectangle()
		{
			return new Rectangle(X,Y,Width,Height);
		}
		public RectangleF ToRectangleF()
		{
			return new RectangleF(X,Y,Width,Height);
		}

		public bool IsEmpty()
		{
			return (Width==0 && Height == 0);
		}
		public bool IsNegative()
		{
			return (Width<0 || Height < 0);
		}

		public ERectangle Copy()
		{
			return new ERectangle(X,Y,Width,Height);
		}
		public void Intersect(ERectangle rct)
		{
			int b = Bottom;
			int r = Right;
			X = Math.Max(rct.X, X);
			Y = Math.Max(rct.Y, Y);
			Bottom = Math.Min(rct.Bottom, b);
			Right = Math.Min(rct.Right, r);
		}
		public bool IntersectsWith(ERectangle rct)
		{
			ERectangle rctNew = this.Copy();
			rctNew.Intersect(rct);
			return !(rctNew.IsNegative() || rctNew.IsEmpty());
		}
		public bool Contains(EPoint pnt)
		{
			return (pnt.X >= Left && pnt.X <= Right && pnt.Y >= Top && pnt.Y <= Bottom);
		}

		public void MakePointInside(EPoint pnt)
		{
			pnt.X = Math.Max(pnt.X, X);
			pnt.X = Math.Min(pnt.X, Right);
			pnt.Y = Math.Max(pnt.Y, Y);
			pnt.Y = Math.Min(pnt.Y, Bottom);
		}
		public void WrapPointInside(EPoint pnt)
		{
			if (pnt.X < X)
				pnt.X = Right - (X - pnt.X);
			else if (pnt.X > Right)
				pnt.X = X + (pnt.X - Right);
			if (pnt.Y < Y)
				pnt.Y = Bottom - (Y - pnt.Y);
			else if (pnt.Y > Bottom)
				pnt.Y = Y + (pnt.Y - Bottom);
		}


		public static ERectangle operator +(ERectangle r1, ERectangle r2)
		{
			return new ERectangle(r1.X+r2.X, r1.Y+r2.Y, r1.Width+r2.Width, r1.Height+r2.Height);
		}

		public void Multiply(EPoint pnt)
		{
			X*=pnt.X;
			Y*=pnt.Y;
			Width*=pnt.X;
			Height*=pnt.Y;
		}
		public void Multiply(int val)
		{
			X*=val;
			Y*=val;
			Width*=val;
			Height*=val;
		}
	}
}
