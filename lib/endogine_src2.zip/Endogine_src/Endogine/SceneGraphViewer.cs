using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Endogine
{
	/// <summary>
	/// Summary description for SceneGraphViewer.
	/// </summary>
	public class SceneGraphViewer : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TreeView treeView1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem miView;

		private PropertyInspector m_pi;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem miMark;
		private System.Windows.Forms.MenuItem miDelete;
		private System.Windows.Forms.MenuItem miExport;
		private System.Windows.Forms.MenuItem miImport;

		private Hashtable m_htMarkers;
		private System.Windows.Forms.MenuItem miProperties;
		private System.Windows.Forms.MenuItem miOpenNodeInNew;
		private Hashtable m_htExpandedNodes;
		private System.Windows.Forms.MenuItem miCenterCamera;
		private System.Windows.Forms.MenuItem miLocScaleRot;

		private Sprite m_spRoot; //this window's root (doesn't have to be the stage's root)

		public SceneGraphViewer()
		{
			InitializeComponent();

			m_htExpandedNodes = new Hashtable();
			m_htMarkers = new Hashtable();

			MenuItem mi, miSub;
			
			mi = new MenuItem("Refresh");
			miView.MenuItems.Add(mi);
			mi.Shortcut = System.Windows.Forms.Shortcut.F5;
			mi = new MenuItem("&Filter...");
			miView.MenuItems.Add(mi);
			mi = new MenuItem("S&ort...");
			miView.MenuItems.Add(mi);
			mi = new MenuItem("&Group...");
			miView.MenuItems.Add(mi);
			mi = new MenuItem("-");
			miView.MenuItems.Add(mi);

			mi = new MenuItem("&Load preset");
			miView.MenuItems.Add(mi);
			miSub = new MenuItem("From file...");
			mi.MenuItems.Add(miSub);
			miSub = new MenuItem("Offscreen");
			mi.MenuItems.Add(miSub);
			miSub = new MenuItem("Invisible");
			mi.MenuItems.Add(miSub);
			miSub = new MenuItem("Scaled");
			mi.MenuItems.Add(miSub);
			miSub = new MenuItem("Rotated");
			mi.MenuItems.Add(miSub);

			mi = new MenuItem("&Save preset...");
			miView.MenuItems.Add(mi);

			foreach (MenuItem miViewItems in miView.MenuItems)
				miViewItems.Click+=new EventHandler(miViewItems_Click);

			EndogineHub endo = EndogineHub.Get();
			m_spRoot = endo.Stage.RootSprite;

			RefreshView();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.treeView1 = new System.Windows.Forms.TreeView();
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.miMark = new System.Windows.Forms.MenuItem();
			this.miDelete = new System.Windows.Forms.MenuItem();
			this.miProperties = new System.Windows.Forms.MenuItem();
			this.miOpenNodeInNew = new System.Windows.Forms.MenuItem();
			this.miCenterCamera = new System.Windows.Forms.MenuItem();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.miExport = new System.Windows.Forms.MenuItem();
			this.miImport = new System.Windows.Forms.MenuItem();
			this.miView = new System.Windows.Forms.MenuItem();
			this.miLocScaleRot = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// treeView1
			// 
			this.treeView1.ContextMenu = this.contextMenu1;
			this.treeView1.ImageIndex = -1;
			this.treeView1.Location = new System.Drawing.Point(0, 0);
			this.treeView1.Name = "treeView1";
			this.treeView1.SelectedImageIndex = -1;
			this.treeView1.Size = new System.Drawing.Size(288, 232);
			this.treeView1.TabIndex = 0;
			this.treeView1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeView1_MouseDown);
			this.treeView1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.treeView1_MouseUp);
			this.treeView1.DoubleClick += new System.EventHandler(this.treeView1_DoubleClick);
			this.treeView1.BeforeSelect += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView1_BeforeSelect);
			this.treeView1.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView1_BeforeExpand);
			// 
			// contextMenu1
			// 
			this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.miMark,
																						 this.miDelete,
																						 this.miProperties,
																						 this.miLocScaleRot,
																						 this.miCenterCamera,
																						 this.miOpenNodeInNew});
			// 
			// miMark
			// 
			this.miMark.Index = 0;
			this.miMark.Shortcut = System.Windows.Forms.Shortcut.CtrlM;
			this.miMark.Text = "Mark";
			this.miMark.Click += new System.EventHandler(this.miMark_Click);
			// 
			// miDelete
			// 
			this.miDelete.Index = 1;
			this.miDelete.Shortcut = System.Windows.Forms.Shortcut.Del;
			this.miDelete.Text = "Delete";
			this.miDelete.Click += new System.EventHandler(this.miDelete_Click);
			// 
			// miProperties
			// 
			this.miProperties.Index = 2;
			this.miProperties.Shortcut = System.Windows.Forms.Shortcut.F2;
			this.miProperties.Text = "Properties";
			this.miProperties.Click += new System.EventHandler(this.miProperties_Click);
			// 
			// miOpenNodeInNew
			// 
			this.miOpenNodeInNew.Index = 5;
			this.miOpenNodeInNew.Text = "Open in new window";
			this.miOpenNodeInNew.Click += new System.EventHandler(this.miOpenNodeInNew_Click);
			// 
			// miCenterCamera
			// 
			this.miCenterCamera.Index = 4;
			this.miCenterCamera.Text = "Center camera on it";
			this.miCenterCamera.Click += new System.EventHandler(this.miCenterCamera_Click);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.miView});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.miExport,
																					  this.miImport});
			this.menuItem1.Text = "File";
			// 
			// miExport
			// 
			this.miExport.Index = 0;
			this.miExport.Text = "Export...";
			this.miExport.Click += new System.EventHandler(this.miExport_Click);
			// 
			// miImport
			// 
			this.miImport.Index = 1;
			this.miImport.Text = "Import...";
			this.miImport.Click += new System.EventHandler(this.miImport_Click);
			// 
			// miView
			// 
			this.miView.Index = 1;
			this.miView.Text = "View";
			// 
			// miLocScaleRot
			// 
			this.miLocScaleRot.Index = 3;
			this.miLocScaleRot.Text = "Loc/Scale/Rot control";
			this.miLocScaleRot.Click += new System.EventHandler(this.miLocScaleRot_Click);
			// 
			// SceneGraphViewer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(288, 241);
			this.Controls.Add(this.treeView1);
			this.Menu = this.mainMenu1;
			this.Name = "SceneGraphViewer";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "SceneGraphViewer";
			this.Activated += new System.EventHandler(this.SceneGraphViewer_Activated);
			this.ResumeLayout(false);

		}
		#endregion

		private void btnUpdate_Click(object sender, System.EventArgs e)
		{
			RefreshView();
		}

		public void SetRootSprite(Sprite sp)
		{
			m_spRoot = sp;
			RefreshView();
		}

		public void RefreshView()
		{
			m_htExpandedNodes = new Hashtable();
			if (treeView1.Nodes.Count > 0)
			{
				//remember which nodes were expanded, so the view looks the same after an update!
				RecurseGetExpandedNodes(treeView1.Nodes[0], ref m_htExpandedNodes);
				
				treeView1.Nodes.Clear();
			}

			RecurseAddNodes((TreeNode)null, m_spRoot, -1);

			if (m_htExpandedNodes.Count > 0)
				RecurseExpandNodes(treeView1.Nodes[0], m_htExpandedNodes);
		}

		private void RecurseExpandNodes(TreeNode a_node, Hashtable a_ht)
		{
			if (m_htMarkers.ContainsKey(a_node.Tag))
			{
				a_node.Text = "!! "+a_node.Text;
			}

			if (a_ht.ContainsKey(a_node.Tag))
			{
				a_node.Expand();
				Hashtable htSub = (Hashtable)a_ht[a_node.Tag];
				foreach (TreeNode child in a_node.Nodes)
				{
					RecurseExpandNodes(child, htSub);
				}
			}
		}

		private void RecurseGetExpandedNodes(TreeNode a_node, ref Hashtable a_ht)
		{
			Hashtable htSub = new Hashtable();

			if (a_node.IsExpanded)
				a_ht.Add(a_node.Tag, htSub);

			foreach (TreeNode child in a_node.Nodes)
			{
				if (child.IsExpanded)
				{
					RecurseGetExpandedNodes(child, ref htSub);
				}
			}
		}

		private void RecurseAddNodes(TreeNode a_node, Sprite a_sp, int a_nNumRecurseLevels)
		{
			//show name, member name, and class name
			
			string sText = a_sp.GetSceneGraphName(); //a_sp.Name +  "/";
//			if (a_sp.Member != null)
//				sText+=a_sp.Member.Name;
//			sText+= ":"+a_sp.ToString().Replace("Endogine", ""); //remove "Endogine" from class name, it's understood...

			TreeNode newNode = new TreeNode(sText);
			newNode.Tag = a_sp.GetHashCode();

			//TreeNode oldSelected = treeView1.SelectedNode;
			if (a_node == null)
				treeView1.Nodes.Add(newNode);
			else
				a_node.Nodes.Add(newNode); //treeView1.SelectedNode.Nodes.Add(newNode);

			//treeView1.SelectedNode = newNode;


			if (a_nNumRecurseLevels > 0)
				a_nNumRecurseLevels--;
			for (int i = 0; i < a_sp.ChildCount; i++)
			{
				Sprite sp = a_sp.GetChildByIndex(i);
				if (a_nNumRecurseLevels == -1 || a_nNumRecurseLevels > 0)
					RecurseAddNodes(newNode, sp, a_nNumRecurseLevels);
			}

			//treeView1.SelectedNode.Collapse();

			//if (oldSelected != null)
			//	treeView1.SelectedNode = oldSelected;
		}

		private void treeView1_BeforeExpand(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			/*if (e.Node.Nodes.Count > 0)
				e.Node.Nodes.Clear();
			treeView1.SelectedNode = e.Node;
			//RecurseAddNodes();*/
		}

		private void treeView1_BeforeSelect(object sender, System.Windows.Forms.TreeViewCancelEventArgs e)
		{
			//MarkedNode(e.Node);
		}


		private void miViewItems_Click(object sender, EventArgs e)
		{
			MenuItem mi = (MenuItem)sender;
			switch (mi.Text)
			{
				case "Refresh":
					RefreshView();
					break;
				case "&Filter...":
					//TODO: make dataTable with all sprites and all their props, use SQL SELECTs
					break;
				case "S&ort...":
					break;
				case "&Group...":
					break;
				case "&Load view...":
					break;
				case "&Save view...":
					break;
			}
		}

		private TreeNode RecurseGetNode(int a_nSpriteHash, TreeNodeCollection nodes)
		{
			foreach (TreeNode node in nodes)
			{
				if (a_nSpriteHash == (int)node.Tag)
					return node;
				if (node.Nodes.Count > 0)
				{
					TreeNode foundNode = RecurseGetNode(a_nSpriteHash, node.Nodes);
					if (foundNode != null)
						return foundNode;
				}
			}
			return (TreeNode)null;
		}
		private TreeNode NodeFromSprite(Sprite a_sp)
		{
			int nHash = a_sp.GetHashCode();
			//TreeNodeCollection nodes = treeView1.Nodes;
			return RecurseGetNode(nHash, treeView1.Nodes);
		}
		private Sprite SpriteFromNode(TreeNode a_node)
		{
			//find out which sprite the node refers to.
			//start at root sprite, then walk the hierarchy to find sprite
			TreeNode parent = a_node;
			ArrayList aHierarchy = new ArrayList();
			for (;;)
			{
				aHierarchy.Insert(0, parent);
				if (parent.Parent == null)
					break;
				parent = parent.Parent;
			}
			aHierarchy.RemoveAt(0); //we know that the first in hierarchy is the root sprite.

			Sprite sp = m_spRoot;
			bool bFoundIt = true;
			foreach (TreeNode node in aHierarchy)
			{
				int hash = (int)node.Tag;
				Sprite spChild = sp.GetChildByHashCode(hash);
				if (spChild == null)
				{
					//TODO: messagebox doesn't appear for some reason...
					//MessageBox.Show("Sprite has been deleted or moved");
					bFoundIt = false;
					break;
				}
				else
					sp = spChild;
			}
			if (bFoundIt)
				return sp;
			return (Sprite)null;
		}

		public void MarkSprite(Sprite sp)
		{
			MarkedNode(this.NodeFromSprite(sp));
		}
		public void MarkedNode(TreeNode a_node)
		{
			if (a_node == null)
				return;

			Sprite sp = SpriteFromNode(a_node);
			if (sp!=null)
			{
				if (m_htMarkers.ContainsKey(sp.GetHashCode()))
				{
					BhSpriteMarker bhMarker = (BhSpriteMarker)m_htMarkers[sp.GetHashCode()];
					m_htMarkers.Remove(sp.GetHashCode());
					bhMarker.Dispose();
					a_node.Text = a_node.Text.Replace("!! ", "");
				}
				else
				{
					BhSpriteMarker bhMarker = new BhSpriteMarker();
					sp.AddBehavior(bhMarker);
					m_htMarkers.Add(sp.GetHashCode(), bhMarker);
					a_node.Text = "!! "+a_node.Text;
				}
				//sp.Color = Color.FromArgb(255,0,0);
			}
		}
		private void treeView1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
//			TreeNode node = treeView1.GetNodeAt(e.X, e.Y);
//			if (node == null)
//				return;
//			if (treeView1.SelectedNode == node)
//				MarkedNode(node);
		}

		public void SelectSprite(Sprite sp)
		{
			TreeNode node = NodeFromSprite(sp);
			if (node != null)
				treeView1.SelectedNode = node;
		}

		private void miMark_Click(object sender, System.EventArgs e)
		{
			if (treeView1.SelectedNode == null)
				return;
			MarkedNode(treeView1.SelectedNode);
		}

		private void miDelete_Click(object sender, System.EventArgs e)
		{
		
		}

		private void miExport_Click(object sender, System.EventArgs e)
		{
			SaveFileDialog dlg = new SaveFileDialog();
			dlg.Filter = "Endogine/Director (*.sgr)|*.sgr|All files|*.*";
			if(dlg.ShowDialog() == DialogResult.OK)
			{
			}
		}

		private void miImport_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog dlg = new OpenFileDialog();
			dlg.Filter = "Endogine/Director (*.sgr)|*.sgr|Photoshop (*.psd)|*.psd|Flash (*.swf)|*.swf|All files|*.*";
			//dlgOpenFile.ShowReadOnly = true;
			if(dlg.ShowDialog() == DialogResult.OK)
			{
				//TODO: why doesn't it work to show this messagebox?
			//	if (MessageBox.Show(this, "Merge with current scene (otherwise replace)?", "Merge or replace", MessageBoxButtons.YesNo,
			//		MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.No)
			}
		}

		private void SceneGraphViewer_Activated(object sender, System.EventArgs e)
		{
			RefreshView();
		}

		private void treeView1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				treeView1.SelectedNode = treeView1.GetNodeAt(e.X, e.Y);
			}
		}


		private void treeView1_DoubleClick(object sender, System.EventArgs e)
		{
		}

		private void miProperties_Click(object sender, System.EventArgs e)
		{
			if (treeView1.SelectedNode == null)
				return;

			Sprite sp = SpriteFromNode(treeView1.SelectedNode);
			if (sp!=null)
			{
				if (m_pi == null || m_pi.IsDisposed)
				{
					m_pi = new PropertyInspector();
					m_pi.MdiParent = this.MdiParent;
				}
				m_pi.Show();
				m_pi.ShowProperties(sp);
			}
		}

		private void miOpenNodeInNew_Click(object sender, System.EventArgs e)
		{
			if (treeView1.SelectedNode == null)
				return;

			Sprite sp = SpriteFromNode(treeView1.SelectedNode);

			SceneGraphViewer scgrvw = new SceneGraphViewer();
			scgrvw.MdiParent = this.MdiParent;
			scgrvw.SetRootSprite(sp);
			scgrvw.Show();
		}

		private void miCenterCamera_Click(object sender, System.EventArgs e)
		{
			if (treeView1.SelectedNode == null)
				return;

			Sprite sp = SpriteFromNode(treeView1.SelectedNode);
			EPointF pnt = sp.ConvParentLocToRootLoc(sp.Loc);
			EndogineHub endo = EndogineHub.Get();
			EPointF pntSize = new EPointF(endo.Stage.RenderControl.Width, endo.Stage.RenderControl.Height);
			endo.Stage.Camera.Loc = pnt+endo.Stage.Camera.Loc - pntSize*0.5f;
		}

		private void miLocScaleRot_Click(object sender, System.EventArgs e)
		{
			LocScaleRotEdit ctrl = new LocScaleRotEdit();
			Sprite sp = SpriteFromNode(treeView1.SelectedNode);
			ctrl.EditSprite = sp;
			ctrl.MdiParent = this.MdiParent;
			ctrl.Show();
		}
	}
}
