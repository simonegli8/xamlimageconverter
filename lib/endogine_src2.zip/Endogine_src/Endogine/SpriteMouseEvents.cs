using System;

namespace Endogine
{
	/// <summary>
	/// Summary description for SpriteMouseEvents.
	/// </summary>
	public class SpriteMouseEvents
	{
		protected Sprite m_sp;
		protected bool m_bActive;
		public SpriteMouseEvents(Sprite a_sp)
		{
			m_sp = a_sp;
			m_bActive = true;
		}


		public bool Active
		{
			get {return m_bActive;}
			set {m_bActive = value;}
		}
	}
}
