using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Endogine
{
	/// <summary>
	/// Summary description for BehaviorInspector.
	/// </summary>
	public class BehaviorInspector : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Label lblDescrHead;
		private System.Windows.Forms.Label lblDescription;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Button btnAdd;
		private System.Windows.Forms.Button btnRemove;
		private System.Windows.Forms.Button btnProps;

		private Sprite m_sp;

		public BehaviorInspector()
		{
			InitializeComponent();
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.lblDescrHead = new System.Windows.Forms.Label();
			this.lblDescription = new System.Windows.Forms.Label();
			this.btnAdd = new System.Windows.Forms.Button();
			this.btnRemove = new System.Windows.Forms.Button();
			this.btnProps = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(0, 0);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(184, 95);
			this.listBox1.TabIndex = 0;
			// 
			// lblDescrHead
			// 
			this.lblDescrHead.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblDescrHead.Location = new System.Drawing.Point(0, 104);
			this.lblDescrHead.Name = "lblDescrHead";
			this.lblDescrHead.Size = new System.Drawing.Size(100, 16);
			this.lblDescrHead.TabIndex = 1;
			this.lblDescrHead.Text = "Description";
			// 
			// lblDescription
			// 
			this.lblDescription.Location = new System.Drawing.Point(0, 120);
			this.lblDescription.Name = "lblDescription";
			this.lblDescription.TabIndex = 2;
			this.lblDescription.Text = "label1";
			// 
			// btnAdd
			// 
			this.btnAdd.Location = new System.Drawing.Point(192, 0);
			this.btnAdd.Name = "btnAdd";
			this.btnAdd.Size = new System.Drawing.Size(72, 23);
			this.btnAdd.TabIndex = 3;
			this.btnAdd.Text = "Add...";
			this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
			// 
			// btnRemove
			// 
			this.btnRemove.Location = new System.Drawing.Point(192, 24);
			this.btnRemove.Name = "btnRemove";
			this.btnRemove.Size = new System.Drawing.Size(72, 23);
			this.btnRemove.TabIndex = 4;
			this.btnRemove.Text = "Remove";
			this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
			// 
			// btnProps
			// 
			this.btnProps.Location = new System.Drawing.Point(192, 64);
			this.btnProps.Name = "btnProps";
			this.btnProps.Size = new System.Drawing.Size(72, 23);
			this.btnProps.TabIndex = 5;
			this.btnProps.Text = "Properties...";
			// 
			// BehaviorInspector
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.Add(this.btnProps);
			this.Controls.Add(this.btnRemove);
			this.Controls.Add(this.btnAdd);
			this.Controls.Add(this.lblDescription);
			this.Controls.Add(this.lblDescrHead);
			this.Controls.Add(this.listBox1);
			this.Name = "BehaviorInspector";
			this.Text = "BehaviorInspector";
			this.ResumeLayout(false);

		}
		#endregion

		public void SetSprite(Sprite a_sp)
		{
			m_sp = a_sp;
			RefreshView();
		}

		public void RefreshView()
		{
			listBox1.Items.Clear();
			int nNumBhs = m_sp.GetNumBehaviors();
			for (int i = 0; i < nNumBhs; i++)
			{
				Behavior bh = (Behavior)m_sp.GetBehaviorByIndex(i);
				listBox1.Items.Add(bh.ToString());
			}
		}
		private void btnRemove_Click(object sender, System.EventArgs e)
		{
			if (listBox1.SelectedItem == null)
				return;
			Behavior bh = (Behavior)m_sp.GetBehaviorByIndex(listBox1.SelectedIndex);
			bh.Dispose();
			//m_sp.RemoveBehavior();
			RefreshView();
		}

		private void btnAdd_Click(object sender, System.EventArgs e)
		{
			//TODO: How to dynamically create an object from a string? Use scripting engine? Or a factory?
			//TODO: How to find all behavior classes? Search in a separate folder? Or register somehow?
		}
	}
}
