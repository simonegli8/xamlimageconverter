using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;

namespace Endogine
{
	/// <summary>
	/// Summary description for MemberBitmapBase.
	/// </summary>
	public abstract class MemberBitmapBase : MemberBase
	{
		protected EPoint m_pntRegPoint;

		protected EPoint m_sizeAnimateWithin;
		protected EPoint m_sizeTotal; //The full size of the bitmap (if it's a bitmap with many frames, it's the size of the whole bitmap, not just a frame)
		protected int m_nNumFramesOnX;
		protected int m_nNumFramesTotal = 0;
		protected int m_nAnimationFrame = 0;
		protected bool m_bGotAnimation = false;
		protected bool m_bAutoAnimate = false;
		protected Color m_clrKey;

		static string DummyFilename; //this file is to be used when resource isn't found

		public MemberBitmapBase()
		{
			m_clrKey = Color.FromArgb(255,255,255);
			m_pntRegPoint = new EPoint(0,0);
			m_sizeAnimateWithin = new EPoint(0,0);
			m_sizeTotal = new EPoint(0,0);
		}


		public virtual EPoint Size
		{
			get
			{
				if (GotAnimation)
					return this.AnimateWithinSize;
				return this.TotalSize;
			}
			//set {}
		}

		public virtual EPoint TotalSize
		{ get {return m_sizeTotal;}}

		public EPoint AnimateWithinSize
		{
			get {return m_sizeAnimateWithin;}
			set 
			{
				m_bAutoAnimate = true;
				m_sizeAnimateWithin = value;
				m_bGotAnimation = true;

				if (m_nNumFramesOnX == 0)
				{
					m_nNumFramesOnX = TotalSize.X/AnimateWithinSize.X;
					m_nNumFramesTotal = m_nNumFramesOnX*TotalSize.Y/AnimateWithinSize.Y;
				}
			}
		}


		public abstract Bitmap Bitmap
		{ get; set; }

		public Bitmap _FriendLoadIntoBitmap(string a_sFilename)
		{
			a_sFilename = m_endogine.CastLib.FindFile(a_sFilename);

			System.IO.FileInfo finfo = new System.IO.FileInfo(a_sFilename);

			Name = finfo.Name.Replace(finfo.Extension, "");
			FileFullName = a_sFilename;

			if (a_sFilename.Length == 0)
			{
				if (m_endogine.CastLib.UseDummiesForFilesNotFound)
				{
					//a_sFilename = this.
				}
			}
			
			if (!finfo.Exists)
			{
				throw new System.IO.FileNotFoundException("Member file not found: "+a_sFilename);
			}

			//TODO: only allow >= 24 bpp PixelFormat.Format8bppIndexed - otherwise convert!

			Bitmap bmpDst = null;
			bool bStandardLoad = true;
			if (a_sFilename.IndexOf(".gif") > 0)
			{
				Image img = System.Drawing.Image.FromFile(a_sFilename);
				System.Drawing.Imaging.FrameDimension oDimension = new System.Drawing.Imaging.FrameDimension(img.FrameDimensionsList[0]);
				int nNumFrames = img.GetFrameCount(oDimension);

				//calc how big the destination bitmap must be (make it as square as possible)
				//TODO: it's OK if there's a few uninhabited tiles at end?
				int nNumFramesOnX = (int)Math.Sqrt(nNumFrames);
				for (; nNumFramesOnX > 0; nNumFramesOnX--)
				{
					if (nNumFrames/nNumFramesOnX*nNumFramesOnX == nNumFrames)
						break;
				}
				
				bmpDst = new Bitmap(
					img.Size.Width*nNumFramesOnX, img.Size.Height*nNumFrames/nNumFramesOnX,
					PixelFormat.Format24bppRgb);
				Graphics g = Graphics.FromImage(bmpDst);
				
				if (nNumFrames > 1)
				{
					bStandardLoad = false;
					for(int i = 0; i < nNumFrames; i++)
					{
						int x = i%nNumFramesOnX;
						int y = i/nNumFramesOnX;
						img.SelectActiveFrame(oDimension, i); 
						g.DrawImageUnscaled(img, x*img.Size.Width, y*img.Size.Height, img.Size.Width, img.Size.Height);
					}
					g.Dispose();
					
					m_nNumFramesOnX = nNumFramesOnX;
					if (m_nNumFramesTotal == 0)
						m_nNumFramesTotal = nNumFrames;
					AnimateWithinSize = new EPoint(img.Size.Width, img.Size.Height);
				}
				img.Dispose();
			}

			if (!bStandardLoad)
			{
			}
			else
			{
				bmpDst = (Bitmap)System.Drawing.Bitmap.FromFile(a_sFilename);
			}

			m_sizeTotal = new EPoint(bmpDst.Width, bmpDst.Height);

			return bmpDst;
		}



		public EPoint RegPoint
		{
			get {return m_pntRegPoint;}
			set
			{
				m_pntRegPoint = value;
				//TODO: tell sprites to invalidate!
			}
		}

		public void CenterRegPoint()
		{
			m_pntRegPoint = new EPoint(Size.X/2, Size.Y/2);
		}

		public virtual void Fill()
		{}

		



		public bool AutoAnimate
		{ get {return m_bAutoAnimate;}
			set {m_bAutoAnimate = value;}
		}
		public bool GotAnimation
		{ get {return m_bGotAnimation;}}
		
		public int NumAnimationFrames
		{
			get {return m_nNumFramesTotal;}
			set
			{
				m_nNumFramesTotal = value; //TODO: check that it doesn't exceed possible num frames!
			}
		}
		public ERectangle GetRectForFrame(int a_nFrameNum)
		{
			if (m_bGotAnimation)
			{
				a_nFrameNum = a_nFrameNum%m_nNumFramesTotal;

				EPoint pnt = new EPoint((a_nFrameNum%m_nNumFramesOnX)*m_sizeAnimateWithin.X, (a_nFrameNum/m_nNumFramesOnX)*m_sizeAnimateWithin.Y);
				return new ERectangle(pnt, m_sizeAnimateWithin);
			}
			return new ERectangle(0,0, m_sizeTotal.X,m_sizeTotal.Y);
		}



		public Color ColorKey
		{
			get {return m_clrKey;}
			set {m_clrKey = value;}
		}

		public EPoint GetUpperPowerTextureSize(EPoint a_size)
		{
			EPoint sizeReturn = new EPoint();
			SortedList aAllowedSizes = new SortedList();
			int n = 4;
			for (int i = 0; i < 10; i++)
			{
				aAllowedSizes.Add(n,i);
				n*=2;
			}

			int nVal = a_size.X;
			for (int i = 0; i < 2; i++)
			{
				aAllowedSizes.Add(nVal, -1);
				int nIndex = aAllowedSizes.IndexOfValue(-1);
				aAllowedSizes.RemoveAt(nIndex);
				if (nIndex > aAllowedSizes.Count)
					nIndex--;
				nVal = Convert.ToInt32(aAllowedSizes.GetKey(nIndex));
				if (i == 0)
					sizeReturn.X = nVal;
				else
					sizeReturn.Y = nVal;

				nVal = a_size.Y;
			}
			return sizeReturn;
		}

		public bool GotAlpha
		{
			get {return false;}
		}
	}
}
