using System;
using System.Windows.Forms;
using Microsoft.DirectX;
using Microsoft.DirectX.DirectDraw;
using System.Drawing;

namespace Endogine
{
	/// <summary>
	/// Summary description for Stage.
	/// </summary>
	public class StageDD : StageBase
	{
		protected Control target           = null;
		protected Device  graphicsDevice   = null;
		protected Clipper graphicsClipper  = null;
		protected Surface surfacePrimary   = null;
		protected Surface surfaceSecondary = null;

		protected long m_nTicks;
		//public Sprite2D spRoot = null;
		//private SpriteAnimate m_main;

		/// <summary>
		/// The DirectDraw Device
		/// </summary>
		public Device DDDevice
		{
			get
			{
				return graphicsDevice;
			}
		}

		/// <summary>
		/// This surface can be accessed to render to.
		/// </summary>
		public Surface RenderSurface
		{
			get
			{
				return surfaceSecondary;
			}
		}

		/// <summary>
		/// Constructor. Initializes DirectDraw Device
		/// and surfaces.
		/// </summary>
		/// <param name="RenderControl">
		/// The control the device is connected to.
		/// </param>
		public StageDD(Control RenderControl, EndogineHub a_endogine) : base(RenderControl, a_endogine)
		{
			// Create DirectDraw device
			graphicsDevice = new Device();

#if DEBUG
			// In debug mode, use windowed level
			graphicsDevice.SetCooperativeLevel(m_renderControl, CooperativeLevelFlags.Normal);
#else
			graphicsDevice.SetCooperativeLevel(this.target, CooperativeLevelFlags.Normal);
			// In release mode, use fullscreen...
/*			graphicsDevice.SetCooperativeLevel(this.target, CooperativeLevelFlags.FullscreenExclusive);

			// ...and 640x480x16 resolution with 85Hz frequency
			graphicsDevice.SetDisplayMode(640, 480, 16, 85, true);
*/
#endif

		}

		public override void Init()
		{
			this.CreateRootSprite(new ERectangle(0,0, m_renderControl.Width, m_renderControl.Height));

			this.createSurfaces();

			m_nTicks = DateTime.Now.Millisecond;
		}

		/// <summary>
		/// This method creates the primary and secondary surfaces
		/// </summary>
		protected void createSurfaces()
		{
			// Every surface needs a description
			// This is where you set the parameters for the surface
			SurfaceDescription desc = new SurfaceDescription();
			
			// First we want to create a primary surface
			desc.SurfaceCaps.PrimarySurface = true;

#if !DEBUG
			// In release mode, we enable flipping, set the complex
			// flag and tell the surface that we will use one back
			// buffer
			/*desc.SurfaceCaps.Flip = true;
			desc.SurfaceCaps.Complex = true;
			desc.BackBufferCount = 1;
*/
#endif

			// Create the surface
			surfacePrimary = new Surface(desc, graphicsDevice);

			// To build the secondary surface, we need 
			// a new description -> clear all values
			desc.Clear();

#if DEBUG
			// In debug mode, we simply copy the primary surfaces
			// dimensions and create a offscreenplain secondary
			// surface
			desc.Width = surfacePrimary.SurfaceDescription.Width;
			desc.Height = surfacePrimary.SurfaceDescription.Height;
			desc.SurfaceCaps.OffScreenPlain = true;
			surfaceSecondary = new Surface(desc, this.graphicsDevice);
#else
			desc.Width = surfacePrimary.SurfaceDescription.Width;
			desc.Height = surfacePrimary.SurfaceDescription.Height;
			desc.SurfaceCaps.OffScreenPlain = true;
			surfaceSecondary = new Surface(desc, this.graphicsDevice);
			// In release mode, we set the backbuffer flag to true
			// and retrieve a backbuffer surface from the primary
			// surface
/*			desc.SurfaceCaps.BackBuffer = true;
			surfaceSecondary = surfacePrimary.GetAttachedSurface(desc.SurfaceCaps);
*/
#endif

			// This is the clipper for the secondary surface
			// -> connect it to the target control
			graphicsClipper = new Clipper(graphicsDevice);
			graphicsClipper.Window = m_renderControl;

			// Attach clipper to the surface
			surfacePrimary.Clipper = this.graphicsClipper;

			SurfaceDescription descr = new SurfaceDescription();
			descr.Width = m_renderControl.Size.Width;
			descr.Height = m_renderControl.Size.Height;
			//MemberDDSurface mb = new MemberDDSurface(m_endogine, descr);
			//TODO: MemberSpriteBitmap m_spRoot.Member = mb;
		}

		public override void UpdateStage()
		{
			// First we check if the target control
			// is created yet.
			if (!m_renderControl.Created)
			{
				return;
			}

			// Now check if both surfaces are there.
			if (surfacePrimary == null || surfaceSecondary == null)
			{
				return;
			}
			

			//((MemberBitmapBase)spRoot.Member).Fill();
			m_spRoot.EnterFrame();
			m_spRoot.Draw();


			ERectangle rct = m_spRoot.RectInt;
			Point pntScreenTopLeft = m_renderControl.PointToScreen(new System.Drawing.Point(0,0));
			rct.X+=pntScreenTopLeft.X;
			rct.Y+=pntScreenTopLeft.Y;
			//TODO: MemberSpriteBitmap
			//surfaceSecondary.Draw(rct, ((MemberDDSurface)m_spRoot.Member).Surface, m_spRoot.SourceRect, DrawFlags.DoNotWait);

			try
			{
				//put some text on the screen:
				surfaceSecondary.ForeColor = Color.White;
				long nDiff = DateTime.Now.Millisecond - m_nTicks;
				m_nTicks = DateTime.Now.Millisecond;
				surfaceSecondary.DrawText(10+pntScreenTopLeft.X, 30+pntScreenTopLeft.Y, "Press Esc to exit " + nDiff.ToString(), false);

				//debug output:
				//surfaceSecondary.DrawText(10+pntScreenTopLeft.X, 60+pntScreenTopLeft.Y, sDebug, false);
			}
			catch (Exception e)
			{
				string s = e.Message;
			}



			// Try to Draw or Flip, depending on compile mode
			try
			{
#if DEBUG
				surfacePrimary.Draw(surfaceSecondary, DrawFlags.Wait);
#else
				surfacePrimary.Draw(surfaceSecondary, DrawFlags.Wait);
				//surfacePrimary.Flip(surfaceSecondary, FlipFlags.Wait);
#endif
			}
			catch (SurfaceLostException)
			{
				// On activation of power saving mode 
				// and in other situations we may lose the surfaces
				// and have to recreate them
				this.createSurfaces();
			}

			surfaceSecondary.ColorFill(0);
		}
		/// <summary>
		/// This method flips the secondary surface to the
		/// primary one, thus drawing its content to the screen.
		/// </summary>
		public void Flip()
		{
			// First we check if the target control
			// is created yet.
			if (!this.target.Created)
			{
				return;
			}

			// Now check if both surfaces are there.
			if (surfacePrimary == null || surfaceSecondary == null)
			{
				return;
			}

			// Try to Draw or Flip, depending on compile mode
			try
			{
#if DEBUG
				surfacePrimary.Draw(surfaceSecondary, DrawFlags.Wait);
#else
				surfacePrimary.Draw(surfaceSecondary, DrawFlags.Wait);
				//surfacePrimary.Flip(surfaceSecondary, FlipFlags.Wait);
#endif
			}
			catch (SurfaceLostException)
			{
				// On activation of power saving mode 
				// and in other situations we may lose the surfaces
				// and have to recreate them
				this.createSurfaces();
			}
		}
	}
}
