using System;
using System.Drawing;

namespace Endogine
{
	/// <summary>
	/// Summary description for SpriteRenderStrategy.
	/// </summary>
	public abstract class SpriteRenderStrategy
	{
		protected EndogineHub m_endogine;
		protected Sprite m_sp;

		public void SetEndogine(EndogineHub a_endogine)
		{
			m_endogine = a_endogine;
		}
		public void SetSprite(Sprite a_sp)
		{
			m_sp = a_sp;
		}
		abstract public void Dispose();

		abstract public void Init();
		

		abstract public void SetColor(Color a_clr);
		abstract public void EnterFrame();
		abstract public void SetMember(MemberBase a_mb);
		abstract public void SetMemberAnimationFrame(int n);
//		abstract public void SetSourceRect(ERectangle rct);
		abstract public void RecalcedParentOutput();
		abstract public void SubDraw();
	}
}
