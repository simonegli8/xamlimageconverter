using System;
using System.Drawing;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX.DirectDraw;

namespace Endogine
{
	/// <summary>
	/// Bitmap media for sprites. If it's a D3D sprite, a texture is used. If it's a DD sprite, a DD surface is used. GDI+
	/// </summary>
	public class MemberSpriteBitmap : MemberBitmapBase
	{
		protected MemberSpriteBitmapRenderStrategy m_renderStrategy;

		public MemberSpriteBitmap(string a_sFilename)
		{
			AutoSetStrategy();
			m_renderStrategy.Load(a_sFilename);
		}

		public MemberSpriteBitmap(Bitmap a_bmp)
		{
			AutoSetStrategy();
			Bitmap = a_bmp;
		}

		protected void AutoSetStrategy()
		{
			if (m_endogine.CurrentRenderStrategy == EndogineHub.RenderStrategy.D3D)
				m_renderStrategy = new MemberSpriteBitmapRender3DStrategy();
			else if (m_endogine.CurrentRenderStrategy == EndogineHub.RenderStrategy.DD)
				m_renderStrategy = new MemberSpriteBitmapRenderDDStrategy();
			else
				m_renderStrategy = new MemberSpriteBitmapRenderGDIStrategy();
			
			m_renderStrategy.SetMemberBitmap(this);
			m_renderStrategy.SetEndogine(m_endogine);
		}

		public void CreateFromSurfaceDescription(Microsoft.DirectX.DirectDraw.SurfaceDescription a_desc)
		{
			if (m_endogine.CurrentRenderStrategy == EndogineHub.RenderStrategy.DD)
				((MemberSpriteBitmapRenderDDStrategy)m_renderStrategy).CreateSurface(a_desc);
		}

		public override Bitmap Bitmap
		{
			get
			{
				if (m_endogine.CurrentRenderStrategy == EndogineHub.RenderStrategy.GDI)
					return ((MemberSpriteBitmapRenderGDIStrategy)m_renderStrategy).GetBitmap();
				return (Bitmap)null;
			}
			set
			{
				m_sizeTotal = new EPoint(value.Width, value.Height);
				m_renderStrategy.CreateFromBitmap(value);
			}
		}

		//public int ColorKey
		//{
		//}

		public Microsoft.DirectX.DirectDraw.Surface DDSurface
		{
			get
			{
				if (m_endogine.CurrentRenderStrategy == EndogineHub.RenderStrategy.DD)
					return ((MemberSpriteBitmapRenderDDStrategy)m_renderStrategy).Surface;
			  
				return (Microsoft.DirectX.DirectDraw.Surface)null;
			}
		}

		public Texture Texture
		{
			get
			{
				if (m_endogine.CurrentRenderStrategy == EndogineHub.RenderStrategy.D3D)
					return ((MemberSpriteBitmapRender3DStrategy)m_renderStrategy).Texture;
			  
				return (Texture)null;
			}
		}
	}
}
