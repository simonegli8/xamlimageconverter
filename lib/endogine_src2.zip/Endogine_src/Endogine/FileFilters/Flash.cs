using System;

namespace EndoTest01.Endogine.FileFilters
{
	/// <summary>
	/// Summary description for Flash.
	/// </summary>
	public class Flash
	{
		public Flash()
		{
			// http://www.amanith.org/blog/index.php
		}
	}
}
