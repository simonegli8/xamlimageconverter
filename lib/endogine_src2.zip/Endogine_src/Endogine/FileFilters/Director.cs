using System;

namespace EndoTest01.Endogine.FileFilters
{
	/// <summary>
	/// Summary description for Director.
	/// </summary>
	public class Director
	{
		public Director()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
