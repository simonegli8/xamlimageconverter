using System;

namespace EndoTest01.Endogine.FileFilters
{
	/// <summary>
	/// Summary description for Photoshop.
	/// </summary>
	public class Photoshop
	{
		public Photoshop()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
