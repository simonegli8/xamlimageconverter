using System;
using System.Drawing;
using Microsoft.DirectX.DirectDraw;

namespace Endogine
{
	/// <summary>
	/// Summary description for MemberSpriteBitmapRenderDDStrategy.
	/// </summary>
	public class MemberSpriteBitmapRenderDDStrategy : MemberSpriteBitmapRenderStrategy
	{
		protected Surface m_surface;

		public MemberSpriteBitmapRenderDDStrategy()
		{
		}

		public override void Load(string a_sFilename)
		{
			Bitmap bmp =  m_mb._FriendLoadIntoBitmap(a_sFilename);
			Microsoft.DirectX.DirectDraw.SurfaceDescription description = new Microsoft.DirectX.DirectDraw.SurfaceDescription();
			m_surface = new Surface(bmp, description, ((StageDD)(m_endogine.Stage)).DDDevice);

			//m_surface = new Surface(a_sFileName, description, ((StageDD)(m_endogine.Stage)).DDDevice);
			ColorKey ck = new ColorKey();
			ck.ColorSpaceHighValue = 0;
			ck.ColorSpaceLowValue = 0;
			m_surface.SetColorKey(ColorKeyFlags.SourceDraw, ck);
		}
		
		public void CreateSurface(SurfaceDescription a_descr)
		{
			m_surface = new Surface(a_descr,  ((StageDD)(m_endogine.Stage)).DDDevice);
		}

		public override void CreateFromBitmap(Bitmap a_bmp)
		{
		}

		public Surface Surface
		{
			get {return m_surface;}
		}
	}
}
