using System;
using System.Windows.Forms;
using Microsoft.DirectX.Direct3D;

namespace Endogine
{
	/// <summary>
	/// Summary description for StageBase.
	/// </summary>
	public class StageBase
	{
		protected Sprite m_spRoot;
		protected Camera m_cam = null;

		protected EndogineHub m_endogine;
		protected Control m_renderControl;
		protected System.Drawing.Color m_clr;

		protected bool m_bFullscreen = false;


		public StageBase(Control a_renderControl, EndogineHub a_endogine)
		{
			m_clr = System.Drawing.Color.Black;
			m_renderControl = a_renderControl;
			m_endogine = a_endogine;
		}

		public virtual void Dispose()
		{}

		public virtual Device D3DDevice
		{ get {return (Device)null;}}

		public EPoint Size
		{
			get {return m_spRoot.SourceRect.Size;}
		}
		public virtual void Init()
		{
		}

		public System.Drawing.Color Color
		{
			get {return m_clr;}
			set {m_clr = value;}
		}
		public bool Fullscreen
		{
			set {m_bFullscreen = value;}
		}
		public virtual void UpdateStage()
		{
		}

		protected void CreateRootSprite(ERectangle a_rct)
		{
			m_spRoot = new Sprite();
			m_spRoot.SourceRect = a_rct;
			m_spRoot.Name = "root";

			m_cam = new Camera();
			m_cam.Name = "Camera";
			m_cam.Parent = m_spRoot;

			ParallaxLayer layer = new ParallaxLayer();
			layer.Name = "DefaultLayer";
			layer.Parent = (Sprite)m_cam;
		}

		public Sprite RootSprite
		{
			get {return m_spRoot;}
		}

		public Camera Camera
		{
			get {return m_cam;}
		}
		public Control RenderControl
		{
			get {return this.m_renderControl;}
		}
	}
}
