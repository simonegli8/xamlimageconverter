using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

using ThisMovie;

namespace Endogine
{
	/// <summary>
	/// Summary description for Stage3D.
	/// </summary>
	public class Stage3D : StageBase
	{
		public Device device = null;
		//private System.ComponentModel.Container components = null;


		public Stage3D(Control RenderControl, EndogineHub a_endogine) : base(RenderControl, a_endogine)
		{
		}

		public override Device D3DDevice
		{ get {return device;}}

		public override void Init()
		{
			try 
			{
				//m_renderControl.Width
				PresentParameters presentParams = new PresentParameters();
				AdapterInformation adapter = Manager.Adapters.Default;

				DisplayMode dm;
				if (m_bFullscreen)
				{
					dm = new DisplayMode();
					dm.Width = 640;
					dm.Height = 480;
					dm.Format = Format.X8R8G8B8;
				}
				else
					dm = adapter.CurrentDisplayMode;

				presentParams.SwapEffect = SwapEffect.Discard;
				presentParams.BackBufferFormat = Format.Unknown;
				if (m_bFullscreen)
				{
					presentParams.BackBufferFormat = dm.Format;
					presentParams.BackBufferWidth = dm.Width;
					presentParams.BackBufferHeight = dm.Height;
					presentParams.FullScreenRefreshRateInHz = 60;
					presentParams.PresentFlag = PresentFlag.LockableBackBuffer;
					presentParams.BackBufferCount = 1;
					presentParams.PresentationInterval = PresentInterval.Immediate;
				}
				presentParams.AutoDepthStencilFormat = DepthFormat.D16;
				presentParams.EnableAutoDepthStencil = true;
				presentParams.Windowed = !m_bFullscreen;

				//http://www.dotnetforums.net/t73717.html
				//http://www.dotnetforums.net/showthread.php?t=92593

				// Store the default adapter
				int adapterOrdinal = Manager.Adapters.Default.Adapter;
				CreateFlags flags = CreateFlags.SoftwareVertexProcessing;

				// Check to see if we can use a pure hardware device
				Caps caps = Manager.GetDeviceCaps(adapterOrdinal, DeviceType.Hardware);

				// Do we support hardware vertex processing?
				if (caps.DeviceCaps.SupportsHardwareTransformAndLight)
					// Replace the software vertex processing
					flags = CreateFlags.HardwareVertexProcessing;
            
				// Do we support a pure device?
				if (caps.DeviceCaps.SupportsPureDevice)
					flags |= CreateFlags.PureDevice;


				device = new Device(0, DeviceType.Hardware, m_renderControl, flags, presentParams);

				this.CreateRootSprite(new ERectangle(0,0, device.Viewport.Width, device.Viewport.Height));

				
				device.SamplerState[0].MagFilter = TextureFilter.Linear;
				device.SamplerState[0].MinFilter = TextureFilter.Linear;

				device.DeviceReset += new System.EventHandler(this.OnResetDevice);
				OnResetDevice(device, null);


				SetUpViews();
			}
			catch (DirectXException) 
			{
				// Catch any errors and return a failure
			}
		}

		public override void Dispose()
		{
			m_spRoot.Dispose();
			device.Dispose();
		}

		

		private void SetUpViews() 
		{
			//Set up views
			device.Transform.Projection = Matrix.OrthoLH((float)m_renderControl.Width, (float)m_renderControl.Height, 0.1f, 10000f);
			//.PerspectiveFovLH((float)Math.PI / 4, this.Width / this.Height , 0.1f, 100.0f ); 
			device.RenderState.CullMode = Cull.None;
			device.RenderState.Lighting = true;

			/*device.Lights[0].Type = LightType.Directional;
			device.Lights[0].Diffuse = System.Drawing.Color.DarkTurquoise;
			device.Lights[0].Direction = new Vector3((float)Math.Cos(Environment.TickCount / 250.0f), 1.0f, (float)Math.Sin(Environment.TickCount / 250.0f));
			device.Lights[0].Enabled = true;*/

			device.RenderState.Ambient = System.Drawing.Color.FromArgb(0xFFFFFF);
		}


		public void OnResetDevice(object sender, EventArgs e) 
		{
			Device device = (Device)sender;
			SetUpViews();
		}

		public void OnPaint(System.Windows.Forms.PaintEventArgs e) 
		{
			UpdateStage();
		}

		public override void UpdateStage()
		{
			device.Clear(ClearFlags.Target | ClearFlags.ZBuffer, Color, 1.0f, 0);

			m_spRoot.EnterFrame();

			device.BeginScene();

			device.Transform.World = 
				Matrix.RotationYawPitchRoll(0.0f, 0.0f, 0.0f) * 
				Matrix.Translation(0.0f, 0.0f, 1.0f);
			//Geometry.DegreeToRadian(spinX), Geometry.DegreeToRadian(spinY)
			
			m_spRoot.Draw();

			device.EndScene();
			device.Present();

			m_renderControl.Invalidate();
		}
	}
}
