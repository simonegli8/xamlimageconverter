using System;

namespace Endogine
{
	public abstract class InterpolationStrategy
	{
		abstract public double GetValueAt(double a_dTime, params double[] a_args);
	}
}
