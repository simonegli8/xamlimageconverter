using System;

using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using System.Data;
using System.Windows.Forms;

namespace Endogine
{
	/// <summary>
	/// Summary description for SpriteBase.
	/// </summary>
	public class SpriteBase
	{
		public enum Props
		{
			Loc, LocX, LocY, LocZ,
			Member, MemberName, MemberNum, MemberAnimationFrame
		}
		public enum MouseEventType
		{
			Down, StillDown, Up, UpOutside, Click, Enter, Leave
		}

		protected SpriteMouseEvents m_spMouse = null;
		protected Rectangle m_rctSrcClip;
		//protected Size m_sizeSrc;
		//protected Point m_pntSrcRegPoint;

		protected RectangleF m_rctDstParent;
		protected RectangleF m_rctDstDraw;
		protected SpriteBase m_spParent;
		//protected SpriteBase m_spDrawTarget;

		protected Hashtable m_plChildrenByHash;
		protected DataTable m_dtChildren;
		protected DataView m_dvChildrenLocZSorted;
		protected DataView m_dvChildrenLocZInverseSorted;

		protected string m_sID;
		protected int m_nInk;
		protected int m_nBlend;
		protected Color m_clr;

		protected EndogineHub m_endogine;

		protected Animator m_autoAnimator = null;

		protected bool m_bMouseDown = false;
		protected bool m_bMouseIsInside = false;

		//these are "derived" values - for user interaction and faster calculations.
		//m_rctDstParent is the result of loc, scale, srcCrop and regPoint
		protected float m_fLocZ;
		protected PointF m_pntLoc;
		protected PointF m_pntScale;
		protected float m_fRotation;

		protected MemberBitmapBase m_mb;
		protected int m_nMemberAnimFrame;

		public SpriteBase(EndogineHub a_endogine)
		{
			m_endogine = a_endogine;

			m_plChildrenByHash = new Hashtable();
			m_sID = "";
			m_nInk = 0;
			m_nBlend = 255;
			m_fLocZ = 0.0f;
			m_pntLoc = new PointF(0.0f, 0.0f);
			m_pntScale = new PointF(1.0f, 1.0f);
			m_clr = Color.White;

			m_nMemberAnimFrame = 0;

			m_dtChildren = new DataTable();
			m_dtChildren.Columns.Add("Name", typeof(System.String));
			m_dtChildren.Columns.Add("LocZ", typeof(System.Double));
			m_dtChildren.Columns.Add("Hash", typeof(System.Int32));

			m_dvChildrenLocZSorted = new DataView(m_dtChildren, "", "LocZ", DataViewRowState.CurrentRows);
			m_dvChildrenLocZInverseSorted  = new DataView(m_dtChildren, "", "LocZ DESC", DataViewRowState.CurrentRows);


			if (m_endogine.Stage != null && m_endogine.Stage.RootSprite != null)
			{
				m_endogine.Stage.RootSprite.AddChild(this);
			}
		}

		public void Dispose()
		{
			//TODO: removeChild, member reference
			string s = "K";
		}

		public EndogineHub EndogineHub
		{
			get {return m_endogine;}
		}

		#region Mouse control
		public void ConfigMouse()
		{
			if (m_spMouse == null)
				m_spMouse = new SpriteMouseEvents(this);
		}

		public bool CheckMouse(MouseEventArgs e, PointF a_pntLocalLoc, bool a_bButtonAction, bool a_bDown)
		{
			bool bContinueChecking = true;

			a_pntLocalLoc = this.ConvParentLocToSrcLoc(a_pntLocalLoc);
			foreach (DataRowView row in m_dvChildrenLocZInverseSorted)
			{
				SpriteBase sp = ((SpriteBase)m_plChildrenByHash[(int)row["Hash"]]);
				if (sp.ChildCount > 0)
					bContinueChecking = sp.CheckMouse(e, a_pntLocalLoc, a_bButtonAction, a_bDown);

				if (!bContinueChecking)
					return false;
				if (sp.MouseActive)
				{
					bool bReactedToButton = false;
					bool bReactedRoll = false;

					if (sp.Rect.Contains(a_pntLocalLoc))
					{
						if (!sp.m_bMouseIsInside)
						{
							//enter
							bReactedRoll = true;
							sp.m_bMouseIsInside = true;
							sp.OnMouse(e, MouseEventType.Enter);
						}
					
						if (a_bButtonAction)
						{
							if (a_bDown)
								sp.OnMouse(e, MouseEventType.Down);
							else
							{
								if (sp.m_bMouseDown)
									sp.OnMouse(e,  MouseEventType.Click);
								else
									sp.OnMouse(e, MouseEventType.Up);
							}
							bReactedToButton = true;
						}
						else if (sp.m_bMouseDown)
							sp.OnMouse(e,  MouseEventType.StillDown);
					}
					else
					{
						if (sp.m_bMouseIsInside)
						{
							//leave
							bReactedRoll = true;
							sp.m_bMouseIsInside = false;
							sp.OnMouse(e, MouseEventType.Leave);
						}
						if (a_bButtonAction && !a_bDown && sp.m_bMouseDown)
							sp.OnMouse(e, MouseEventType.UpOutside);
					}

					
					if (bReactedToButton) //a_bButtonAction
						sp.m_bMouseDown = a_bDown;

					//Can't stop checking completely: sprites under might need to send Leave, or UpOutside...
					//if (bReactedToButton && true) //TODO: pass?
					//	return true; 
					//if (bReactedRoll && true) //TODO: pass?
					//	return true;
				}					
			}
			return false;
		}

		protected virtual void OnMouse(MouseEventArgs e, MouseEventType t)
		{
		}


		public void GetMouseActiveOffspringZSorted(ref SortedList a_plSprites, ref int a_nOrderCount)
		{
			foreach (DataRowView row in m_dvChildrenLocZSorted)
			{
				SpriteBase sp = ((SpriteBase)m_plChildrenByHash[(int)row["Hash"]]);
	
				if (sp.MouseActive)
					a_plSprites.Add(a_nOrderCount, sp);

				a_nOrderCount++;
				if (sp.ChildCount > 0)
				{
					sp.GetMouseActiveOffspringZSorted(ref a_plSprites, ref a_nOrderCount);
				}
			}
		}

		public bool MouseActive
		{
			get
			{
				if (m_spMouse == null) return false;
				return m_spMouse.Active;
			}
			set 
			{
				if (m_spMouse == null)
				{
					if (value == true) ConfigMouse();
					else return;
				}
				else
					m_spMouse.Active = value;
			}
		}
		#endregion


		public void SetOneProp(string a_sProp, object a_oVal)
		{
			switch (a_sProp)
			{
				case "LocX":
					SetOneProp(SpriteBase.Props.LocX, a_oVal);
					break;
				case "MemberNum":
					SetOneProp(SpriteBase.Props.MemberNum, a_oVal);
					break;
				case "Member":
					SetOneProp(SpriteBase.Props.Member, a_oVal);
					break;
				case "MemberName":
					SetOneProp(SpriteBase.Props.MemberName, a_oVal);
					break;
				case "MemberAnimationFrame":
					SetOneProp(SpriteBase.Props.MemberAnimationFrame, a_oVal);
					break;
			}
		}
		public void SetOneProp(Props a_prop, object a_oVal)
		{
			switch (a_prop)
			{
				case Props.Loc:
					this.Loc = (PointF)a_oVal;
					break;
				case Props.LocX:
					Move((float)Convert.ToDouble(a_oVal)-Loc.X, 0);
					break;
				case Props.LocY:
					Move(0, (float)Convert.ToDouble(a_oVal)-Loc.Y);
					break;
				case Props.MemberNum:
					this.Member = (MemberBitmapBase)m_endogine.CastLib.GetByIndex((int)a_oVal);
					break;
				case Props.Member:
					this.Member = (MemberBitmapBase)a_oVal;
					break;
				case Props.MemberName:
					this.Member = (MemberBitmapBase)m_endogine.CastLib.GetByName((string)a_oVal);
					break;
				case Props.MemberAnimationFrame:
					this.MemberAnimationFrame = (int)a_oVal;
					break;
			}
		}

		public String Name
		{
			get {return m_sID;}
			set 
			{
				m_sID = value;
				if (m_spParent != null)
				{
					m_spParent.RemoveChild(this);
					m_spParent.AddChild(this);
				}
			}
		}
		public RectangleF Rect
		{
			get {return m_rctDstParent;}
			set
			{
				//if (m_pntSrcSize = point(0,0)) then m_pntSrcSize = point(1.0,1.0)
				m_pntScale.X = value.Width/m_rctSrcClip.Width;
				m_pntScale.Y = value.Height/m_rctSrcClip.Height;
				//TODO: when scale = 0

				m_pntLoc.X = value.Left + m_pntScale.X*m_mb.RegPoint.X;
				m_pntLoc.Y = value.Top + m_pntScale.Y*m_mb.RegPoint.Y;

				m_rctDstParent = value;
			}
		}
		public Rectangle RectInt
		{
			get {return new Rectangle((int)m_rctDstParent.Left, (int)m_rctDstParent.Top, (int)m_rctDstParent.Width, (int)m_rctDstParent.Height);}
		}
		public Rectangle SourceRect
		{
			get {return m_rctSrcClip;}
		}

		//normally avoided. Use for when sprite is only a dummy node, with no graphic representation
		public void ForceSetSourceRect(Rectangle a_rct)
		{
			m_rctSrcClip = a_rct;
			CalcInParent();
		}

		public int Ink
		{
			get {return m_nInk;}
			set {m_nInk = value;}
		}
		public int Blend
		{
			get {return m_nBlend;}
			set {m_nBlend = value;}
		}
		public virtual Color Color
		{
			get {return m_clr;}
			set {m_clr = value;}
		}

		public int MemberAnimationFrame
		{
			get {return m_nMemberAnimFrame;}
			set {m_nMemberAnimFrame = value;}
		}

		public Animator AutoAnimator
		{	get {return m_autoAnimator;} }

		public virtual MemberBitmapBase Member
		{
			get {return m_mb;}
			set
			{
				//if (m_mb != null)
				//	m_mb.RemoveSprite(this);
				if (value == null)
					throw(new Exception("No member!"));

				m_mb = value;
				m_rctSrcClip = new Rectangle(new Point(0,0), m_mb.Size);
				CalcInParent();

				if (value.GotAnimation)
				{
					m_autoAnimator = new Animator("MemberAnimationFrame", new AnimateEvent(SetOneProp));
				}

				//m_mb.AddSprite(this);
			}
		}

		#region Move/Scale/Rotate methods
		public PointF Loc
		{
			get {return m_pntLoc;}
			set {m_pntLoc = value; CalcInParent();}
		}
		public float LocX
		{
			get {return m_pntLoc.X;}
			set {m_pntLoc.X = value; CalcInParent();}
		}
		public float LocY
		{
			get {return m_pntLoc.Y;}
			set {m_pntLoc.Y = value; CalcInParent();}
		}
		public void Move(PointF a_pnt)
		{
			this.Loc = new PointF(a_pnt.X+this.Loc.X, a_pnt.Y+this.Loc.Y);
		}
		public void Move(float a_fX, float a_fY)
		{
			this.Loc = new PointF(a_fX+this.Loc.X, a_fY+this.Loc.Y);
		}
		public float LocZ
		{
			get {return m_fLocZ;}
			set {m_fLocZ = value;}
		}

		public PointF Scaling
		{
			get {return m_pntScale;}
			set {m_pntScale = value; CalcInParent();}
		}
		public void Scale(float a_fX, float a_fY)
		{
			m_pntScale.X = a_fX; m_pntScale.Y = a_fY;
			CalcInParent();
		}
		public float Rotation
		{
			get {return m_fRotation;}
			set {m_fRotation = value;}
		}
		#endregion


		#region Output rect/quad calculation methods
		public void CalcInParent()
		{
			m_rctDstParent = m_rctSrcClip;

			m_rctDstParent.X *= m_pntScale.X;
			m_rctDstParent.Y *= m_pntScale.Y;
			m_rctDstParent.Width *= m_pntScale.X;
			m_rctDstParent.Height *= m_pntScale.Y;

			//TODO: use sprite pntLoc instead of members!
			if (Member != null)
				m_rctDstParent.Offset(m_pntLoc.X - Member.RegPoint.X, m_pntLoc.Y - Member.RegPoint.Y);
			else
				m_rctDstParent.Offset(m_pntLoc);
		}

		#endregion


		#region Loc conversion methods (between source/parent/drawTarget/root)
		//ParentLoc = point relative to the output rect (Rect) - source loc after move/scale/rotate
		public PointF ConvSrcLocToParentLoc(PointF a_pntLoc)
		{
			PointF pntFract = new PointF(a_pntLoc.X/m_mb.Size.Width, a_pntLoc.Y/m_mb.Size.Height);
			pntFract.X = pntFract.X*m_rctDstParent.Width + m_rctDstParent.Left;
			pntFract.Y = pntFract.Y*m_rctDstParent.Height + m_rctDstParent.Top;
			return pntFract;
		}

		public PointF ConvParentLocToDrawLoc(PointF a_pntLoc, SpriteBase a_spDraw)
		{
			if (m_spParent == null || m_spParent == a_spDraw)
				return a_pntLoc;

			a_pntLoc = m_spParent.ConvSrcLocToParentLoc(a_pntLoc);
			return m_spParent.ConvParentLocToDrawLoc(a_pntLoc, a_spDraw);
		}

		public PointF ConvParentLocToRootLoc(PointF a_pntLoc)
		{
			if (m_spParent == null)
				return a_pntLoc;

			return m_spParent.ConvParentLocToRootLoc(m_spParent.ConvSrcLocToParentLoc(a_pntLoc));
		}

		public PointF MapPointFromRectAToRectB(PointF a_pnt, RectangleF a_rctA, RectangleF a_rctB)
		{
			PointF pntNew = new PointF(a_pnt.X-a_rctA.Left, a_pnt.Y-a_rctA.Top);
			pntNew.X/=a_rctA.Width;
			pntNew.Y/=a_rctA.Height;

			pntNew.X = pntNew.X*a_rctB.Width + a_rctB.Left;
			pntNew.Y = pntNew.Y*a_rctB.Height + a_rctB.Top;
			return pntNew;
		}

		public PointF ConvParentLocToSrcLoc(PointF a_pntLoc)
		{
			return MapPointFromRectAToRectB(a_pntLoc, Rect, this.SourceRect);
		}
		#endregion


		public virtual void EnterFrame()
		{
			if (m_autoAnimator != null)
				m_autoAnimator.EnterFrame();

			foreach (DataRowView row in m_dvChildrenLocZSorted)
				((SpriteBase)m_plChildrenByHash[(int)row["Hash"]]).EnterFrame();
		}

		#region Parent/child relation methods

		public SpriteBase Parent
		{
			get {return m_spParent;}
			set
			{
				if (m_spParent != null)
					m_spParent.RemoveChild(this);

				if (value != null)
				{
					m_spParent = value;
					m_spParent.AddChild(this);
				}
			}
		}
		public void AddChild(SpriteBase a_sp)
		{
			//Need a sorted list class that allows duplicate keys!
			DataRow row = m_dtChildren.NewRow();
			row["Name"] = a_sp.Name;
			row["LocZ"] = a_sp.LocZ;
			row["Hash"] = a_sp.GetHashCode();
			m_dtChildren.Rows.Add(row);

			m_plChildrenByHash[a_sp.GetHashCode()] = a_sp;
		}
		public void RemoveChild(SpriteBase a_sp)
		{
			//DataRow[] rows = m_dtChildren.Select("Name = '"+a_sp.Name+"'");
			DataRow[] rows = m_dtChildren.Select("Hash = '"+a_sp.GetHashCode()+"'");
			if (rows.GetLength(0) > 0)
				m_dtChildren.Rows.Remove(rows[0]);

			m_plChildrenByHash.Remove(a_sp.GetHashCode());
		}

		public int ChildCount
		{
			get {return m_plChildrenByHash.Count;}
		}
		public SpriteBase GetChildByName(string a_sName)
		{
			DataRow[] rows = m_dtChildren.Select("Name = '"+a_sName+"'");
			if (rows.GetLength(0) > 0)
			{
				int hash = (int)rows[0]["Hash"];
				return (SpriteBase)m_plChildrenByHash[hash];
			}
			return (SpriteBase)null;
		}
		public SpriteBase GetChildByIndex(int a_nIndex)
		{
			DataRowView row = m_dvChildrenLocZSorted[a_nIndex];
			return (SpriteBase)m_plChildrenByHash[(int)row["Hash"]];
		}
		public void GetChildHierarchyDebug(ref string sOutput, int nDepth)
		{
			string sIndent = "";
			nDepth++;
			for (int j = 0; j<nDepth; j++)
				sIndent+=" ";

			for (int i = 0; i < ChildCount; i++)
			{
				SpriteBase sp = GetChildByIndex(i);
				sOutput+=sIndent+sp.Name+"\r\n";
				sp.GetChildHierarchyDebug(ref sOutput, nDepth);
			}
		}
		#endregion
	}
}
