using System;
using Microsoft.DirectX.DirectDraw;
using System.Drawing;


namespace Endogine
{
	/// <summary>
	/// Summary description for MemberDDSurface.
	/// </summary>
	public class MemberDDSurface : MemberBitmapBase
	{
		private Surface m_surf;

		public MemberDDSurface(EndogineHub a_endogine, string a_sFileName) : base(a_endogine)
		{
			CreateSurface(a_sFileName);
		}

		public MemberDDSurface(EndogineHub a_endogine, SurfaceDescription a_descr) : base(a_endogine)
		{
			CreateSurface(a_descr);
		}

		public MemberDDSurface(EndogineHub a_endogine) : base(a_endogine)
		{
		}

		public void CreateSurface(string a_sFileName)
		{
			Microsoft.DirectX.DirectDraw.SurfaceDescription description = new Microsoft.DirectX.DirectDraw.SurfaceDescription();
			m_surf = new Surface(a_sFileName, description, ((Stage2D)(m_endogine.Stage)).DDDevice);
			ColorKey ck = new ColorKey();
			ck.ColorSpaceHighValue = 0;
			ck.ColorSpaceLowValue = 0;
			m_surf.SetColorKey(ColorKeyFlags.SourceDraw, ck);
		}
		public void CreateSurface(SurfaceDescription a_descr)
		{
			m_surf = new Surface(a_descr,  ((Stage2D)(m_endogine.Stage)).DDDevice);
		}
		public override void Fill()
		{
			if (m_surf == null)
			{
				Microsoft.DirectX.DirectDraw.SurfaceDescription descr = new Microsoft.DirectX.DirectDraw.SurfaceDescription();
				CreateSurface(descr);
			}
			else
				m_surf.ColorFill(0);
		}

		public Surface Surface
		{
			get {return m_surf;}
		}

		public override Size Size
		{
			get {return new Size(m_surf.SurfaceDescription.Width, m_surf.SurfaceDescription.Height);}
		}
	}
}
