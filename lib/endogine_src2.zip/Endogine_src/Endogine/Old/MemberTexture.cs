using System;
using Microsoft.DirectX.Direct3D;
using System.Drawing;

using System.Collections;

namespace Endogine
{
	/// <summary>
	/// Summary description for MemberTexture.
	/// </summary>
	public class MemberTexture : MemberBitmapBase
	{
		private Texture m_tx;
		private ImageInformation m_info;

		public MemberTexture(EndogineHub a_endogine, string a_sFilename) : base(a_endogine)
		{
			bool bStandardLoad = true;
			if (a_sFilename.IndexOf(".gif") > 0)
			{
				Image img = System.Drawing.Image.FromFile(a_sFilename);
				System.Drawing.Imaging.FrameDimension oDimension = new System.Drawing.Imaging.FrameDimension(img.FrameDimensionsList[0]);
				int nNumFrames = img.GetFrameCount(oDimension);

				//calc how big the destination bitmap must be (make it as square as possible)
				//TODO: it's OK if there's a few uninhabited tiles at end?
				m_nNumFramesOnX = (int)Math.Sqrt(nNumFrames);
				for (; m_nNumFramesOnX > 0; m_nNumFramesOnX--)
				{
					if (nNumFrames/m_nNumFramesOnX*m_nNumFramesOnX == nNumFrames)
						break;
				}
				
				Bitmap bmpDst = new Bitmap(
					img.Size.Width*m_nNumFramesOnX, img.Size.Height*nNumFrames/m_nNumFramesOnX,
					img.PixelFormat);
				Graphics g = Graphics.FromImage(bmpDst);

				if (nNumFrames > 1)
				{
					bStandardLoad = false;
					for(int i = 0; i < nNumFrames; i++)
					{
						int x = i%m_nNumFramesOnX;
						int y = i/m_nNumFramesOnX;
						img.SelectActiveFrame(oDimension, i); 
						g.DrawImageUnscaled(img, x*img.Size.Width, y*img.Size.Height, img.Size.Width, img.Size.Height);
					}
					g.Dispose();
					
					m_tx = new Texture(a_endogine.Stage.D3DDevice, bmpDst, Usage.None, Pool.Managed);
					//m_tx = new Texture(a_endogine.Stage.D3DDevice, img.Size.Width, img.Size.Height, 1, Usage.None, Format.A8R8G8B8, Pool.Managed)
					m_info = new ImageInformation();
					m_info.Width = bmpDst.Width;
					m_info.Height = bmpDst.Height;

					AnimateWithinSize = new Size(img.Size.Width, img.Size.Height);
					bmpDst.Dispose();
				}
				img.Dispose();
			}

			if (!bStandardLoad)
			{
			}
			else
			{
				m_info = TextureLoader.ImageInformationFromFile(a_sFilename);
			
				int nMipLevels = 1;
				Format format = m_info.Format;
				format = Format.A8R8G8B8;

				m_tx = TextureLoader.FromFile(a_endogine.Stage.D3DDevice, a_sFilename, m_info.Width, m_info.Height, 
					nMipLevels, Usage.None, format, Pool.Managed, Filter.Linear, Filter.Point, (unchecked((int)0xff000000)));
			}

		}

		public Texture Texture
		{ get {return m_tx;}}


		public override Size TotalSize
		{
			get { return new Size(m_info.Width, m_info.Height);}
		}
	}
}
