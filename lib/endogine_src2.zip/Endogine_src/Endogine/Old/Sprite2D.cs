using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Collections;
using Microsoft.DirectX.DirectDraw;
using System.Data;

namespace Endogine
{
	/// <summary>
	/// Summary description for Sprite.
	/// </summary>
	

	public class Sprite2D : SpriteBase
	{
		protected Image m_imgBlit;
		protected Sprite2D m_spDrawTarget;
		public LockedData m_lockedsurfacedata;

		public Sprite2D(EndogineHub a_endogine):base(a_endogine)
		{
			m_spDrawTarget = null;

			if (m_endogine.Stage != null && m_endogine.Stage.RootSprite != null)
			{
				DrawToSprite = (Sprite2D)m_endogine.Stage.RootSprite;
			}
		}

/*		public void Dispose()
		{
			//TODO: removeChild, member reference
			string s = "K";
		}
*/
		public Image Image
		{
			get {return m_imgBlit;}
			set {m_imgBlit = value;}
		}

		public Sprite2D DrawToSprite
		{
			set {m_spDrawTarget = value; if (m_spParent == null) m_spParent = value;}
		}

		public RectangleF CalcRectInDrawTarget()
		{
			PointF pnt1 = ConvParentLocToDrawLoc(m_rctDstParent.Location, m_spDrawTarget);
			PointF pnt2 = ConvParentLocToDrawLoc(new PointF(m_rctDstParent.Right, m_rctDstParent.Bottom), m_spDrawTarget);
			//TODO: why can't PointF and SizeF be added..?
			//PointF pnt2 = ConvParentLocToDrawLoc(new PointF(m_rctDstParent.Location.X + m_rctDstParent.Size.Width, m_rctDstParent.Location.Y + m_rctDstParent.Size.Height), m_spDrawTarget);
			return new RectangleF(pnt1.X, pnt1.Y, pnt2.X-pnt1.X, pnt2.Y-pnt1.Y);
		}


		public void Draw()
		{
			//if (m_surface != null)
				//m_lockedsurfacedata = m_surface.Lock(LockFlags.SurfaceMemoryPointer);

			if (Name != "root")
			{
				RectangleF rctDraw = CalcRectInDrawTarget();
				RasterOps rasterops = new RasterOps();

				rasterops.CopyPixels(((MemberDDSurface)m_spDrawTarget.m_mb), (MemberDDSurface)m_mb,
					rctDraw, m_rctSrcClip, m_spDrawTarget.m_rctSrcClip,
					m_nInk, m_nBlend, m_spDrawTarget.m_lockedsurfacedata);
			}

			foreach (DataRowView row in m_dvChildrenLocZSorted)
				((Sprite2D)m_plChildrenByHash[(int)row["Hash"]]).Draw();

			//if (m_surface != null && m_lockedsurfacedata.Width != 0)
			//	m_surface.Unlock();
		}

		public bool UsingDDSurface
		{
			get {return true;}
		}
	}
}
