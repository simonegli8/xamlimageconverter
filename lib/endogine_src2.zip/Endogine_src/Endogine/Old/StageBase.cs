using System;
using System.Windows.Forms;
using Microsoft.DirectX.Direct3D;

namespace Endogine
{
	/// <summary>
	/// Summary description for StageBase.
	/// </summary>
	public class StageBase
	{
		protected SpriteBase m_spRoot;
		protected SpriteTestStrategy m_spTestRoot;

		protected EndogineHub m_endogine;
		protected Control m_renderControl;


		public StageBase(Control a_renderControl, EndogineHub a_endogine)
		{
			m_renderControl = a_renderControl;
			m_endogine = a_endogine;
		}

		public virtual Device D3DDevice
		{ get {return (Device)null;}}

		public virtual void Init()
		{
		}

		public virtual void UpdateStage()
		{
		}

		public SpriteBase RootSprite
		{
			get {return m_spRoot;}
		}

		public SpriteTestStrategy RootTestSprite
		{
			get {return m_spTestRoot;}
		}
	}
}
