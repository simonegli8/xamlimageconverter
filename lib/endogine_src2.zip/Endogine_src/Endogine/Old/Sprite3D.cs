using System;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using System.Drawing;
using System.Data;

using System.Collections;

namespace Endogine
{
	/// <summary>
	/// Summary description for Sprite3D.
	/// </summary>
	public class Sprite3D : SpriteBase
	{
		private int numVerts = 4;
		private VertexBuffer vertexBuffer = null;
		private VertexFormats customVertexFlags = VertexFormats.Position | VertexFormats.Texture1;
		private Device device = null;

		protected Material m_mtrl;

		private struct CustomVertex 
		{
			public float X;
			public float Y;
			public float Z;
			public float Tu;
			public float Tv;
			public CustomVertex(float x, float y, float z, float tu, float tv) 
			{
				X = x;
				Y = y;
				Z = z;
				Tu = tu;
				Tv = tv;
			}
		}

		public Sprite3D(EndogineHub a_endogine):base(a_endogine)
		{
			device = a_endogine.Stage3D.device;

			m_mtrl = new Material();
			m_mtrl.Emissive = base.Color;

			vertexBuffer = new VertexBuffer(typeof(CustomVertex), 
				numVerts, device, Usage.WriteOnly, customVertexFlags, Pool.Default);
			vertexBuffer.Created += new System.EventHandler(this.OnCreateVertexBuffer);
		}

		public override Color Color
		{
			get
			{
				return base.Color;
			}
			set
			{
				base.Color = value;
				m_mtrl.Emissive = base.Color;
			}
		}

		public override MemberBitmapBase Member
		{
			get {return base.Member;}
			set 
			{
				base.Member = value;
				this.OnCreateVertexBuffer(vertexBuffer, null);
			}
		}


		public float[,] GenerateUVs()
		{
			RectangleF rctfCropped;
			if (Member.GotAnimation)
			{
				Rectangle rctAnim = Member.GetRectForFrame(m_nMemberAnimFrame);

				Size size = Member.TotalSize;
				Size sizeFrame = Member.Size;
				Size sizeReal = size;//GetUpperPowerTextureSize(size);

				rctfCropped = new RectangleF((float)rctAnim.X/sizeReal.Width, (float)rctAnim.Y/sizeReal.Height, 
					(float)rctAnim.Width/sizeReal.Width, (float)rctAnim.Height/sizeReal.Height);
			}
			else
			{
				rctfCropped = new RectangleF(0,0, 1, 1);
				rctfCropped = new RectangleF(0.1f,0.1f, 0.9f, 0.9f);
			}

			//me.setSourceSize(pntSize) --note that regPoint is not lost after this
  
			float tXOffset = 0f; //.5f/sizeReal.Width;
			float tYOffset = 0f; //.5f/sizeReal.Height;

			float[,] tUVs = new float[,]{
{rctfCropped.Left+tXOffset,			rctfCropped.Top+tYOffset},
{rctfCropped.Right-tXOffset,		rctfCropped.Top+tYOffset},
{rctfCropped.Right-tXOffset,		rctfCropped.Bottom-tYOffset},
{rctfCropped.Left+tXOffset,			rctfCropped.Bottom-tYOffset}};

			return tUVs;
		}

		public void OnCreateVertexBuffer(object sender, EventArgs e) 
		{
			vertexBuffer = new VertexBuffer(typeof(CustomVertex), 
				numVerts, device, Usage.Dynamic, customVertexFlags, Pool.Default);

			AdjustVertices();
		}

		protected void AdjustVertices()
		{
			if (Member == null)
				return;

			float[,] aUVs = GenerateUVs();

			CustomVertex[] vertices = vertexBuffer.Lock(0, 0) as CustomVertex[];
			vertices[0] = new CustomVertex(0,	0, 0.0f, aUVs[0,0], aUVs[0,1]);
			vertices[1] = new CustomVertex(1,	0, 0.0f, aUVs[1,0], aUVs[1,1]);
			vertices[2] = new CustomVertex(0,	-1, 0.0f, aUVs[3,0], aUVs[3,1]);
			vertices[3] = new CustomVertex(1,	-1, 0.0f, aUVs[2,0], aUVs[2,1]);
			vertexBuffer.Unlock();
		}
		public override void EnterFrame()
		{
			base.EnterFrame();
			AdjustVertices();
		}

		public void Draw() 
		{

			if (Name != "root")
			{
				Matrix QuadMatrix = Matrix.RotationZ(m_fRotation)
					*Matrix.Scaling(this.Rect.Width, this.Rect.Height, 1)
					*Matrix.Translation(this.Rect.X-device.Viewport.Width/2, -(this.Rect.Y-device.Viewport.Height/2), 0f);

				device.Material = m_mtrl;

				/*Microsoft.DirectX.Direct3D.Font font = new Microsoft.DirectX.Direct3D.Font(device, 20,20, FontWeight.Bold, 1, false, CharacterSet.Ansi, Precision.Default, FontQuality.AntiAliased, PitchAndFamily.FamilySwiss, "Verdana");
				Sprite MSSprite = new Sprite(device);
				MSSprite.Begin(SpriteFlags.AlphaBlend);
				font.DrawText(MSSprite, "Testing!", new Rectangle(0,0,100,100), DrawTextFormat.Left, Color.Red);
				MSSprite.End();
				MSSprite.Dispose();
				font.Dispose();*/

				device.SetTexture(0,((MemberTexture)Member).Texture);
				device.SetStreamSource(0, vertexBuffer, 0);
				device.VertexFormat = customVertexFlags;
				device.SetTransform(TransformType.View, QuadMatrix);
				device.DrawPrimitives(PrimitiveType.TriangleStrip, 0, numVerts-2);
			}

			
			foreach (DataRowView row in m_dvChildrenLocZSorted)
				((Sprite3D)m_plChildrenByHash[(int)row["Hash"]]).Draw();
		}
	}
}
