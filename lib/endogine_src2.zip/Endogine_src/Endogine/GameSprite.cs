using System;

namespace Endogine
{
	/// <summary>
	/// Summary description for GameSprite.
	/// </summary>
	public class GameSprite : Sprite
	{
		protected EPointF m_pntVel;
		protected float m_fAngle = 0;

		public GameSprite()
		{
			m_pntVel = new EPointF();
		}

		public override void EnterFrame()
		{
			base.EnterFrame();
			Loc+=m_pntVel;
		}

		public float Speed
		{
			get {return (float)Math.Sqrt(m_pntVel.X*m_pntVel.X + m_pntVel.Y*m_pntVel.Y);}
			set
			{
				m_pntVel = new EPointF((float)Math.Sin(m_fAngle), -(float)Math.Cos(m_fAngle))*value;
			}
		}
		public float MovementAngle
		{
			get {return m_fAngle;}
			set
			{
				m_fAngle = value;
				m_pntVel = new EPointF((float)Math.Sin(value), -(float)Math.Cos(value))*Speed;
			}
		}

		public EPointF Velocity
		{
			get {return m_pntVel;}
			set 
			{
				m_pntVel = value;
				m_fAngle = (float)Math.Atan2(m_pntVel.X, m_pntVel.Y);
			}
		}
	}
}
