using System;
using System.Collections;
using System.Windows.Forms;

namespace Endogine
{
	/// <summary>
	/// Summary description for KeysSteering.
	/// </summary>
	public class KeysSteering
	{
		private class KeyPair
		{
			public Keys Key1;
			public Keys Key2;
			public ArrayList PressedOrder;
			public KeyPair(Keys k1, Keys k2)
			{
				Key1 = k1; Key2 = k2;
				PressedOrder = new ArrayList();
			}
		}

		EndogineHub m_endogine;
		SortedList m_plPairs; //
		ArrayList m_aOtherPressed;
		Hashtable m_htActionsAndKeys;

		public event KeyEventHandler KeyEvent;

/// <summary>
/// 
/// </summary>
/// <param name="a_endogine"></param>
/// <param name="a_htActionAndKey">Hashtable with keys/values as e.g. "shoot":Keys.Space</param>
/// <param name="a_aPairCodes">Define opposing actions, such as "left" and "right". Only the latest pressed key will be considered as active</param>
		public KeysSteering(Hashtable a_htActionsAndKeys, ArrayList a_aPairCodes)
		{
			m_htActionsAndKeys = a_htActionsAndKeys;
			m_plPairs = new SortedList();
			m_aOtherPressed = new ArrayList();

			for (int i = 0; i < a_aPairCodes.Count; i+=2)
				AddPair((string)a_aPairCodes[i], (string)a_aPairCodes[i+1]);
		}
		public KeysSteering(Hashtable a_htActionsAndKeys)
		{
			m_htActionsAndKeys = a_htActionsAndKeys;
			m_plPairs = new SortedList();
			m_aOtherPressed = new ArrayList();
		}


		public void AddPair(string s1, string s2)
		{
			Keys k1 = GetKeyForAction(s1);
			Keys k2 = GetKeyForAction(s2);
			AddPair(k1, k2);
		}

		public void AddPair(Keys k1, Keys k2)
		{
			KeyPair kp = new KeyPair(k1, k2);
			m_plPairs.Add(k1, kp);
			m_plPairs.Add(k2, kp);
		}

		public void ReceiveEndogineKeys(EndogineHub a_endogine)
		{
			m_endogine = a_endogine;
			m_endogine.KeyEvent+=new KeyEventHandler(m_endogine_KeyEvent);
		}
		public void ReceiveFormsControlKeys(System.Windows.Forms.Control ctrl)
		{
			ctrl.KeyDown+=new System.Windows.Forms.KeyEventHandler(ctrl_KeyDown);
			ctrl.KeyUp+=new System.Windows.Forms.KeyEventHandler(ctrl_KeyUp);
		}

		private void m_endogine_KeyEvent(System.Windows.Forms.KeyEventArgs e, bool bDown)
		{
			bool bPressedBefore = false;

			int nPos = m_plPairs.IndexOfKey(e.KeyCode);
			if (nPos < 0)
			{
				//The key is not part of a key pair
				if (bDown)
				{
					if (!m_aOtherPressed.Contains(e.KeyCode))
						m_aOtherPressed.Add(e.KeyCode);
					else
						bPressedBefore = true;
				}
				else
					m_aOtherPressed.Remove(e.KeyCode);
				//return;
			}
			else
			{
				KeyPair kp = (KeyPair)m_plPairs.GetByIndex(nPos);
				if (bDown)
				{
					if (!kp.PressedOrder.Contains(e.KeyCode))
						kp.PressedOrder.Add(e.KeyCode);
					else
						bPressedBefore = true;
				}
				else 
					kp.PressedOrder.Remove(e.KeyCode);
			}

			 //don't send event if it was pressed before
			if (bDown && bPressedBefore)
				return;

			if (KeyEvent!=null)
				KeyEvent(e, bDown);
		}

		public string GetActionForKey(Keys k)
		{
			if (!m_htActionsAndKeys.ContainsValue(k))
				return "";

			IDictionaryEnumerator enumerator = m_htActionsAndKeys.GetEnumerator();
			while (enumerator.MoveNext())
			{
				if ((Keys)enumerator.Value == k)
					return (string)enumerator.Key;
			}
			return "";
		}

		public Keys GetKeyForAction(string a_sAction)
		{
			if (m_htActionsAndKeys.ContainsKey(a_sAction))
				return (Keys)m_htActionsAndKeys[a_sAction];
			return Keys.None;
		}

		public bool GetKeyActive(string a_sAction)
		{
			Keys k = GetKeyForAction(a_sAction);
			return GetKeyActive(k);
		}

		public bool GetKeyActive(Keys k)
		{
			int nPos = m_plPairs.IndexOfKey(k);
			if (nPos < 0)
			{
				return m_aOtherPressed.Contains(k);
			}
			
			KeyPair kp = (KeyPair)m_plPairs.GetByIndex(nPos);
			if (kp.PressedOrder.Count == 0)
				return false;

			return ((Keys)kp.PressedOrder[kp.PressedOrder.Count-1] == k);
		}

		public ArrayList KeysPressed
		{
			get
			{
				ArrayList keys = new ArrayList();

				foreach (Keys key in m_aOtherPressed)
					keys.Add(key);

				for (int i = 0; i < m_plPairs.Count; i++)
				{
					KeyPair kp = (KeyPair)m_plPairs.GetByIndex(i);
					foreach (Keys key2 in kp.PressedOrder)
						keys.Add(key2);
				}
				return keys;
			}
		}

		private void ctrl_KeyDown(object sender, KeyEventArgs e)
		{
			m_endogine_KeyEvent(e, true);
		}

		private void ctrl_KeyUp(object sender, KeyEventArgs e)
		{
			m_endogine_KeyEvent(e, false);
		}
	}
}
