using System;
using System.Drawing;
using System.Collections;
using System.Xml;

using Endogine;

namespace Endogine.Text
{
	/// <summary>
	/// Summary description for BitmapFont.
	/// </summary>
	public class BitmapFont
	{
		private SortedList m_slCharReplacements; //which chars to use when a char is missing (�->A, �->e etc)
		private SortedList m_slKerningReplacements;
		private string m_sName;
		private float m_fTop;
		private float m_fBottom;
		private MemberSpriteBitmap m_mb;
		private SortedList m_slCharInfo;

		public BitmapFont()
		{
		}

		/// <summary>
		/// The big bitmap containing all characters
		/// </summary>
		public MemberSpriteBitmap Member
		{
			get {return m_mb;}
		}

		/// <summary>
		/// Get info about the specified character. If the character doesn't exist in the loaded file, substitute info is provided instead.
		/// </summary>
		/// <param name="s">A one-character string</param>
		/// <returns>CharInfo instance</returns>
		public CharInfo GetCharInfo(string s)
		{
			int nCode = Convert.ToInt32(s[0]);
			CharInfo charInfo = (CharInfo)m_slCharInfo[nCode];
			if (charInfo == null)
			{
				if (m_slCharReplacements.ContainsKey(nCode))
				{
					nCode = (int)m_slCharReplacements[nCode];
					charInfo = (CharInfo)m_slCharInfo[nCode];
				}
			}

			//last resort: use A for charInfo
			if (charInfo == null)
				charInfo = (CharInfo)m_slCharInfo[65];

			return charInfo;
		}

		public float GetKerningBetween(string s1, string s2)
		{
			CharInfo info1 = GetCharInfo(s1);
			float fKern = info1.GetKern(Convert.ToInt32(s2[0]));
			if (fKern < 0)
			{
				if (m_slKerningReplacements.ContainsKey(Convert.ToInt32(s2[0])))
				{
					int nCode = (int)m_slKerningReplacements[Convert.ToInt32(s2[0])];
					fKern = info1.GetKern(nCode);
				}
			}
			return fKern;
		}

		/// <summary>
		/// Get which frame in the big font bitmap that contains the requested character
		/// </summary>
		/// <param name="s"></param>
		/// <returns>0-based frame number</returns>
		public int GetFrame(string s)
		{
			CharInfo charInfo = GetCharInfo(s);
			if (charInfo!=null)
				return charInfo.FrameNum;
			return 0;
		}
		public Point GetRegPoint(string s)
		{
			CharInfo charInfo = GetCharInfo(s);
			if (charInfo!=null)
				return charInfo.RegPoint;
			return new Point(0,0);
		}
/// <summary>
/// Reads font info files created with my Lingo font generator. The generator will be ported to C# later.
/// </summary>
/// <param name="a_sFolder"></param>
		public void Load(string a_sFolder)
		{
			//http://www.geocities.com/foetsch/bmpfonts/bmpfonts.htm
			XmlTextReader r = new XmlTextReader(a_sFolder + "\\FontInfo.xml");

			XmlDocument doc = new XmlDocument();
			doc.Load(r);
			XmlNode node = doc.SelectSingleNode("root");

			m_slCharInfo = new SortedList();

			m_sName = node.SelectSingleNode("Name").InnerText;

//			m_sName = node.SelectSingleNode("DefaultExtraSpace").InnerText;
//			m_sName = node.SelectSingleNode("DefaultWidth").InnerText;
			//if no set default width, use character A's width

			node = node.SelectSingleNode("Stats");
			m_fTop = Convert.ToSingle(node.SelectSingleNode("Top").InnerText);
			m_fBottom = Convert.ToSingle(node.SelectSingleNode("Bottom").InnerText);
			node = node.ParentNode;

			node = node.SelectSingleNode("CharReplacements");
			m_slCharReplacements = new SortedList();
			foreach (XmlNode subnode in node.ChildNodes)
				InsertNodeIntoSortedList(ref m_slCharReplacements, subnode);
			node = node.ParentNode;


			node = node.SelectSingleNode("RegPoints");
			SortedList slRegPoints = new SortedList();
			foreach (XmlNode subnode in node.ChildNodes)
				InsertNodeIntoSortedList(ref slRegPoints, subnode);
			node = node.ParentNode;

			for (int i = 0; i < slRegPoints.Count; i++)
			{
				Point pnt = (Point)slRegPoints.GetByIndex(i);
				int nCode = (int)slRegPoints.GetKey(i);
				CharInfo charInfo = new CharInfo(nCode);
				charInfo.RegPoint = pnt;
				m_slCharInfo.Add(nCode, charInfo);
			}


			node = node.SelectSingleNode("Rects");
			SortedList slRects = new SortedList();
			foreach (XmlNode subnode in node.ChildNodes)
				InsertNodeIntoSortedList(ref slRects, subnode);
			node = node.ParentNode;

			for (int i = 0; i < slRects.Count; i++)
			{
				int nCode = (int)slRects.GetKey(i);
				string sRct = (string)slRects.GetByIndex(i);
				string[] sVals = sRct.Split(",".ToCharArray());
				ArrayList aVals = new ArrayList();
				foreach (string sVal in sVals)
					aVals.Add(Convert.ToInt32(sVal));

				Rectangle rct = new Rectangle((int)aVals[0],(int)aVals[1], (int)aVals[2]-(int)aVals[0], (int)aVals[3]-(int)aVals[1]);
				CharInfo charInfo = (CharInfo)m_slCharInfo[nCode];
				charInfo.Rect = rct;
			}


			string sOrder = node.SelectSingleNode("BmpOrder").InnerText;
			string[] sCharCodes = sOrder.Split(",".ToCharArray());
			ArrayList aOrder = new ArrayList();
			for (int i = 0; i < sCharCodes.GetLength(0); i++)
			{
				int nCode = Convert.ToInt32(sCharCodes[i]);
				CharInfo charInfo = (CharInfo)m_slCharInfo[nCode];
				charInfo.FrameNum = i;
			}

			node = node.SelectSingleNode("RectsIfNotAsBitmap");
			node = node.ParentNode;

			
			//  if (voidP(m_paWidths.getaProp(32))) then m_paWidths.setaProp(32, integer(0.3*m_nStdWidth))
			CharInfo ciSpace = new CharInfo(32);
			m_slCharInfo[32] = ciSpace;
			ciSpace.Rect = new Rectangle(0,0,10,15);
			ciSpace.FrameNum = -1;


			node = node.SelectSingleNode("KerningReplacements");
			m_slKerningReplacements = new SortedList();
			foreach (XmlNode subnode in node.ChildNodes)
				InsertNodeIntoSortedList(ref m_slKerningReplacements, subnode);
			node = node.ParentNode;

			node = node.SelectSingleNode("Kerning");
			SortedList slKerning = new SortedList();
			foreach (XmlNode subnode in node.ChildNodes)
				InsertNodeIntoSortedList(ref slKerning, subnode);
			node = node.ParentNode;

			for (int i = 0; i < slKerning.Count; i++)
			{
				SortedList sl = (SortedList)slKerning.GetByIndex(i);
				int nCode = (int)slKerning.GetKey(i);
				CharInfo charInfo = (CharInfo)m_slCharInfo[nCode];
				charInfo.SetKerningList(sl);
			}



			Point pntTile = (Point)ConvertToValue(node.SelectSingleNode("TileSize").InnerText);
			m_mb = new MemberSpriteBitmap(a_sFolder + "\\Font.png");
			m_mb.AnimateWithinSize = new EPoint(pntTile.X, pntTile.Y);
			m_mb.AutoAnimate = false;

			//m_nLineHeight = integer(m_nStdWidth*1.5)
 		}

		private void InsertNodeIntoSortedList(ref SortedList list, XmlNode node)
		{
			string s = node.Name;
			object o;

			bool bChildNodes = false;
			if (node.HasChildNodes)
			{
				if (node.ChildNodes.Count > 1)
					bChildNodes = true;
			}
			if (bChildNodes)
			{
				SortedList sublist = new SortedList();
				o = sublist;
				foreach (XmlNode subnode in node.ChildNodes)
				{
					InsertNodeIntoSortedList(ref sublist, subnode);
				}
			}
			else
			{
				o = ConvertToValue(node.InnerText);
			}

			if (s.IndexOf("_INT") == 0)
			{
				s = s.Replace("_INT", "");
				int i = Convert.ToInt32(s);
				if (!list.ContainsKey(i))
					list.Add(i, o);
			}
			else
				list.Add(s, o);
		}

		private object ConvertToValue(string sValue)
		{
			object o;
			try {o = (int)Convert.ToInt32(sValue);}
			catch
			{
				if (sValue.IndexOf("point") >= 0)
				{
					sValue = sValue.Replace("point(", "");
					sValue = sValue.Replace(")", "");
					string[] aCoords = sValue.Split(",".ToCharArray());
					System.Drawing.Point pnt = new System.Drawing.Point(Convert.ToInt32(aCoords[0]), Convert.ToInt32(aCoords[1]));
					o = pnt;
				}
				else
					o = (string)sValue;
			}
			return o;
		}
	}
}
