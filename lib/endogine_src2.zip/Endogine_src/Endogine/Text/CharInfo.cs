using System;
using System.Drawing;
using System.Collections;

namespace Endogine.Text
{
	/// <summary>
	/// Summary description for CharInfo.
	/// </summary>
	public class CharInfo
	{
		private int m_nCharCode;
		private SortedList m_slKerning;
		private float m_fHeight;
		private Point m_pntRegPoint;
		private int m_frameInBitmap;
		private Rectangle m_rct;
 
		public CharInfo(int m_nCharCode)
		{
			m_slKerning = new SortedList();
		}

		public float Width
		{
			get {return m_rct.Width;}
		}

		public Rectangle Rect
		{
			get {return m_rct;}
			set {m_rct = value;}
		}

		public Point RegPoint
		{
			get {return m_pntRegPoint;}
			set {m_pntRegPoint = value;}
		}

		public int FrameNum
		{
			get {return m_frameInBitmap;}
			set {m_frameInBitmap = value;}
		}

		

		public int CharCode
		{ get {return m_nCharCode;}}

		public float GetKern(int nCharCode)
		{
			if (m_slKerning.ContainsKey(nCharCode) == false)
				return -1;
			return (float)(int)m_slKerning[nCharCode];
		}

		public void SetKerningList(SortedList a_slKerning)
		{
			m_slKerning = a_slKerning;
		}
	}
}
