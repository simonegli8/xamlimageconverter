using System;
using System.Drawing;
using Endogine;

namespace Endogine.Forms
{
	/// <summary>
	/// Summary description for Form.
	/// </summary>
	public class Form : Sprite
	{
		protected Frame m_frame;
		protected Dragbar m_dragbar;
		protected Sprite m_resizeCorner;
		public Form()
		{
			this.m_bNoScalingOnSetRect = true;
			Name = "Form";

			m_frame = new Frame();
			m_frame.Parent = this;
			m_frame.Ink = RasterOps.ROPs.D3DTest2;
			MemberSpriteBitmap mb = (MemberSpriteBitmap)m_endogine.CastLib.GetOrCreate("Button2Up");
			//mb.ColorKey =
			m_frame.Member = mb;
			m_frame.LocZ = 0;

			m_dragbar = new Dragbar();
			m_dragbar.Parent = this;

			m_resizeCorner = new Sprite();
			m_resizeCorner.Parent = this;
			m_resizeCorner.Name = "ResizeCorner";
			m_resizeCorner.MemberName = "Button2Up";
			m_resizeCorner.Member = mb;
			m_resizeCorner.Ink = RasterOps.ROPs.BgTransparent;
			m_resizeCorner.SourceRect = new ERectangle(0,0,15,15);
			m_resizeCorner.MouseActive = true;
			m_resizeCorner.MouseEvent+=new MouseEventDelegate(m_resizeCorner_MouseEvent);
		}

		public override ERectangleF Rect
		{
			get{	return base.Rect;}
			set
			{
				base.Rect = value;
				m_frame.Rect = new ERectangleF(0,0,Rect.Width,Rect.Height);
				m_dragbar.Rect = new ERectangleF(0,0,Rect.Width,40);
				m_resizeCorner.Loc = new EPointF(Rect.Width-20,Rect.Height-20);
			}
		}

		public void Close()
		{
			Dispose();
		}

		private void m_resizeCorner_MouseEvent(System.Windows.Forms.MouseEventArgs e, MouseEventType t)
		{
			if (t==Sprite.MouseEventType.StillDown)
			{
				EPoint pntDiff = new EPoint(e.X-m_resizeCorner.MouseLast.X, e.Y-m_resizeCorner.MouseLast.Y);
				Rect = new ERectangleF(Rect.Location, Rect.Size+pntDiff.ToEPointF());//SizeF(Rect.Size.Width+pntDiff.X,Rect.Size.Height+pntDiff.Y));
			}
		}
	}
}
