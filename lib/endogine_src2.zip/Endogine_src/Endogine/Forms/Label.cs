using System;
using System.Drawing;
using System.Collections;
using Endogine.Text;

namespace Endogine.Forms
{
	/// <summary>
	/// This class will allow more advanced text rendering, with line wraps, and provide functionality for user text editing
	/// Currently it only supports one single font.
	/// </summary>
	public class Label : Sprite
	{
		protected float m_fKerning = 1.0f;
		protected float m_fSpacing = 1.0f;
		protected float m_fDefaultCharWidth;
		protected BitmapFont m_font = null;
		protected string m_sText;
		protected ArrayList m_aCharSprites = null;

		public Label()
		{
			Name = "Label";
		}

		public BitmapFont Font
		{
			set {m_font = value;}
		}

		public float Kerning
		{
			get {return m_fKerning;}
			set  {m_fKerning = value;}
		}

		public string Text
		{
			get {return m_sText;}
			set  {m_sText = value; CreateTextSprites(m_sText);}
		}

		public ArrayList Sprites
		{
			get { return m_aCharSprites; }
		}

		public void CreateTextSprites(string s)
		{
			if (m_aCharSprites != null)
			{
				foreach (Sprite sp in m_aCharSprites)
					sp.Dispose();
			}

			m_aCharSprites = new ArrayList();
			float x = 0;
			char nLastChar = (char)0;
			m_fKerning = 1;
			foreach (char nChar in s)
			{
				CharInfo charInfo = m_font.GetCharInfo(nChar.ToString());
				if (charInfo==null)
					continue;

				if (charInfo.FrameNum < 0)
				{
					x+=charInfo.Rect.Right;
					continue;
				}
				Sprite sp = new Sprite();
				sp.Parent = this;
				sp.Name = nChar.ToString();
				sp.Member = m_font.Member;
				sp.MemberAnimationFrame = charInfo.FrameNum;
				sp.RegPoint = new EPoint(0,charInfo.RegPoint.Y);
				sp.Ink = 0;
				if (nLastChar != 0)
					x-=m_fKerning*(float)m_font.GetKerningBetween(nLastChar.ToString(), nChar.ToString());
				sp.Loc = new EPointF(x,10);
				x=sp.LocX+charInfo.Rect.Right;
				m_aCharSprites.Add(sp);

				nLastChar = nChar;
			}
		}
	}
}
