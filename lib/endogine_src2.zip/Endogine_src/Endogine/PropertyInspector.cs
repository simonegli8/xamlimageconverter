using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Endogine
{
	/// <summary>
	/// TODO: use PropertyGrid and PropertyInfo
	/// http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dndotnet/html/usingpropgrid.asp
	/// http://www.thecodeproject.com/csharp/configeditor.asp
	/// http://www.codeproject.com/csharp/Fast_Dynamic_Properties.asp
	/// http://www.codeproject.com/cs/miscctrl/CustomPropGrid.asp
	/// http://www.codeproject.com/csharp/SimpleSerializer.asp
	/// http://www.codeproject.com/csharp/DzCollectionEditor.asp
	/// Summary description for PropertyInspector.
	/// </summary>
	public class PropertyInspector : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private Sprite m_sp = null;

		public PropertyInspector()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Location = new System.Drawing.Point(0, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(288, 264);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "groupBox1";
			// 
			// PropertyInspector
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(288, 277);
			this.Controls.Add(this.groupBox1);
			this.Name = "PropertyInspector";
			this.Text = "PropertyInspector";
			this.ResumeLayout(false);

		}
		#endregion

		public void ShowProperties(Sprite a_sp)
		{
			for (int i = groupBox1.Controls.Count-1; i >= 0; i--)
			{
				Control ctrl = (Control)groupBox1.Controls[i];
				groupBox1.Controls.RemoveAt(i);
				ctrl.Dispose();
			}

			m_sp = a_sp;
			//Type type = m_sp.GetType();
			//System.Reflection.PropertyInfo[] aPi = type.GetProperties();
			//aPi[0].Attributes

			Hashtable pdl = a_sp.GetPropertyDescriptionList();
			IDictionaryEnumerator enumerator = pdl.GetEnumerator();
			int y = 0;
			//TODO: why doesn't this work?? foreach (Endogine.PropertyDescription pd in pdl)
			for (int i = 0; i < pdl.Count; i++)
			{
				enumerator.MoveNext();
				PropertyDescription pd = (PropertyDescription)enumerator.Value;
				Label lbl = new Label();
				groupBox1.Controls.Add(lbl);
				lbl.Text = pd.Name;
				lbl.Top = y;

				Control ctrl;
				int width = 50;
				//TODO: all this is a quick hack; will rewrite after deciding proper format for PropertyDescription (should be same format as MS uses)
				//Also, the same type of property inspector that VS uses should be available as an option.
				if (pd.UseNumericUpDown)
				{
					NumericUpDown updown = new NumericUpDown();
					//				if (pd.Type == typeof(float))

					//ctrl.DecimalPlaces = 
					if (pd.EnforceLimits)
					{
						updown.Minimum = (decimal)pd.Min;
						updown.Maximum = (decimal)pd.Max;
					}
					else
					{
						updown.Minimum = (decimal)-1000000;
						updown.Maximum = (decimal)1000000;
					}
					if (pd.Type == typeof(float))
						updown.Value = (decimal)((float)a_sp.GetOneProp(pd.Name));
					else
						updown.Value = (decimal)((int)a_sp.GetOneProp(pd.Name));
					ctrl = updown;
				}
				else if (pd.UseCheckBox)
				{
					CheckBox cb = new CheckBox();
					cb.Checked = (bool)a_sp.GetOneProp(pd.Name);
					cb.CheckedChanged+=new EventHandler(cb_CheckedChanged);
					ctrl = cb;
				}
				else if (pd.UseDropDownList)
				{
					ComboBox combo = new ComboBox();
					string[] aNames = Enum.GetNames(typeof(RasterOps.ROPs));
					foreach (string s in aNames)
						combo.Items.Add(s);
					ctrl = combo;
					width = 100;
				}
				else
				{
					TextBox tb = new TextBox();
					tb.Text = GetPropValAsString(pd.Name);
					ctrl = tb;
				}

				groupBox1.Controls.Add(ctrl);
				ctrl.Top = y;
				ctrl.Left = 100;
				ctrl.Width = width;
				ctrl.Name = (string)enumerator.Key;
				ctrl.TextChanged+=new EventHandler(ctrl_TextChanged);
				ctrl.LostFocus+=new EventHandler(ctrl_LostFocus);
				ctrl.KeyDown+=new System.Windows.Forms.KeyEventHandler(ctrl_KeyDown);

				y+=25;
			}
			System.Windows.Forms.Button btn = new System.Windows.Forms.Button();
			int nNumBh = m_sp.GetNumBehaviors();
			btn.Text = "Behaviors ("+nNumBh+") ...";
			btn.Top = y;
			btn.Click+=new EventHandler(btn_Click);
			btn.Width = 100;
			groupBox1.Controls.Add(btn);
		}

		private string GetPropValAsString(string a_sName)
		{
			Hashtable pdl = m_sp.GetPropertyDescriptionList();
			PropertyDescription pd = (PropertyDescription)pdl[a_sName];

			if (pd.Type == typeof(float))
				return ((float)m_sp.GetOneProp(a_sName)).ToString();
			else if (pd.Type == typeof(int))
				return ((int)m_sp.GetOneProp(a_sName)).ToString();
			else
				return m_sp.GetOneProp(a_sName).ToString();
		}

		private void TrySetValue(Control ctrl, bool bCorrect)
		{
			Hashtable pdl = m_sp.GetPropertyDescriptionList();
			PropertyDescription pd = (PropertyDescription)pdl[ctrl.Name];

			string s = ctrl.Text;
			try
			{
				if (pd.Type == typeof(float))
					m_sp.SetOneProp(ctrl.Name, Convert.ToSingle(s));
				else if (pd.Type == typeof(int))
					m_sp.SetOneProp(ctrl.Name, Convert.ToInt32(s));
				else if (pd.Type == typeof(bool))
					m_sp.SetOneProp(ctrl.Name, ((CheckBox)ctrl).Checked);
				else
					m_sp.SetOneProp(ctrl.Name, s);
			}
			catch
			{
				if (bCorrect)
				{
					ctrl.Text = GetPropValAsString(ctrl.Name);
				}
			}
		}

		private void ctrl_TextChanged(object sender, EventArgs e)
		{
			TrySetValue((Control)sender, false);
		}

		private void ctrl_LostFocus(object sender, EventArgs e)
		{
			TrySetValue((Control)sender, true);
		}

		private void ctrl_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Return)
				 this.Focus();
		}

		private void cb_CheckedChanged(object sender, EventArgs e)
		{
			TrySetValue((Control)sender, false);
		}

		private void btn_Click(object sender, EventArgs e)
		{
			BehaviorInspector bhi = new BehaviorInspector();
			bhi.SetSprite(m_sp);
			bhi.MdiParent = this.MdiParent;
			bhi.Show();
		}
	}
}
