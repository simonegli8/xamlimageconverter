using System;
using System.Collections;

namespace Endogine
{
	/// <summary>
	/// Animates a sprite property
	/// </summary>
	public delegate void AnimateEvent(string s, object o);

	public class Animator
	{
		private string m_sProp = null;
		private AnimateEvent m_delegate;
		private double m_dPos;
		private double m_dStep;
		private SortedList m_plKeys;

		private EndogineHub m_endogine;

		public Animator(EndogineHub a_endogine, string a_sProp, AnimateEvent a_delegate)
		{
			m_endogine = a_endogine;

			m_sProp = a_sProp;
			m_delegate = a_delegate;

			m_dPos = 0.0;
			m_dStep = 1.0;

			m_endogine.EnterFrameEvent+=new Endogine.EnterFrame(m_endogine_EnterFrameEvent);
		}

		public void Dispose()
		{
			m_endogine.EnterFrameEvent-=new Endogine.EnterFrame(m_endogine_EnterFrameEvent);
		}

		public double StepSize
		{
			get {return m_dStep;}
			set
			{
				m_dStep = value;
			}
		}

		public void EnterFrame()
		{
			m_dPos+=m_dStep;
			if (m_sProp != null)
				m_delegate(m_sProp, m_dPos); //(((int)m_dPos%30)+1).ToString());
		}

		private void m_endogine_EnterFrameEvent()
		{
			EnterFrame();
		}
	}
}
