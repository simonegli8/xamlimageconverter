using System;
using Endogine;

namespace SideScroller
{
	/// <summary>
	/// Summary description for Asteroid.
	/// </summary>
	public class Asteroid : WrappingSprite
	{
		protected int m_nSize;
		protected GameMain m_gameMain;

		public Asteroid(GameMain a_gameMain, int a_nSize)
		{
			this.WrapRect = new ERectangleF(new EPointF(0,0), EndogineHub.Get().Stage.Size.ToEPointF()) + new ERectangleF(-80,-80,160,160);

			m_gameMain = a_gameMain;
			m_gameMain.Asteroids.Add(this);
			m_nSize = a_nSize;
			string sMemberFile = "Asteroid01"; //"Asteroid0"+m_nSize.ToString();
			MemberSpriteBitmap mb = (MemberSpriteBitmap)m_endogine.CastLib.GetOrCreate(sMemberFile);
			mb.AnimateWithinSize = mb.TotalSize/new EPoint(7,6); //this is done one time for each sprite - unnecessary and stupid!
			mb.NumAnimationFrames = 40; //mb.NumAnimationFrames-2;
			this.Member = mb;
			this.AutoAnimator.StepSize = 0.8f-0.2f*m_nSize;
			this.Scaling = new EPointF(2,2)*(1f/(float)(4-m_nSize));
		}

		public override void Dispose()
		{
			base.Dispose ();
			m_gameMain.Asteroids.Remove(this);
		}

		public void Hit()
		{
			if (m_nSize > 1)
			{
				//create two smaller asteroids
				Asteroid part;
				part = new Asteroid(m_gameMain, m_nSize-1);
				part.MovementAngle = MovementAngle+(float)Math.PI/2;
				part.Speed = Speed*1.5f;
				part.Loc = this.Loc + part.Velocity*30*(m_nSize-1);

				part = new Asteroid(m_gameMain, m_nSize-1);
				part.MovementAngle = MovementAngle-(float)Math.PI/2;
				part.Speed = Speed*1.5f;
				part.Loc = this.Loc + part.Velocity*30*(m_nSize-1);
			}
			this.Dispose();
		}
	}
}
