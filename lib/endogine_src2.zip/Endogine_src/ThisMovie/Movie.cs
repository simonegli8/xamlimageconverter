using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;

using Endogine;
using PuzzleBobble;

namespace ThisMovie
{
	/// <summary>
	/// Summary description for Movie.
	/// </summary>
	public class Movie
	{
		private static EndogineHub m_endogine = null;

		public Movie(EndogineHub a_endogine)
		{
			m_endogine = a_endogine;

			//I've moved all functionality out to Main.cs instead!


			//TODO: how to configure XML documentation so that TODO's are documented?
			//I want to be able to set a priority, so I can get a generated TODO-list.
			//This must exist, I guess I just have to find it.
			///<todo p=1>Get TODO's to work!!</todo>
		}


		public void Dispose()
		{
		}
	}
}
