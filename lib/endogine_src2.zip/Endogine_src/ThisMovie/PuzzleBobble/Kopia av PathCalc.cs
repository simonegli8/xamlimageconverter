using System;
using System.Drawing;
using System.Collections;
using Endogine;

namespace ThisMovie
{
	/// <summary>
	/// Summary description for PathCalc.
	/// </summary>
	public class PathCalc
	{
		private PlayArea m_playArea;
		private ArrayList aSprites;

		public PathCalc(PlayArea a_playArea)
		{
			m_playArea = a_playArea;
			aSprites = new ArrayList();
			for (int i = 0; i < 10; i++)
			{
				Sprite sp = new Sprite(m_playArea.EndogineHub);
				sp.Parent = m_playArea;
				sp.MemberName = "BallRed";
				sp.Member.CenterRegPoint();
				sp.RegPoint = sp.Member.RegPoint;
				aSprites.Add(sp);
			}
		}

		public void DrawPath(ArrayList aLocs)
		{
			int n = Math.Min(10,aLocs.Count);

			for (int i = 0; i < n; i++)
			{
				PointF pnt = (PointF)aLocs[i];
				pnt = m_playArea.Grid.GetGfxLocFromGridLoc(pnt);
				Sprite sp = (Sprite)aSprites[i];
				sp.Loc = pnt;
			}
		}

		public ArrayList CalcPath(double a_dAngle)
		{
			System.Collections.ArrayList aLocs = new System.Collections.ArrayList();

			float fSpeed = 1;
			PointF pntVel = new PointF(fSpeed*(float)Math.Sin(a_dAngle), -fSpeed*(float)Math.Cos(a_dAngle));


			pntVel.X = pntVel.X*2;
			pntVel.Y = pntVel.Y*2/m_playArea.Grid.HeightProportion;

			PointF pntOrgStart = m_playArea.Grid.GetGridStartLoc();
			float fNumTimesToMultiply = (float)(pntOrgStart.Y-m_playArea.Grid.CeilingNumStepsDown)/-pntVel.Y;
			float fReachCeilingAtX = pntVel.X*fNumTimesToMultiply;
			float fNumWallBounces = Math.Abs(fReachCeilingAtX)/m_playArea.Grid.GridSize.Width + 0.5f;
			int nNumWallBounces = (int)fNumWallBounces;

			int nDirection = Math.Sign(pntVel.X);

			aLocs.Add(pntOrgStart);
			float fYperX = 0;
			if (nDirection != 0)
				fYperX = -Math.Abs(pntVel.Y/pntVel.X);

			PointF pntStartThisLoop = pntOrgStart;
			for (int nWallBounceNum = 0; nWallBounceNum < nNumWallBounces; nWallBounceNum++)
			{
				float fWallY = fYperX*((float)nWallBounceNum+1-0.5f)*m_playArea.Grid.GridSize.Width;
				int nLeftOrRightWall = nDirection*(2*((nWallBounceNum+1)%2)-1);
				PointF pntWallLoc = new PointF(
					0.5f*nLeftOrRightWall*m_playArea.Grid.GridSize.Width + pntOrgStart.X, fWallY+pntOrgStart.Y);

				PointF pntHitOtherBallLoc;
				if (CalcTouchedBall(pntStartThisLoop, pntWallLoc, a_dAngle, out pntHitOtherBallLoc))
				{
					aLocs.Add(pntHitOtherBallLoc);
					return aLocs;
				}
				aLocs.Add(pntWallLoc);
				pntStartThisLoop = pntWallLoc;
			}

			//it didn't hit other balls, so calc where on ceiling it will stick, or if it hits a ball on the final distance:
			if (nNumWallBounces > 0)
			{
				fReachCeilingAtX = (fNumWallBounces - nNumWallBounces)*m_playArea.Grid.GridSize.Width;
				if (nNumWallBounces % 2 == 1 && nDirection == 1 ||
					nNumWallBounces % 2 == 0 && nDirection == -1)
					fReachCeilingAtX = m_playArea.Grid.GridSize.Width - fReachCeilingAtX;

				fReachCeilingAtX = fReachCeilingAtX - (float)m_playArea.Grid.GridSize.Width/2;
			}

			PointF pntStickOnCeiling = new PointF(fReachCeilingAtX + pntOrgStart.X,
				(float)m_playArea.Grid.CeilingNumStepsDown/2*m_playArea.Grid.HeightProportion);
			
			PointF pntHitLoc;
			if (CalcTouchedBall(pntStartThisLoop, pntStickOnCeiling, a_dAngle, out pntHitLoc))
				aLocs.Add(pntHitLoc);
			else
				aLocs.Add(pntStickOnCeiling);
			return aLocs;
		}

		private bool CalcTouchedBall(PointF a_pntStart, PointF a_pntEnd, double a_dAngle, out PointF a_pntTouch)
		{
			a_pntTouch = new PointF(0,0);

			//follow two lines, parallel with path, to see which squares are touched by ball
			a_dAngle+=Math.PI/2;
			PointF pntOffset = new PointF((float)Math.Sin(a_dAngle), -(float)Math.Cos(a_dAngle) / m_playArea.Grid.HeightProportion);

			PointF pntDiff = new PointF(a_pntEnd.X-a_pntStart.X, a_pntEnd.Y-a_pntStart.Y);
			Point pntSigns = new Point(Math.Sign(pntDiff.X), Math.Sign(pntDiff.Y));

			System.Collections.ArrayList aLocs = new System.Collections.ArrayList();
			for (int i = -1; i <= 1; i++)
			{
				//which line to follow:
				PointF pntStart = new PointF(a_pntStart.X + pntOffset.X*i, a_pntStart.Y + pntOffset.Y*i);

				//many squares will be checked more than once by this algorithm, but better safe than sorry.
				//Surplus squares are removed by PointExistsInArray
				if (pntDiff.X != 0)
				{
					//moves on X axis, check all grid squares passed
					float fNearestX = (int)a_pntStart.X + (1f-a_pntStart.X);
					for (int n = 0; n <= (int)Math.Abs(pntDiff.X)+1; n++)//each time a square is passed
					{
						PointF pntTmp = new PointF(
							pntStart.X + fNearestX + n*pntSigns.X,
							pntStart.Y + pntDiff.Y*(fNearestX + n*pntSigns.X)/pntDiff.X);
						pntTmp.X = pntTmp.X + pntSigns.X* (((int)pntTmp.Y%2 != (int)pntTmp.X % 2)?1:0);

						Point pnt = new Point((int)pntTmp.X, (int)pntTmp.Y);
						if (!PointExistsInArray(aLocs,pnt))
							aLocs.Add(pnt);
					}
				}

				if (pntDiff.Y != 0)
				{
					//moves on Y axis, check all grid squares passed
					float fNearestY = (int)a_pntStart.Y + (1f-a_pntStart.Y);
					for (int n = 0; n <= (int)Math.Abs(pntDiff.Y)+1; n++)//each time a square is passed
					{
						// tmpLocH = tmpStartLoc[1] + tmpDiff[1]*(tmpNearestV + n*tmpSigns[2])/tmpDiff[2]
						// tmpLocH = tmpLocH + tmpSigns[2]*(realInteger(tmpLocV) mod 2 <> realInteger(tmpLocH) mod 2)
						PointF pntTmp = new PointF(
							pntStart.X + pntDiff.X*(fNearestY + n*pntSigns.Y)/pntDiff.Y,
							pntStart.Y + fNearestY + n*pntSigns.Y);
						pntTmp.X = pntTmp.X + pntSigns.Y* (((int)pntTmp.Y%2 != (int)pntTmp.X % 2)?1:0);

						Point pnt = new Point((int)pntTmp.X, (int)pntTmp.Y);

						if (!PointExistsInArray(aLocs,pnt))
							aLocs.Add(pnt);
					}
				}
			}

			System.Collections.SortedList sortedByY = new System.Collections.SortedList();
			for (int n = aLocs.Count-1; n >= 0; n--)
			{
				Point pnt = (Point)aLocs[n];
				if (pnt.X < 0 || pnt.X > m_playArea.Grid.GridSize.Width || pnt.Y < 0)
					aLocs.RemoveAt(n);
				else
					sortedByY.Add(pnt.Y+(float)n/aLocs.Count/10, pnt); //add extra to pntY, since sortedlist can't contain duplicates!
			}  

			float fFirstHitTime = 1000;
			Point pntFirstHitLoc;


			PointF pntGfxStart = m_playArea.Grid.GetGfxLocFromGridLoc(a_pntStart);
			PointF pntGfxEnd = m_playArea.Grid.GetGfxLocFromGridLoc(a_pntEnd);

			bool bHit = false;
			for (int n = sortedByY.Count-1; n>=0; n--)
			{
				Point pnt = (Point)sortedByY.GetByIndex(n);
				Ball ball = m_playArea.Grid.GetBallOnLoc(pnt);
				if (ball != null)
				{
					//collided with ball
					PointF pntGfx = m_playArea.Grid.GetGfxLocFromGridLoc(pnt);
					System.Collections.ArrayList aTouchLocs = new System.Collections.ArrayList();
					System.Collections.ArrayList aTouchTimes = new System.Collections.ArrayList();

					if (CalcCircleCircleCollisions(
						pntGfxStart, pntGfx,
						new PointF(pntGfxEnd.X-pntGfxStart.X, pntGfxEnd.Y-pntGfxStart.Y), new PointF(0,0),
						m_playArea.Grid.BallDiameter/2, m_playArea.Grid.BallDiameter/2,
						out aTouchLocs, out aTouchTimes))
					{
						PointF pntTouch =  (PointF)aTouchLocs[0];
						float fTime = (float)aTouchTimes[0];
						if (fTime < 0)
						{
							fTime = (float)aTouchTimes[1];
							pntTouch = (PointF)aTouchLocs[1];
						}
						if (fTime <= 1)
						{
							if (fTime < fFirstHitTime)
							{
								fFirstHitTime = fTime;
								PointF pntTopLeft = new PointF(0,0);
								a_pntTouch = m_playArea.Grid.GetGridLocFromGfxLoc(pntTouch);
								//a_pntTouch.X = (a_pntTouch.X-pntTopLeft.X)/m_playArea.Grid.BallDiameter*2;
								//a_pntTouch.Y = (a_pntTouch.Y-pntTopLeft.Y)/m_playArea.Grid.BallDiameter*2/m_playArea.Grid.HeightProportion;
								bHit = true;
							}
						}					  
					}					
				}
			}
			return bHit;
		}

		public bool CalcCircleCircleCollisions(PointF loc1, PointF loc2, PointF vel1, PointF vel2, float r1, float r2, out ArrayList aLocs, out ArrayList aTimes)
		{
			aLocs = new ArrayList();
			aTimes = new ArrayList();

			PointF loc = new PointF(loc2.X-loc1.X, loc2.Y-loc1.Y);
			PointF vel = new PointF(vel2.X-vel1.X, vel2.Y-vel1.Y);

			if (vel.X == 0 && vel.Y == 0)
				return false;
  
			//(velx*velx + vely*vely)X^2 + 2*(locx*velx + locy*vely)*X + locx*locx + locy*locy - (r1 + r2)(r1 + r2) = 0
  
			float r = r1 + r2;
  
			PointF locPwr2 = new PointF(loc.X*loc.X, loc.Y*loc.Y);
			PointF velPwr2 = new PointF(vel.X*vel.X, vel.Y*vel.Y);

			float a = 2f*(loc.X*vel.X + loc.Y*vel.Y);
			float b = locPwr2.X + locPwr2.Y - r*r;

			float divide = velPwr2.X + velPwr2.Y;

			a/=divide;
			b/=divide;

			float roots = a*a/4 - b;
			if (roots < 0)
				return false;

			roots = (float)Math.Sqrt(roots);
			float mid = -a/2;

			PointF pntHit;
			float fTime;

			fTime = mid-roots;
			for (int n = 0; n < 2; n++)
			{
				pntHit = new PointF(loc1.X - fTime*vel.X, loc1.Y-fTime*vel.Y);
				aLocs.Add(pntHit);
				aTimes.Add(fTime);

				fTime = mid+roots;
			}
			return true;
		}

		private static bool PointExistsInArray(ArrayList a, Point p)
		{
			foreach (Point pnt in a)
			{
				if (p.X == pnt.X && p.Y == pnt.Y)
					return true;
			}
			return false;
		}

	}
}
