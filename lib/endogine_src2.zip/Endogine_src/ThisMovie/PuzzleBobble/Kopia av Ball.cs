using System;
using System.Collections;
using System.Drawing;
using Endogine;

namespace PuzzleBobble
{
	/// <summary>
	/// Summary description for Ball.
	/// </summary>
	public class Ball : Sprite
	{
		private PointF m_pntVel;
		private PlayArea m_playArea;

		private ArrayList m_aPath;
		private ArrayList m_aDistances;
		private int m_nCurrentDistanceIndex;
		private float m_fMovedDistance;

		private ArrayList m_aCollisionLines;

		public int BallType = 0;
		public int ChainNum = 0; //for storing while calculating chains and connections in grid
		private Point m_pntGridLoc;
		public ArrayList m_aNeighbourLocs;
		
		public Ball(EndogineHub a_endogine, int a_nType, PlayArea a_playArea):base(a_endogine)
		{
			Parent = a_playArea;
			m_playArea = a_playArea;

			string sClr = "";
			switch (a_nType)
			{
				case 0:
					sClr = "Red";
					break;
				case 1:
					sClr = "Green";
					break;
				case 2:
					sClr = "Blue";
					break;
				case 3:
					sClr = "Yellow";
					break;
			}
			BallType = a_nType;

			MemberName = "Ball"+sClr;
			m_endogine.Put(MemberName);
			Member.CenterRegPoint();
			RegPoint = Member.RegPoint;

			m_pntVel = new PointF(0,0);
		}

		public void Shoot(int a_nAngle)
		{
			float fSpeed = 8;
			double dAngle = (double)a_nAngle*Math.PI/180;
			m_pntVel = new PointF(-fSpeed*(float)Math.Sin(dAngle), -fSpeed*(float)Math.Cos(dAngle));
		}


		public override void EnterFrame()
		{
			base.EnterFrame();
			if (m_pntVel.X == 0 && m_pntVel.Y == 0)
				return;

			Point pntStick;
			PointF pntBounce;
			if (m_playArea.m_pathCalc.GetFirstStickOrBounce(ref m_pntLoc, ref m_pntVel, out pntStick, out pntBounce))
			{
				m_playArea.Grid.SetBallOnLoc(pntStick, this);
			}
			else
				Loc = m_pntLoc;

			//TTT();
		}

		public void PushToNextWaitingPos(int a_nPos)
		{

		}

		public void Burst()
		{

		}

		public void SetPath(ArrayList a_aPath)
		{
			return;

			m_aPath = a_aPath;
			m_aDistances = new ArrayList();
			m_aDistances.Add(0f);
			float fTotalDistance = 0;
			PointF pnt = (PointF)m_aPath[0]; //m_playArea.Grid.GetGfxLocFromGridLoc((PointF)m_aPath[0]);
			for (int i = 1; i < m_aPath.Count; i++)
			{
				PointF pntNext = (PointF)m_aPath[i]; //m_playArea.Grid.GetGfxLocFromGridLoc((PointF)m_aPath[i]);//
				PointF pntDiff = new PointF(pntNext.X-pnt.X, pntNext.Y-pnt.Y);
				float fDistance = (float)Math.Sqrt(pntDiff.X*pntDiff.X + pntDiff.Y*pntDiff.Y);
				fTotalDistance+=fDistance;
				m_aDistances.Add(fTotalDistance);
				pnt = pntNext;
			}

			m_nCurrentDistanceIndex = -1;
			m_fMovedDistance = 0;
			NextDist();
		}

		private bool NextDist()
		{
			m_nCurrentDistanceIndex++;
			if (m_nCurrentDistanceIndex+1 >= m_aDistances.Count)
				return false;
			PointF pntNext = (PointF)m_aPath[m_nCurrentDistanceIndex+1];
			PointF pntThis = (PointF)m_aPath[m_nCurrentDistanceIndex];
			PointF pntDiff = new PointF(pntNext.X-pntThis.X, pntNext.Y-pntThis.Y);

			float fDist = (float)m_aDistances[m_nCurrentDistanceIndex+1] - (float)m_aDistances[m_nCurrentDistanceIndex];
			m_pntVel = new PointF(pntDiff.X/fDist, pntDiff.Y/fDist);

			return true;
		}

		private void TTT()
		{
			if (m_pntVel.Y == 0)
				return;

			float m_fSpeed = 0.3f;
			m_fMovedDistance+=m_fSpeed;
			if (m_fMovedDistance > (float)m_aDistances[m_nCurrentDistanceIndex+1])
			{
				if (NextDist() == false)
				{
					m_pntVel = new PointF(0,0);
					PointF pntF = (PointF)m_aPath[m_aPath.Count-1];
					Point pntI = m_playArea.Grid.RoundToClosestGridLoc(pntF);

					m_playArea.Grid.SetBallOnLoc(pntI, this);
					Loc = m_playArea.Grid.GetGfxLocFromGridLoc(pntI);
					//report Done!
					return;
				}
			}
			//Loc = new PointF(m_pntVel);
			float fDistSinceBounce = m_fMovedDistance-(float)m_aDistances[m_nCurrentDistanceIndex];
			PointF pntXXX = new PointF(m_pntVel.X*fDistSinceBounce, m_pntVel.Y*fDistSinceBounce);
			PointF pnt = (PointF)m_aPath[m_nCurrentDistanceIndex];
			pntXXX.X = pntXXX.X + pnt.X;
			pntXXX.Y = pntXXX.Y + pnt.Y;
			Loc = m_playArea.Grid.GetGfxLocFromGridLoc(pntXXX);
		}

		public Point GridLoc
		{
			set
			{
				m_pntGridLoc = value;

				//calc cached neighbour list for faster calculations of chains
				m_aNeighbourLocs = new ArrayList();
				if (value.Y > 0)
				{
					m_aNeighbourLocs.Add(new Point(value.X+1, value.Y-1));
					m_aNeighbourLocs.Add(new Point(value.X-1, value.Y-1));
				}
				if (value.X >= 2)
					m_aNeighbourLocs.Add(new Point(value.X-2, value.Y));
				if (value.X <= m_playArea.Grid.GridSize.Width - 2)
					m_aNeighbourLocs.Add(new Point(value.X+2, value.Y));

				m_aNeighbourLocs.Add(new Point(value.X-1, value.Y+1));
				m_aNeighbourLocs.Add(new Point(value.X+1, value.Y+1));
			}
			get {return m_pntGridLoc;}
		}

		public ArrayList GetNeighbourLocs()
		{
			return m_aNeighbourLocs;
		}
	}
}
