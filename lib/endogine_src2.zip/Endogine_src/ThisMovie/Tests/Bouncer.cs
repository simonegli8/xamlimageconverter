using System;
using System.Drawing;

using Endogine;

namespace ThisMovie
{
	/// <summary>
	/// Summary description for Bouncer.
	/// </summary>
	public class Bouncer : Sprite //Sprite3D
	{
		protected EPointF m_pntVel;
		protected Animator m_animatorRotation;

		public Bouncer()
		{
			Name = "Bouncer";
			m_pntVel = new EPointF(1f, 0.5f);
			//m_pntVel = new PointF(0f, 0f);
			//m_animatorRotation = CreateAnimator("Rotation");
			//m_animatorRotation.StepSize = 0.01f;
		}

		public override void EnterFrame()
		{
			base.EnterFrame();
			Move(m_pntVel);
			if (Loc.X < -40 || Loc.X > 400)
				m_pntVel.X*=-1;
			if (Loc.Y < -40 || Loc.Y > 400)
				m_pntVel.Y*=-1;

			if (AutoAnimator!=null)
				AutoAnimator.StepSize = Loc.X/200;
		}
	}
}
