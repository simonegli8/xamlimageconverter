using System;
using Endogine;

namespace ThisMovie
{
	/// <summary>
	/// Summary description for SwingBehavior.
	/// </summary>
	public class BhSwing : Behavior
	{
		private int m_nCnt = 0;

		public BhSwing()
		{
		}

		public BhSwing(int nCntOffset)
		{
			m_nCnt = nCntOffset;
		}

		protected override void EnterFrame()
		{
			m_sp.LocY += (float)Math.Sin(0.05*m_nCnt++)*0.5f;
			m_sp.Rotation = (float)Math.Sin(0.05*m_nCnt++)*0.1f;
			base.EnterFrame();
		}
	}
}
