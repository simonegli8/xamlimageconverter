using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

using Endogine;

namespace ThisMovie
{
	public class Main : Endogine.MainBase
	{
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem miParticle;
		private System.Windows.Forms.MenuItem miPuzzle;
		private System.Windows.Forms.MenuItem miFont;
		private System.Windows.Forms.MenuItem miParallax;
		private System.Windows.Forms.MenuItem miGifAnim;
		private System.Windows.Forms.MenuItem miDonut;
		private System.ComponentModel.IContainer components = null;

		private PuzzleBobble.PlayArea m_playArea = null;

		private Endogine.Text.BitmapFont m_font;
		private Endogine.Forms.Label m_lbl;

		private SideScroller.GameMain m_scrollerGame = null;

		private ParticleControl m_particleControl = null;
		private System.Windows.Forms.MenuItem miGDIPerlin;
		private FunParticleSystem m_particleSystem = null;

		private Sprite m_spProcedural = null;

		private Sprite m_spDragGif = null;
		private Sprite m_spDonut = null;

		public Main()
		{
			InitializeComponent();
			this.Text = "Main!";
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.miParticle = new System.Windows.Forms.MenuItem();
			this.miPuzzle = new System.Windows.Forms.MenuItem();
			this.miFont = new System.Windows.Forms.MenuItem();
			this.miParallax = new System.Windows.Forms.MenuItem();
			this.miGDIPerlin = new System.Windows.Forms.MenuItem();
			this.miGifAnim = new System.Windows.Forms.MenuItem();
			this.miDonut = new System.Windows.Forms.MenuItem();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.miParticle,
																					  this.miPuzzle,
																					  this.miFont,
																					  this.miParallax,
																					  this.miGDIPerlin,
																					  this.miGifAnim,
																					  this.miDonut});
			this.menuItem1.Text = "Engine tests";
			// 
			// miParticle
			// 
			this.miParticle.Index = 0;
			this.miParticle.Text = "Particle system";
			this.miParticle.Click += new System.EventHandler(this.miParticle_Click);
			// 
			// miPuzzle
			// 
			this.miPuzzle.Index = 1;
			this.miPuzzle.Text = "Puzzle Bobble";
			this.miPuzzle.Click += new System.EventHandler(this.miPuzzle_Click);
			// 
			// miFont
			// 
			this.miFont.Index = 2;
			this.miFont.Text = "Font";
			this.miFont.Click += new System.EventHandler(this.miFont_Click);
			// 
			// miParallax
			// 
			this.miParallax.Index = 3;
			this.miParallax.Text = "Parallax Scroll";
			this.miParallax.Click += new System.EventHandler(this.miParallax_Click);
			// 
			// miGDIPerlin
			// 
			this.miGDIPerlin.Index = 4;
			this.miGDIPerlin.Text = "GDI+random procedural";
			this.miGDIPerlin.Click += new System.EventHandler(this.miGDIPerlin_Click);
			// 
			// miGifAnim
			// 
			this.miGifAnim.Index = 5;
			this.miGifAnim.Text = "Draggable animated gif";
			this.miGifAnim.Click += new System.EventHandler(this.miGifAnim_Click);
			// 
			// miDonut
			// 
			this.miDonut.Index = 6;
			this.miDonut.Text = "Bouncing donut";
			this.miDonut.Click += new System.EventHandler(this.miDonut_Click);
			// 
			// Main
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(632, 453);
			this.Menu = this.mainMenu1;
			this.Name = "Main";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Stage";

		}
		#endregion

		private void miParticle_Click(object sender, System.EventArgs e)
		{
			if (m_particleControl == null)
			{
				MemberSpriteBitmap mbParticle = (MemberSpriteBitmap)EndogineHub.Get().CastLib.GetOrCreate("Particle");
				mbParticle.CenterRegPoint();

				m_particleSystem = new FunParticleSystem();
				m_particleSystem.ParticleMember = mbParticle;
				m_particleSystem.Ink = RasterOps.ROPs.AddPin; //Difference looks nice (only works properly in GDI mode);
				m_particleSystem.SourceRect = new ERectangle(0,0,50,50); //how big is the emitter
				m_particleSystem.LocZ = 100;

				m_particleControl = new ParticleControl(m_particleSystem);
			}
			else
			{
				m_particleControl.Dispose();
				m_particleControl = null;

				m_particleSystem.Dispose();
			}
		}

		private void miPuzzle_Click(object sender, System.EventArgs e)
		{
			if (m_playArea == null)
			{
				//This starts puzzle bobble:
				m_playArea = new PuzzleBobble.PlayArea();
				m_playArea.Loc = new EPointF(100,50);
			}
			else
			{
				m_playArea.Dispose();
				m_playArea = null;
			}
		}

		private void miFont_Click(object sender, System.EventArgs e)
		{
			if (m_lbl == null)
			{
				//Testing custom bitmap font text rendering.
				if (m_font == null)
				{
					m_font = new Endogine.Text.BitmapFont();
					//Load. The parsing of the font specification is what takes so long in the initialization (it's quick hack, I'll improve it later)
					m_font.Load(m_endogine.CastLib.DirectoryPath + "FontRM01");
				}
				m_lbl = new Endogine.Forms.Label();
				m_lbl.Font = m_font;
				m_lbl.Kerning = 0.5f;
				m_lbl.Loc = new EPointF(10,100);
				m_lbl.Text = "Kerning: VA";
				//Add a swing behavior to each sprite. Behaviors can be added to any sprite.
				for (int i = 0; i < m_lbl.Sprites.Count; i++)
					((Sprite)m_lbl.Sprites[i]).AddBehavior(new BhSwing(i*5));
			}
			else
			{
				m_lbl.Dispose();
				m_lbl = null;
			}
		}

		private void miParallax_Click(object sender, System.EventArgs e)
		{
			if (m_scrollerGame == null)
			{
				m_scrollerGame = new SideScroller.GameMain();
			}
			else
			{
				m_scrollerGame.Dispose();
				m_scrollerGame = null;
			}
		}

		private void miGDIPerlin_Click(object sender, System.EventArgs e)
		{
			if (m_spProcedural == null)
			{
				Bitmap bmp;
				Graphics g;

				#region Procedural noise bitmap
				
				Random rnd = new Random();

				Endogine.Procedural.Noise procedural = null;
				switch (rnd.Next(3))
				{
					case 0:
						procedural = new Endogine.Procedural.Plasma();
						procedural.Decay = 0.5f;
						procedural.Frequency = 0.1f;
						procedural.Octaves = 3;
						break;
					case 1:
						procedural = new Endogine.Procedural.Wood();
						procedural.Decay = 0.5f;
						procedural.Frequency = 0.1f;
						procedural.Octaves = 3;
						((Endogine.Procedural.Wood)procedural).NumCircles = 5;
						((Endogine.Procedural.Wood)procedural).Turbulence = 0.3f;
						break;
					case 2:
						procedural = new Endogine.Procedural.Marble();
						procedural.Decay = 0.5f;
						procedural.Frequency = 0.1f;
						procedural.Octaves = 3;
						((Endogine.Procedural.Marble)procedural).Periods = new EPointF(15,30);
						((Endogine.Procedural.Marble)procedural).Turbulence = 3.3f;
						break;
				}

				
				bmp = new Bitmap(200,200);
				//create a color table that makes it look like lakes and mountains:
				System.Collections.SortedList aColors = new System.Collections.SortedList();
				aColors.Add(0.0, Color.FromArgb(0,0,190));
				aColors.Add(0.1, Color.FromArgb(0,0,255));
				aColors.Add(0.11, Color.FromArgb(0,200,0));
				aColors.Add(0.5, Color.FromArgb(150,100,0));
				aColors.Add(1.0, Color.FromArgb(255,255,255));
				procedural.SetColors(aColors);
				//write pixels to bitmap:
				procedural.WriteToBitmap(bmp);
				#endregion


				#region Create gradient bitmap
				//Create two gradients using GDI+, and merge them with my CopyPixels for special effects
				Bitmap bmpGradient = new Bitmap(200,200);
				g = Graphics.FromImage(bmpGradient);
				LinearGradientBrush brush = new LinearGradientBrush(new Rectangle(4,0,bmpGradient.Width,bmpGradient.Height), Color.FromArgb(255,0,0), Color.FromArgb(0,255,0), 0f);
				g.FillRectangle(brush, brush.Rectangle);

				Bitmap bmp2 = new Bitmap(bmpGradient.Width,bmpGradient.Height);
				brush = new LinearGradientBrush(new Rectangle(0,0,bmp2.Width,bmp2.Height), Color.FromArgb(0,0,255), Color.FromArgb(0,0,0), (float)90);
				Graphics g2 = Graphics.FromImage(bmp2);
				g2.FillRectangle(brush, brush.Rectangle);
			
				RasterOps.CopyPixels(bmpGradient, bmp2, (int)RasterOps.ROPs.AddPin, 255);
				RasterOps.CopyPixels(bmp, bmpGradient, (int)RasterOps.ROPs.Lightest, 255);
				g.Dispose();
				#endregion


				MemberSpriteBitmap mb = new MemberSpriteBitmap(bmp);
			
				m_spProcedural = new Sprite();
				m_spProcedural.Name = "Procedural";
				m_spProcedural.Member = mb;
				m_spProcedural.Scaling = new EPointF(2,2);
				m_spProcedural.Ink = 0;
			}
			else
			{
				//TODO: the bitmap will still remain in memory, should have an "autodispose" option,
				//so that resources gets disposed when no sprites are using them
				m_spProcedural.Dispose();
				m_spProcedural = null;
			}
		}

		private void miGifAnim_Click(object sender, System.EventArgs e)
		{
			#region a draggable sprite which scales and changes transparency depending on LocX
			if (m_spDragGif == null)
			{
				MemberSpriteBitmap mbDrag = (MemberSpriteBitmap)m_endogine.CastLib.GetOrCreate("416.gif");
				mbDrag.CenterRegPoint();

				m_spDragGif = new DragSprite();
				m_spDragGif.Member = mbDrag;
				m_spDragGif.Ink = RasterOps.ROPs.D3DTest1;
				m_spDragGif.LocZ = 5;
				m_spDragGif.Loc = new EPointF(300,300);
			}
			else
			{
				m_spDragGif.Dispose();
				m_spDragGif = null;
			}
			#endregion
		}

		private void miDonut_Click(object sender, System.EventArgs e)
		{
			if (m_spDonut == null)
			{
				MemberSpriteBitmap mbDonut = (MemberSpriteBitmap)m_endogine.CastLib.GetOrCreate("donut");
				//this is a bitmap with a grid of pictures used for animation.
				//we have to define the size of each frame in the animation, otherwise it's not interpreted as an animation:
				mbDonut.AnimateWithinSize = new EPoint(64,64);
				mbDonut.CenterRegPoint();

				//create bouncing sprite and set props:
				m_spDonut = new Bouncer();
				m_spDonut.Member = mbDonut;
				m_spDonut.Scaling = new EPointF(4,4);
				m_spDonut.Loc = new EPointF(-32,-32);
				m_spDonut.Ink = RasterOps.ROPs.D3DTest2;
				m_spDonut.LocZ = 1;
			}
			else
			{
				m_spDonut.Dispose();
				m_spDonut = null;
			}
		}
	}
}

