
08 Apr 2009

Inkscape version: 0.46 [1].
Stylesheets from this Inkscape installation: 
	svg2xaml.xsl + colors.xml.
	xaml2svg.xsl + animation.xsl, brushes.xsl, canvas.xsl, geometry.xsl, properties.xsl, shapes.xsl, transform.xsl.

SVG to XAML
================================
Drawing3D_01.svg		Inkskape image.
Drawing3D_01.xaml		Drawing3D_01.svg converted to XAML with svg2xaml.xsl from code.
Drawing3D_02.svg		Drawing3D_01.svg corrected by hand.
Drawing3D_02.xaml		Drawing3D_02.svg converted to XAML with svg2xaml.xsl from code.
Image_01.svg			SVG test image made by hand.
Image_01.xaml 			Image_01.svg converted to XAML with svg2xaml.xsl from code.
Image_01_Inkscape.xaml		Inkscape. Image_01.svg saved as XAML.
Image_01_Inkscape_white.xaml	Image_01_Inkscape_SVG2XAML.xaml + whitespace added by hand.
Image_02.svg			Image_01.svg with larger borders (changed by hand).
Image_01.xaml 			Image_01.xaml with larger borders (changed by hand).
Image_03.svg			Rectangle + line. SVG test image made with Inkscape.
Image_03.xaml			Image_02.svg saved as XAML from Inkscape.
TestText_01.svg			Inkscape. Text objects with the text tool (F8).
TestText_01_Inkscape.xaml	Inkscape. TestText_01.svg saved as XAML.
TestText_02.svg			Inkscape. TestText_01.svg after menu Text | Convert to. 
TestText_02_Inkscape.xaml	Inkscape. TestText_02.svg saved as XAML.
Butterfly.svg			Test image, downloaded.
Butterfly.xaml			Butterfly.svg converted to XAML with svg2xaml.xsl from code.
Lion.svg			Test image, downloaded.
Lion.xaml			Lion.svg converted to XAML with svg2xaml.xsl from code.
Tiger.svg			Test image, downloaded.
Tiger.xaml			Tiger.svg converted to XAML with svg2xaml.xsl from code.
Coloredtoucan2.svg		Test image, downloaded. [2]
Coloredtoucan2.xaml		Coloredtoucan2.svg converted to XAML with svg2xaml.xsl from code.
GreenFrond.svg			Test image, downloaded. [2]
GreenFrond.xaml			GreenFrond.svg converted to XAML with svg2xaml.xsl from code.

[1] http://www.inkscape.org/
[2] http://members.chello.nl/~a.degreef/XAML.html


XAML to SVG
================================
Page_06.xaml			Rectangle, RotateTransform.
Page_06.svg			Page_06.xaml converted to SVG with xaml2svg2.xsl from code.
Page_10.xaml			Rectangle, Path.
Page_10.svg			Page_10.xaml converted to SVG with xaml2svg2.xsl from code.
Page_11.xaml			Polygon.
Page_11.svg			Page_11.xaml converted to SVG with xaml2svg2.xsl from code.
Page_19.xaml			RotateTransform on a Rectangle.
Page_19.svg			Page_19.xaml converted to SVG with xaml2svg2.xsl from code.
Page_20.xaml			As Page_19, with resource.
Page_20.svg			Page_20.xaml converted to SVG with xaml2svg2.xsl from code.

All the SVG files in the XAML to SVG section are corrected with an extra namespace xmlns="http://www.w3.org/2000/svg" in the root element.


-------------------------------------------------------------------------------------------
